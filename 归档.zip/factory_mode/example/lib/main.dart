import 'package:flutter/material.dart';
import 'package:factory_mode/ui/m5/m5_ui.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const ColoredBox(
        color: Colors.grey,
        child: Center(
          child: SizedBox(
            width: 480,
            height: 480,
            child: M5FactoryMode(),
          ),
        ),
      ),
    );
  }
}
