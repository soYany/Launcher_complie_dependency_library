import 'dart:collection';
import 'package:factory_mode/entity/entitys.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:get/get.dart';

class TestProjectManager {
  static final Rx<TestMode?> _currentTestMode = Rx<TestMode?>(null);

  static TestMode? get currentTestMode => _currentTestMode.value;

  static set currentTestMode(TestMode? value) => _currentTestMode.value = value;

  static final Rx<TestProject?> _currentTestProject = Rx<TestProject?>(null);

  static TestProject? get currentTestProject => _currentTestProject.value;

  static set currentTestProject(TestProject? value) => _currentTestProject.value = value;

  static final Rx<bool> _loadHistoryResultMode = Rx<bool>(false);

  static bool get loadHistoryResultMode => _loadHistoryResultMode.value;

  static set loadHistoryResultMode(bool value) => _loadHistoryResultMode.value = value;

  static final LinkedHashMap<TestProject, FunctionEntity> _allTestFunction =
      LinkedHashMap<TestProject, FunctionEntity>.identity();

  static void setAllTestFunction(List<FunctionEntity> projectList) {
    _allTestFunction.clear();
    for (final FunctionEntity element in projectList) {
      final TestProject? project = TestProject.fromString(element.functionId);
      if (project != null) {
        _allTestFunction[project] = element;
      }
    }
  }

  static List<TestProject> getAllTestProject() {
    return _allTestFunction.keys.toList();
  }

  static Map<String, dynamic> getExtraData(TestProject project) {
    return _allTestFunction[project]?.extra ?? <String, dynamic>{};
  }

  static final RxMap<TestProject, bool> _projectStateMap = RxMap<TestProject, bool>.identity();

  static void setTestProjectList(List<TestProject> projectList) {
    _projectStateMap.clear();
    _projectStateMap.addEntries(projectList.map((TestProject e) => MapEntry<TestProject, bool>(e, false)));
  }

  static List<TestProject> getTestProjectList() {
    return _projectStateMap.keys.toList();
  }

  static void setTestProjectTested(TestProject project) {
    if (_projectStateMap.containsKey(project)) {
      _projectStateMap[project] = true;
    }
  }

  static void resetTestProjectState() {
    _projectStateMap.forEach((TestProject key, bool value) {
      _projectStateMap[key] = false;
    });
  }

  static void resetTestProject() {
    _projectStateMap.clear();
    currentTestProject = null;
    currentTestMode = null;
  }

  static bool isTested() {
    return _projectStateMap.isNotEmpty && _projectStateMap.values.every((bool element) => element);
  }

}
