import 'dart:convert';
import 'dart:io';

import 'package:factory_mode/entity/entitys.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/utils/logger_utils.dart';

typedef TestProjectResult = ({TestResult result, String? failReason});

abstract class TestResultManager {
  final String _allTestResultFilePath = "/backup_data/factoryResult.json";
  final String _pcbaTestResultFilePath = "/backup_data/factoryPcbaResult.json";

  abstract final List<TestProject> allTestProjectList;
  abstract final List<TestProject> pcbaTestProjectList;

  abstract final List<TestProject> qrCodeResultOrderList;

  static const String testResultKey = "testResult";

  final Map<String, dynamic> defaultFactoryResultContent = <String, dynamic>{};

  final Map<String, String> deviceInfoContent = <String, String>{};
  final Map<String, dynamic> testResultContent = <String, dynamic>{};

  TestMode? currentMode;

  void loadFactoryResult(TestMode mode) {
    currentMode = mode;
    final File file = switch (mode) {
      TestMode.all => File(_allTestResultFilePath),
      TestMode.pcba => File(_pcbaTestResultFilePath),
    };
    Map<String, dynamic> data;
    if (file.existsSync()) {
      final String str = file.readAsStringSync();
      try {
        data = jsonDecode(str);
      } catch (_) {
        data = Map<String, dynamic>.of(defaultFactoryResultContent);
      }
    } else {
      data = Map<String, dynamic>.of(defaultFactoryResultContent);
    }
    testResultContent
      ..clear()
      ..addAll(data[testResultKey]);
    data.remove(testResultKey);
    if (deviceInfoContent.isEmpty) {
      data.forEach((String key, dynamic value) {
        deviceInfoContent[key] = value.toString();
      });
    }
  }

  void saveFactoryResult() {
    try {
      final TestMode? currentMode = this.currentMode;
      if (currentMode == null) {
        throw Exception("currentMode is null");
      }
      final File file = switch (currentMode) {
        TestMode.all => File(_allTestResultFilePath),
        TestMode.pcba => File(_pcbaTestResultFilePath),
      };
      final Map<String, dynamic> data = <String, dynamic>{}
        ..addAll(deviceInfoContent)
        ..addAll(<String, dynamic>{testResultKey: testResultContent});
      final String resultStr = jsonEncode(data);
      if (file.existsSync()) {
        file.deleteSync();
      }
      file.writeAsStringSync(resultStr, flush: true);
    } catch (e, s) {
      LoggerUtils.print("$e\n$s");
    }
  }

  void setDeviceInfo(DeviceInfoEntity deviceInfo) {
    deviceInfoContent.clear();
    deviceInfoContent.addAll(deviceInfo.toResultMap());
  }

  void setTestResult(TestProject project, TestResult result, {dynamic extraResult});

  TestProjectResult getTestResult(TestProject project);

  String getQrCodeData();

  bool isAllTested();
}
