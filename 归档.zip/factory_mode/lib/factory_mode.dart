import 'dart:io';

import 'package:collection/collection.dart';
import 'package:factory_mode/config/factory_builder_config.dart';
import 'package:factory_mode/ui/gauss/gauss_ui.dart' as gauss_ui;
import 'package:factory_mode/ui/m5/m5_ui.dart' as m5_ui;
import 'package:factory_mode/utils/logger_utils.dart';
import 'package:factory_mode/widget/model_provider_widget.dart';
import 'package:flutter/material.dart';
export 'package:factory_mode/factory_mode.dart';

class FactoryMode {
  factory FactoryMode() => _instance ??= FactoryMode._internal();

  FactoryMode._internal();

  static FactoryMode? _instance;

  FactoryBuilderConfig config = FactoryBuilderConfig.defaultConfig;

  Widget? getFactoryModeUI() {
    try {
      final String cmdline = File("/proc/cmdline").readAsStringSync();
      final String? orbModel = cmdline
          .split(" ")
          .map((String e) => e.trim())
          .firstWhereOrNull((String e) => e.startsWith("orbmodel"))
          ?.split("=")
          .lastOrNull;
      LoggerUtils.print("orbModel: $orbModel");
      Widget? ui;
      if (orbModel == "MixPadGauss") {
        ui = const gauss_ui.GaussFactoryMode();
        scaleValue = 1;
      } else if (orbModel == "MixpadHostM5") {
        ui = const m5_ui.M5FactoryMode();
        scaleValue = 4/3;
      }
      if (ui != null && orbModel != null) {
        return MaterialApp(
          home: ModelProviderWidget(
            model: orbModel,
            child: ui,
          ),
        );
      }
    } catch (e, s) {
      LoggerUtils.print("$e\n$s");
    }
    return null;
  }

  double scaleValue = 1;
}
