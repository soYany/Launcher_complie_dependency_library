import 'dart:convert';
import 'dart:ffi';
import 'dart:io';
import 'dart:isolate';

import 'package:factory_mode/entity/entitys.dart';
import 'package:factory_mode/utils/logger_utils.dart';
import 'package:ffi/ffi.dart';

typedef _InitializeDartApiDL = int Function(Pointer<Void>, int);
typedef _Write = Pointer<Utf8> Function(Pointer<Utf8>);
typedef _Read = Pointer<Utf8> Function(Pointer<Utf8>);
typedef _Reset = void Function();

typedef EventCallback = void Function(Map<String, dynamic> data);

class FactoryTestNativeApi {
  factory FactoryTestNativeApi() => _instance ??= FactoryTestNativeApi._internal();

  FactoryTestNativeApi._internal() {
    _initApi();
  }

  static FactoryTestNativeApi? _instance;

  _InitializeDartApiDL? _initializeDartApiDLApi;
  _Write? _writeApi;
  _Read? _readApi;
  _Reset? _resetApi;

  void _initApi() {
    try {
      const String tagPath = "/tmp/launcher_factory";
      final File tagFile = File(tagPath);
      if (tagFile.existsSync()) {
        LoggerUtils.print("存在 /tmp/launcher_factory, 删除它");
        tagFile.deleteSync();
      } else {
        LoggerUtils.print("不存在 /tmp/launcher_factory, 创建它");
        tagFile.createSync();
      }

      final DynamicLibrary nativeLib = DynamicLibrary.open('liborbfactory.so');
      _initializeDartApiDLApi = nativeLib
          .lookupFunction<IntPtr Function(Pointer<Void>, IntPtr), _InitializeDartApiDL>('Factory_InitializeDartApiDL');
      _writeApi = nativeLib.lookupFunction<Pointer<Utf8> Function(Pointer<Utf8>), _Write>('factory_write');
      _readApi = nativeLib.lookupFunction<Pointer<Utf8> Function(Pointer<Utf8>), _Read>('factory_read');
      _resetApi = nativeLib.lookupFunction<Void Function(), _Reset>('factory_reset');
      final ReceivePort port = ReceivePort();
      _listenerStream(port);
      _initializeDartApiDLApi?.call(NativeApi.initializeApiDLData, port.sendPort.nativePort);
    } catch (e, s) {
      LoggerUtils.print("$e\n$s");
    }
  }

  String? _write(String data) {
    final Pointer<Utf8> dataPtr = data.toNativeUtf8();
    LoggerUtils.print("send data start: $data");
    final Pointer<Utf8>? result = _writeApi?.call(dataPtr);
    final String? resultString = result?.toDartString();
    LoggerUtils.print("send data end: $data $resultString");
    calloc.free(dataPtr);
    return resultString;
  }

  String? _read(String data) {
    final Pointer<Utf8> dataPtr = data.toNativeUtf8();
    LoggerUtils.print("read data start: $data");
    final Pointer<Utf8>? result = _readApi?.call(dataPtr);
    final String? resultString = result?.toDartString();
    LoggerUtils.print("read data end: $data $resultString");
    calloc.free(dataPtr);
    return resultString;
  }

  void reset() {
    _resetApi?.call();
  }

  EventEntity? sendEvent(EventEntity event) {
    final String dataStr = jsonEncode(event);
    final String? result = _write(dataStr);
    if (result == null) {
      return null;
    }
    return EventEntity.fromJson(jsonDecode(result));
  }

  EventEntity? readEvent(EventEntity event) {
    final String dataStr = jsonEncode(event);
    final String? result = _read(dataStr);
    if (result == null) {
      return null;
    }
    return EventEntity.fromJson(jsonDecode(result));
  }

  final Map<String, List<EventCallback>> _eventCallbackMap = <String, List<EventCallback>>{};

  void registerEvent(String event, EventCallback callback) {
    _eventCallbackMap[event] ??= <EventCallback>[];
    _eventCallbackMap[event]?.add(callback);
  }

  void clearEvent(String event) {
    _eventCallbackMap[event]?.clear();
    _eventCallbackMap.remove(event);
  }

  void unregisterEvent(String event, EventCallback callback) {
    _eventCallbackMap[event]?.remove(callback);
    if (_eventCallbackMap[event]?.isEmpty == true) {
      _eventCallbackMap.remove(event);
    }
  }

  Future<void> _listenerStream(Stream<dynamic> stream) async {
    await for (final dynamic data in stream) {
      try {
        if (data is! String) {
          throw Exception('数据类型异常:$data');
        }
        LoggerUtils.print("receive data: $data");
        final Map<String, dynamic> json = jsonDecode(data);
        final EventEntity event = EventEntity.fromJson(json);
        final List<EventCallback> callbacks =
            List<EventCallback>.of(FactoryTestNativeApi()._eventCallbackMap[event.event] ?? <EventCallback>[]);
        for (final EventCallback callback in callbacks) {
          callback(event.data);
        }
      } catch (e, s) {
        LoggerUtils.print("$e\n$s");
      }
    }
  }
}
