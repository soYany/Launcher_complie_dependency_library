import 'dart:async';
import 'dart:io';

import 'package:factory_mode/api/factory_test_native_api.dart';
import 'package:factory_mode/entity/entitys.dart';
import 'package:factory_mode/utils/logger_utils.dart';

class FactoryTestApi {
  static List<FunctionEntity>? getAllTestProjectList() {
    try {
      final Map<String, dynamic>? data = FactoryTestNativeApi().readEvent(EventEntity("ft.function_list.get"))?.data;
      if (data != null) {
        final int status = data["status"];
        if (status == 0) {
          final List<dynamic> testList = data["function_list"];
          final List<FunctionEntity> testProjectList = testList.map((dynamic e) => FunctionEntity.fromJson(e)).toList();
          return testProjectList;
        } else {
          LoggerUtils.print("获取测试项目失败 $status");
        }
      }
    } catch (e, s) {
      LoggerUtils.print("$e\n$s");
    }
    return null;
  }

  static DeviceInfoEntity? getDeviceInfo() {
    final Map<String, dynamic>? data = FactoryTestNativeApi().readEvent(EventEntity("ft.deviceInfo.get"))?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        return DeviceInfoEntity.fromJson(data);
      } else {
        LoggerUtils.print("获取设备信息失败 $status");
      }
    }
    return null;
  }

  static bool wifiScanStart() {
    final Map<String, dynamic>? data = FactoryTestNativeApi()
        .sendEvent(EventEntity("ft.wifiInfo.set", data: <String, dynamic>{"scan": "start"}))
        ?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        return true;
      } else {
        LoggerUtils.print("WiFi Start 失败 $status");
      }
    }
    return false;
  }

  static bool wifiScanStop() {
    final Map<String, dynamic>? data =
        FactoryTestNativeApi().sendEvent(EventEntity("ft.wifiInfo.set", data: <String, dynamic>{"scan": "stop"}))?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        return true;
      } else {
        LoggerUtils.print("WiFi Stop 失败 $status");
      }
    }
    return false;
  }

  static ({WiFiInfoEntity? hz_2_4, WiFiInfoEntity? hz_5}) getWiFiInfo() {
    final Map<String, dynamic>? data = FactoryTestNativeApi().readEvent(EventEntity("ft.wifiInfo.get"))?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        final Map<String, dynamic>? hz_2_4 = data["wifi_hz_2_4"];
        final Map<String, dynamic>? hz_5 = data["wifi_hz_5"];
        WiFiInfoEntity? hz_2_4Info;
        WiFiInfoEntity? hz_5Info;
        if (hz_2_4 != null) {
          hz_2_4Info = WiFiInfoEntity.fromJson(hz_2_4);
          if (hz_2_4Info.isEmpty) {
            hz_2_4Info = null;
          }
        } else {
          hz_2_4Info = null;
        }
        if (hz_5 != null) {
          hz_5Info = WiFiInfoEntity.fromJson(hz_5);
          if (hz_5Info.isEmpty) {
            hz_5Info = null;
          }
        } else {
          hz_5Info = null;
        }
        return (hz_2_4: hz_2_4Info, hz_5: hz_5Info);
      } else {
        LoggerUtils.print("获取WiFi信息失败 $status");
      }
    }
    return (hz_2_4: null, hz_5: null);
  }

  static bool bluetoothScanStart() {
    final Map<String, dynamic>? data = FactoryTestNativeApi()
        .sendEvent(EventEntity("ft.bluetooth.set", data: <String, dynamic>{"scan": "start"}))
        ?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        return true;
      } else {
        LoggerUtils.print("开始扫描蓝牙失败 $status");
      }
    }
    return false;
  }

  static bool bluetoothScanStop() {
    final Map<String, dynamic>? data = FactoryTestNativeApi()
        .sendEvent(EventEntity("ft.bluetooth.set", data: <String, dynamic>{"scan": "stop"}))
        ?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        return true;
      } else {
        LoggerUtils.print("停止扫描蓝牙失败 $status");
      }
    }
    return false;
  }

  static BluetoothInfoEntity? getBluetoothInfo() {
    final Map<String, dynamic>? data = FactoryTestNativeApi().readEvent(EventEntity("ft.bluetooth.get"))?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        final BluetoothInfoEntity bluetoothInfoEntity = BluetoothInfoEntity.fromJson(data);
        if (!bluetoothInfoEntity.isEmpty) {
          return BluetoothInfoEntity.fromJson(data);
        }
      }
      LoggerUtils.print("获取蓝牙信息失败 $status");
    }
    return null;
  }

  static bool bottomShellListenerStart() {
    final Map<String, dynamic>? data = FactoryTestNativeApi()
        .sendEvent(EventEntity("ft.bottomShell.set", data: <String, dynamic>{"action": "start"}))
        ?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        return true;
      } else {
        LoggerUtils.print("开始监听底座失败 $status");
      }
    }
    return false;
  }

  static bool bottomShellListenerStop() {
    final Map<String, dynamic>? data = FactoryTestNativeApi()
        .sendEvent(EventEntity("ft.bottomShell.set", data: <String, dynamic>{"action": "stop"}))
        ?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        return true;
      } else {
        LoggerUtils.print("停止监听底座失败 $status");
      }
    }
    return false;
  }

  static void registerBottomShellCallback(void Function(int type, bool result) callback) {
    void keyActionCallback(Map<String, dynamic> data) {
      final int type = data["type"];
      final bool result = data["status"] == 0;
      callback(type, result);
    }

    FactoryTestNativeApi().registerEvent("ft.bottomShell.upload", keyActionCallback);
  }

  static void unregisterBottomShellCallback(void Function(int type, bool result) callback) {
    FactoryTestNativeApi().clearEvent("ft.bottomShell.upload");
  }

  // data.type
  // 1：继电器类型
  // 2：485传感器
  static bool controllerBottomShell(bool? isOn, {int? index, int type = 1}) {
    final Map<String, dynamic>? data = FactoryTestNativeApi()
        .sendEvent(EventEntity("ft.bottomShell.set", data: <String, dynamic>{
          if (isOn != null) "onoff": isOn ? "on" : "off",
          "type": type,
          if (index != null) "index": index,
        }))
        ?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        return true;
      }
      LoggerUtils.print("控制底壳失败 $status");
    }
    return false;
  }

  static bool audioPlay() {
    final Map<String, dynamic>? data = FactoryTestNativeApi()
        .sendEvent(EventEntity("ft.audio.set", data: <String, dynamic>{
          "action": "play",
        }))
        ?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        return true;
      } else {
        LoggerUtils.print("音频播放失败 $status");
      }
    }
    return false;
  }

  static Future<Map<String, dynamic>?> microphoneBaseTest(String? action,
      {Duration timeout = const Duration(seconds: 15)}) async {
    final Completer<Map<String, dynamic>?> completer = Completer<Map<String, dynamic>?>();
    void callback(Map<String, dynamic> data) {
      FactoryTestNativeApi().unregisterEvent("ft.microphone.upload", callback);
      final Map<String, dynamic> microphones = data["microphones"];
      completer.complete(microphones);
    }

    FactoryTestNativeApi().registerEvent("ft.microphone.upload", callback);
    final Map<String, dynamic>? data = FactoryTestNativeApi()
        .sendEvent(EventEntity("ft.microphone.set", data: <String, dynamic>{"action": action}))
        ?.data;
    if (data != null) {
      final int status = data["status"];
      if (status != 0) {
        FactoryTestNativeApi().unregisterEvent("ft.microphone.upload", callback);
        LoggerUtils.print("麦克风基础测试失败 $status");
        completer.complete(null);
      }
    }
    return completer.future.timeout(timeout, onTimeout: () {
      LoggerUtils.print("麦克风基础测试超时");
      FactoryTestNativeApi().unregisterEvent("ft.microphone.upload", callback);
      completer.complete(null);
      return completer.future;
    });
  }

  static Future<bool> microphoneActionTest(String action) async {
    final Completer<bool> completer = Completer<bool>();
    void callback(Map<String, dynamic> data) {
      final String actionType = data["actionType"];
      if (actionType != action) {
        return;
      }
      FactoryTestNativeApi().unregisterEvent("ft.microphone.upload", callback);
      completer.complete(data["status"] == 0);
    }

    FactoryTestNativeApi().registerEvent("ft.microphone.upload", callback);
    final Map<String, dynamic>? data = FactoryTestNativeApi()
        .sendEvent(EventEntity("ft.microphone.set", data: <String, dynamic>{
          "action": action,
        }))
        ?.data;
    if (data != null) {
      final int status = data["status"];
      if (status != 0) {
        FactoryTestNativeApi().unregisterEvent("ft.microphone.upload", callback);
        LoggerUtils.print("麦克风动作测试失败 $status");
        completer.complete(false);
      }
    }
    return completer.future.timeout(const Duration(seconds: 15), onTimeout: () {
      LoggerUtils.print("麦克风动作测试失败");
      FactoryTestNativeApi().unregisterEvent("ft.microphone.upload", callback);
      completer.complete(false);
      return completer.future;
    });
  }

  static Future<bool> zigbeeActionTest(String action, {int seconds = 5}) async {
    final Completer<bool> completer = Completer<bool>();
    void callback(Map<String, dynamic> data) {
      FactoryTestNativeApi().unregisterEvent("ft.zigbee.upload", callback);
      final int status = data["status"];
      if (status == 0) {
        completer.complete(true);
      } else {
        LoggerUtils.print("Zigbee动作测试失败 $status");
        completer.complete(false);
      }
    }

    FactoryTestNativeApi().registerEvent("ft.zigbee.upload", callback);
    final Map<String, dynamic>? data = FactoryTestNativeApi()
        .sendEvent(EventEntity("ft.zigbee.set", data: <String, dynamic>{
          "action": action,
        }))
        ?.data;
    if (data != null) {
      final int status = data["status"];
      if (status != 0) {
        FactoryTestNativeApi().unregisterEvent("ft.zigbee.upload", callback);
        LoggerUtils.print("Zigbee动作测试失败 $status");
        completer.complete(false);
      }
    }
    return completer.future.timeout(Duration(seconds: seconds), onTimeout: () {
      LoggerUtils.print("Zigbee动作测试超时");
      FactoryTestNativeApi().unregisterEvent("ft.zigbee.upload", callback);
      completer.complete(false);
      return completer.future;
    });
  }

  static bool keyListenerStart() {
    final Map<String, dynamic>? data =
        FactoryTestNativeApi().sendEvent(EventEntity("ft.key.set", data: <String, dynamic>{"action": "start"}))?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        return true;
      } else {
        LoggerUtils.print("开始监听按键失败 $status");
      }
    }
    return false;
  }

  static bool keyListenerStop() {
    final Map<String, dynamic>? data =
        FactoryTestNativeApi().sendEvent(EventEntity("ft.key.set", data: <String, dynamic>{"action": "stop"}))?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        return true;
      } else {
        LoggerUtils.print("停止监听按键失败 $status");
      }
    }
    return false;
  }

  static void registerKeyActionCallback(void Function(Map<String, dynamic> data) callback) {
    FactoryTestNativeApi().registerEvent("ft.key.upload", callback);
  }

  static void unregisterKeyActionCallback(void Function(Map<String, dynamic> data) callback) {
    FactoryTestNativeApi().clearEvent("ft.key.upload");
  }

  static bool humitureListenerStart() {
    final Map<String, dynamic>? data = FactoryTestNativeApi()
        .sendEvent(EventEntity("ft.humiture.set", data: <String, dynamic>{"action": "start"}))
        ?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        return true;
      } else {
        LoggerUtils.print("开始监听温湿度失败 $status");
      }
    }
    return false;
  }

  static bool humitureListenerStop() {
    final Map<String, dynamic>? data = FactoryTestNativeApi()
        .sendEvent(EventEntity("ft.humiture.set", data: <String, dynamic>{"action": "stop"}))
        ?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        return true;
      } else {
        LoggerUtils.print("停止监听温湿度失败 $status");
      }
    }
    return false;
  }

  static ({int temperature, int humidity})? getHumiture() {
    final Map<String, dynamic>? data = FactoryTestNativeApi().readEvent(EventEntity("ft.humiture.get"))?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        final int temperature = data["temperature"];
        final int humidity = data["humidity"];
        return (temperature: temperature, humidity: humidity);
      } else {
        LoggerUtils.print("获取温湿度信息失败 $status");
      }
    }
    return null;
  }

  static int? getMotorVibrationFrequency() {
    final Map<String, dynamic>? data = FactoryTestNativeApi().readEvent(EventEntity("ft.motor.get"))?.data;
    if (data != null) {
      final int status = data["status"];
      if (status == 0) {
        final int vibration = data["vibration_frequency"];
        return vibration;
      } else {
        LoggerUtils.print("获取振动信息失败 $status");
      }
    }
    return null;
  }

  static int? getAgingTime() {
    try {
      final String secStr = File("/backup_data/aging_test_time.txt").readAsStringSync();
      final int? seconds = int.tryParse(secStr.trim());
      return seconds;
    } catch (e, s) {
      LoggerUtils.print("获取老化时间失败:$e\n$s");
    }
    return null;
  }

  static void reset() {
    FactoryTestNativeApi().reset();
  }
}
