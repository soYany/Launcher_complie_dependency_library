class EventEntity {
  EventEntity(this.event, {this.data});

  EventEntity.fromJson(Map<String, dynamic> json)
      : event = json['event'],
        data = json['data'];

  final String event;
  final dynamic data;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'event': event,
        'data': data ?? <String, dynamic>{},
      };
}

class FunctionEntity {
  FunctionEntity({required this.functionId, this.extra = const <String, dynamic>{}});

  FunctionEntity.fromJson(Map<String, dynamic> json)
      : functionId = json['function_id'],
        extra = Map<String, dynamic>.of(json)
          ..remove('function_id')
          ..remove('sort');

  final String functionId;
  final Map<String, dynamic> extra;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'function_id': functionId,
        ...extra,
      };
}

class VersionEntity {
  VersionEntity.fromJson(Map<String, dynamic> json)
      : launcher = json['launcher'],
        basicService = json['basicService'],
        core = json['core'],
        voiceAssistant = json['voiceAssistant'],
        kernel = json['kernel'];

  final String launcher;
  final String basicService;
  final String core;
  final String voiceAssistant;
  final String kernel;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'launcher': launcher,
        'basicService': basicService,
        'core': core,
        'voiceAssistant': voiceAssistant,
        'kernel': kernel,
      };
}

class DeviceInfoEntity {
  DeviceInfoEntity.fromJson(Map<String, dynamic> json)
      : versions = VersionEntity.fromJson(json['versions']),
        sn = json['sn'],
        deviceModel = json['deviceModel'],
        boardId = json['boardId'],
        modelId = json['modelId'],
        uuid = json['uuid'],
        wifiMac = json['wifiMac'],
        btMac = json['btMac'],
        storage = json['storage'],
        ncpVersion = json["ncp_verison"],
        bottomShellVersion = json["bottom_verison"] ??'';

  final VersionEntity versions;
  final String sn;
  final String deviceModel;
  final String boardId;
  final String modelId;
  final String uuid;
  final String wifiMac;
  final String btMac;
  final String storage;
  final String ncpVersion;
  final String bottomShellVersion;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'versions': versions,
        'sn': sn,
        'deviceModel': deviceModel,
        'boardId': boardId,
        'modelId': modelId,
        'uuid': uuid,
        'wifiMac': wifiMac,
        'btMac': btMac,
        'storage': storage,
        'ncp_verison': ncpVersion,
        'bottom_verison': bottomShellVersion,
      };

  Map<String, String> toResultMap() => <String, String>{
        "softversion": versions.core,
        "deviceModel": deviceModel,
        "boardId": boardId,
        "sn": sn,
        "uuid": uuid,
        "wifiMac": wifiMac,
        "blueToothMac": btMac,
        "ncp": ncpVersion,
        "bottomShell": bottomShellVersion,
      };
}

class WiFiInfoEntity {
  WiFiInfoEntity.fromJson(Map<String, dynamic> json)
      : ssid = json['ssid'],
        rssi = json['rssi'];

  final String ssid;
  final int rssi;

  bool get isEmpty => ssid.isEmpty;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'ssid': ssid,
        'rssi': rssi,
      };
}

class BluetoothInfoEntity {
  BluetoothInfoEntity.fromJson(Map<String, dynamic> json)
      : bestBtMac = json['bestBtMac'],
        bestBtRssi = json['bestBtRssi'],
        btCount = json['btCount'];

  final String bestBtMac;
  final int bestBtRssi;
  final int btCount;

  bool get isEmpty => bestBtMac.isEmpty;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'bestBtMac': bestBtMac,
        'bestBtRssi': bestBtRssi,
        'btCount': btCount,
      };
}
