import 'package:collection/collection.dart';
import 'package:factory_mode/widget/model_provider_widget.dart';
import 'package:flutter/material.dart';

enum TestProject {
  deviceInfo("deviceInfo"), //读取信息
  screen("screen"), //屏幕显示
  screenTouch("screenTouch"), //触摸
  bottomShell("bottomShell"), //底座
  wifi("wifi"), //wifi
  bluetooth("bluetooth"), //蓝牙
  humiture("humiture"), //温湿度
  audio("audio"), //声音
  microphone("microphone"), //麦克风
  zigbee("zigbee"), //zigbee
  motor("motor"),
  key("key"); //按键

  const TestProject(this.value);

  final String value;

  static TestProject? fromString(String value) {
    return TestProject.values.firstWhereOrNull((TestProject e) => e.value == value);
  }
}

extension TestProjectName on TestProject {
  String getProjectName(BuildContext context) {
    return switch (this) {
      TestProject.deviceInfo => "产品信息",
      TestProject.screen => "显示屏",
      TestProject.screenTouch => "触摸屏",
      TestProject.bottomShell => "底座",
      TestProject.wifi => "WiFi",
      TestProject.bluetooth => "蓝牙",
      TestProject.humiture => "温湿度",
      TestProject.audio => "音频",
      TestProject.microphone => "麦克风",
      TestProject.zigbee => "Zigbee",
      TestProject.key => ModelProviderWidget.isGauss(context) ? "按键旋钮" : "按键",
      TestProject.motor => "马达",
    };
  }
}

enum TestMode {
  pcba,
  all,
}

enum TestResult {
  pass(0, "PASS"),
  fail(1, "NG"),
  untested(-1, "未测试");

  const TestResult(this.value, this.text);

  final int value;
  final String text;
}

enum StateResult {
  pass(Colors.green),
  fail(Colors.red),
  ordinary(Colors.blue),
  none(Colors.white);

  const StateResult(this.color);

  bool get isNormalState => this == StateResult.ordinary || this == StateResult.none;

  bool get isPass => this == StateResult.pass;

  bool get isFail => this == StateResult.fail;

  final Color color;
}
