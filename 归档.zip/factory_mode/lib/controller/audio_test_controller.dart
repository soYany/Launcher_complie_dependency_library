import 'package:factory_mode/api/factory_test_api.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:get/get.dart';

class AudioTestController extends BaseTestController {
  @override
  TestProject get project => TestProject.audio;

  Rx<StateResult> state = Rx<StateResult>(StateResult.ordinary);

  void audioPlay() {
    state.value = FactoryTestApi.audioPlay() ? StateResult.pass : StateResult.fail;
  }

  @override
  bool tested() {
    return state.value == StateResult.pass;
  }
}
