import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ScreenTestController extends BaseTestController {
  @override
  TestProject get project => TestProject.screen;

  static const List<Color> testColorList = <Color>[
    Colors.white,
    Colors.red,
    Colors.green,
    Colors.black,
    Colors.blue,
  ];

  final Rx<Color> currentColor = Rx<Color>(testColorList.first);

  void changeColor() {
    final int index = testColorList.indexOf(currentColor.value);
    if (index == testColorList.length - 1) {
      currentColor.value = testColorList.last;
    } else {
      currentColor.value = testColorList[index + 1];
    }
  }

  bool testFinish() {
    return currentColor.value == testColorList.last;
  }


  @override
  bool tested() {
    return currentColor.value == testColorList.last;
  }
}
