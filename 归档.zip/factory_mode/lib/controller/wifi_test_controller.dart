import 'package:factory_mode/api/factory_test_api.dart';
import 'package:factory_mode/config/factory_signal_config.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/entity/entitys.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:get/get.dart';

class WifiTestController extends BaseTestController with TimedExecution, FactorySignalConfig {
  @override
  TestProject get project => TestProject.wifi;

  bool get isFrequency5G => getExtraDataValue('frequency5G') == 1;

  @override
  void initState() {
    super.initState();
    FactoryTestApi.wifiScanStart();
  }

  @override
  void dispose() {
    FactoryTestApi.wifiScanStop();
    super.dispose();
  }

  final Rx<({WiFiInfoEntity? hz_2_4, WiFiInfoEntity? hz_5})?> wifiInfoNotifier =
      Rx<({WiFiInfoEntity? hz_2_4, WiFiInfoEntity? hz_5})?>(null);

  @override
  void setTestResult(TestResult result, {dynamic extraResult}) {
    final WiFiInfoEntity? hz_2_4 = wifiInfoNotifier.value?.hz_2_4;
    super.setTestResult(result,
        extraResult: <String, dynamic>{"result": result.value, "rssi": hz_2_4?.rssi, "report_ssid": hz_2_4?.ssid});
  }

  @override
  bool tested() {
    return isHz24tested() && isHz5tested();
  }

  bool isHz24tested() {
    final WiFiInfoEntity? hz24 = wifiInfoNotifier.value?.hz_2_4;
    return hz24 != null && (hz24.rssi >= factorySignalConfig.wifi24GThreshold);
  }

  bool isHz5tested() {
    final WiFiInfoEntity? hz5 = wifiInfoNotifier.value?.hz_5;
    return !isFrequency5G || (hz5 != null && hz5.rssi >= factorySignalConfig.wifi5GThreshold);
  }

  @override
  void timedExecution() {
    wifiInfoNotifier.value = FactoryTestApi.getWiFiInfo();
  }
}
