import 'package:factory_mode/api/factory_test_api.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:get/get.dart';

class BottomShellTestController extends BaseTestController {
  @override
  TestProject get project => TestProject.bottomShell;

  late Rx<StateResult?> sensor485 = Rx<StateResult?>(getExtraDataValue('sensor485') == 1 ? StateResult.ordinary : null);

  late Rx<BottomShellData?> bottomShell =
      Rx<BottomShellData?>((getExtraDataValue<int>('relayCount') ?? 0) > 0 ? BottomShellData() : null);

  void controllerBottomShell({int type = 3}) {
    final BottomShellData? data = bottomShell.value;
    if (data != null) {
      FactoryTestApi.controllerBottomShell(!data.isOn, type: type);
    }
  }

  @override
  void setTestResult(TestResult result, {dynamic extraResult}) {
    super.setTestResult(result, extraResult: <Map<String, dynamic>>[
      if (sensor485.value != null)
        <String, dynamic>{
          "testTag": 0,
          "testType": "sensor",
          "testName": "485Sensor",
          "result": result.value,
          "des": ""
        },
      ...List<Map<String, dynamic>>.generate(
        getExtraDataValue('relayCount') ?? 0,
        (int key) => <String, dynamic>{
          "testTag": 0,
          "testType": "relay",
          "testName": "relay${key + 1}",
          "result": result.value,
          "des": ""
        },
      ),
    ]);
  }

  @override
  void initState() {
    super.initState();
    FactoryTestApi.bottomShellListenerStart();
    FactoryTestApi.registerBottomShellCallback(bottomShellHandlerCallback);
  }

  void bottomShellHandlerCallback(int type, bool result) {
    final BottomShellData? bottomShellData = bottomShell.value;
    final StateResult? sensor485Data = sensor485.value;
    if (type == 2 && sensor485Data != null) {
      sensor485.value = result ? StateResult.pass : StateResult.fail;
      if (bottomShellData != null) {
        bottomShell.value = BottomShellData(
            isOn: result ? !bottomShellData.isOn : bottomShellData.isOn,
            stateResult: result ? StateResult.pass : StateResult.fail);
      }
    }
  }

  @override
  void dispose() {
    FactoryTestApi.bottomShellListenerStop();
    FactoryTestApi.unregisterBottomShellCallback(bottomShellHandlerCallback);
    super.dispose();
  }

  @override
  bool tested() {
    final bool isSensor485Pass = sensor485.value == null || sensor485.value == StateResult.pass;
    return isSensor485Pass;
  }
}

class BottomShellData {
  BottomShellData({this.isOn = false, this.stateResult = StateResult.ordinary});

  bool isOn;
  StateResult stateResult;
}
