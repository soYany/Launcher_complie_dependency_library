import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:get/get.dart';

class ScreenTouchTestController extends BaseTestController {
  @override
  TestProject get project => TestProject.screenTouch;

  final RxBool isAllTouched = RxBool(false);

  @override
  bool tested() {
    return isAllTouched.value;
  }
}
