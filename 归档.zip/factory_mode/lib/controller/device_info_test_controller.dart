import 'dart:async';

import 'package:factory_mode/api/factory_test_api.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/entity/entitys.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:get/get.dart';

class DeviceInfoTestController extends BaseTestController {
  @override
  TestProject get project => TestProject.deviceInfo;

  Timer? _timer;

  @override
  void initState() {
    deviceInfoNotifier.value = FactoryTestApi.getDeviceInfo();
    if(deviceInfoNotifier.value?.ncpVersion.isNotEmpty != true){
      _timer = Timer(const Duration(seconds: 3), () {
        deviceInfoNotifier.value = FactoryTestApi.getDeviceInfo();
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
  }

  final Rx<DeviceInfoEntity?> deviceInfoNotifier = Rx<DeviceInfoEntity?>(null);

  @override
  bool tested() {
    return deviceInfoNotifier.value?.btMac.isNotEmpty == true &&
        deviceInfoNotifier.value?.wifiMac.isNotEmpty == true &&
        deviceInfoNotifier.value?.uuid.isNotEmpty == true;
  }
}
