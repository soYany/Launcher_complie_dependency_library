import 'package:factory_mode/api/factory_test_api.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:get/get.dart';

class ZigbeeTestController extends BaseTestController {
  @override
  TestProject get project => TestProject.zigbee;

  //组网
  final Rx<StateResult> networkingState = Rx<StateResult>(StateResult.ordinary);

  //控制
  final Rx<StateResult> controlState = Rx<StateResult>(StateResult.ordinary);

  //解除
  final Rx<StateResult> relieveState = Rx<StateResult>(StateResult.ordinary);

  void sendNetworking() {
    if (networkingState.value == StateResult.ordinary || networkingState.value.isFail) {
      networkingState.value = StateResult.none;
      FactoryTestApi.zigbeeActionTest('addDevice', seconds: 22).then((bool value) {
        networkingState.value = value ? StateResult.pass : StateResult.fail;
      });
    }
  }

  void sendControl() {
    if (networkingState.value.isPass) {
      FactoryTestApi.zigbeeActionTest('ctrlDevice').then((bool value) {
        controlState.value = value ? StateResult.pass : StateResult.fail;
      });
    }
  }

  void sendRelieve() {
    if (networkingState.value.isPass) {
      FactoryTestApi.zigbeeActionTest('deleteDevice').then((bool value) {
        relieveState.value = value ? StateResult.pass : StateResult.fail;
      });
    }
  }

  @override
  bool tested() {
    return relieveState.value == StateResult.pass &&
        controlState.value == StateResult.pass &&
        relieveState.value == StateResult.pass;
  }
}
