import 'dart:collection';

import 'package:collection/collection.dart';
import 'package:factory_mode/api/factory_test_api.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:get/get.dart';

class KeyTestController extends BaseTestController {
  @override
  TestProject get project => TestProject.key;

  //旋钮按键
  late Rx<StateResult?> knobKeyState = Rx<StateResult?>(getExtraDataValue('knobEnable') == 1 ? defaultValue : null);

  //重启按键
  late Rx<StateResult?> restartKeyState =
      Rx<StateResult?>(getExtraDataValue('rebootKeyEnable') == 1 ? defaultValue : null);

  //按键
  late Map<int, Rx<StateResult>> keyMapState = Map<int, Rx<StateResult>>.fromEntries(
      List<MapEntry<int, Rx<StateResult>>>.generate(getExtraDataValue('keyCount') ?? 0,
          (int index) => MapEntry<int, Rx<StateResult>>(index, Rx<StateResult>(defaultValue))));

  final StateResult defaultValue = StateResult.none;

  //完成的按键
  HashSet<int> completeSet = HashSet<int>();

  @override
  void initState() {
    super.initState();
    Future<void>.delayed(const Duration(milliseconds: 1000), () {
      FactoryTestApi.keyListenerStart();
      FactoryTestApi.registerKeyActionCallback(callback);
    });
  }

  @override
  void dispose() {
    super.dispose();
    FactoryTestApi.keyListenerStop();
    FactoryTestApi.unregisterKeyActionCallback(callback);
  }

  int? firstDirection;
  int? firstPulses;

  void callback(Map<String, dynamic> data) {
    final int keyNo = data["keyNo"];
    if (keyNo == 10000) {
      final int direction = data['direction'];
      final int pulses = data['pulses'];
      if (firstDirection != direction) {
        firstDirection = direction;
        firstPulses = pulses;
      } else {
        final int? firstPulses = this.firstPulses;
        if (firstPulses != null) {
          final int diff = pulses - firstPulses;
          if (diff.abs() >= 2) {
            knobKeyState.value = StateResult.pass;
          }
        }
      }
    } else if (keyNo == 134) {
      restartKeyState.value = StateResult.pass;
    } else if (keyNo == 137) {
      restartKeyState.value = StateResult.pass;
    } else {
      completeSet.add(keyNo);
      keyMapState.forEach((int key, Rx<StateResult> value) {
        value.value = key < completeSet.length ? StateResult.pass : defaultValue;
      });
    }
  }

  @override
  void setTestResult(TestResult result, {dynamic extraResult}) {
    super.setTestResult(result, extraResult: <String, dynamic>{
      "touchKey": knobKeyState.value?.isPass == true ? 0 : 1,
      "rotateKey":
      keyMapState.values.firstWhereOrNull((Rx<StateResult> value) => !value.value.isPass) == null ? 0 : 1,
    });
  }

  @override
  bool tested() {
    final List<StateResult> list = <StateResult>[
      ...keyMapState.values.map((Rx<StateResult> valueNotifier) => valueNotifier.value),
    ];
    final StateResult? knobKeyStateValue = knobKeyState.value;
    final StateResult? restartKeyStateValue = restartKeyState.value;
    return (knobKeyStateValue == null || knobKeyStateValue.isPass == true) &&
        (restartKeyStateValue == null || restartKeyStateValue.isPass == true) &&
        (list.isEmpty || list.firstWhereOrNull((StateResult state) => state != StateResult.pass) == null);
  }
}
