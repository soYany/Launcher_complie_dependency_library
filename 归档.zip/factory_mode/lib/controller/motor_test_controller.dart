import 'package:factory_mode/api/factory_test_api.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/manager/test_project_manager.dart';
import 'package:get/get.dart';

class MotorTestController extends BaseTestController {
  @override
  TestProject get project => TestProject.motor;

  late Rx<({int? vibration, StateResult state})> state =
      Rx<({int? vibration, StateResult state})>((vibration: null, state: StateResult.none));

  bool isPass(int vibration) {
    const double normalValue = 1700;
    const double floatingValue = normalValue * 0.07;
    return vibration >= normalValue - floatingValue && vibration <= normalValue + floatingValue;
  }

  void setMotorVibration() {
    final int? vibration = FactoryTestApi.getMotorVibrationFrequency();
    if (vibration != null) {
      state.value = (vibration: vibration, state: isPass(vibration) ? StateResult.pass : StateResult.fail);
    } else {
      state.value = (vibration: null, state: StateResult.fail);
    }
  }

  void callback(Map<String, dynamic> data) {
    setMotorVibration();
  }

  @override
  void initState() {
    super.initState();
    Future<void>.delayed(const Duration(milliseconds: 200), () {
      FactoryTestApi.registerKeyActionCallback(callback);
      FactoryTestApi.keyListenerStart();
    });
  }

  @override
  void dispose() {
    super.dispose();
    FactoryTestApi.keyListenerStop();
    FactoryTestApi.unregisterKeyActionCallback(callback);
  }

  @override
  bool tested() {
    if (TestProjectManager.currentTestMode == TestMode.pcba) {
      return super.tested();
    }
    return state.value.state == StateResult.pass;
  }
}
