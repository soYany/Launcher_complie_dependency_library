import 'dart:async';

import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/factory_mode.dart';
import 'package:factory_mode/manager/test_project_manager.dart';
import 'package:factory_mode/utils/logger_utils.dart';
import 'package:get/get.dart';

abstract class BaseTestController {
  abstract final TestProject project;

  void initState() {}

  void dispose() {}

  void fail() {
    TestProjectManager.setTestProjectTested(project);
    setTestResult(TestResult.fail);
    next();
  }

  void next() {
    final List<TestProject> textProjectList = TestProjectManager.getTestProjectList();
    final int index = textProjectList.indexOf(project);
    if (index < textProjectList.length - 1) {
      TestProjectManager.currentTestProject = textProjectList[index + 1];
    } else {
      TestProjectManager.currentTestProject = null;
    }
  }

  void pass() {
    TestProjectManager.setTestProjectTested(project);
    setTestResult(TestResult.pass);
    next();
  }

  final RxBool _tested = RxBool(true);
  bool tested() => _tested.value;

  static T getController<T extends BaseTestController>(TestProject project) {
    return FactoryMode().config.controllerFactory(project) as T;
  }

  Map<String, dynamic> getExtraData() {
    return TestProjectManager.getExtraData(project);
  }

  T? getExtraDataValue<T>(String key) {
    final dynamic value = getExtraData()[key];
    if (value is T) {
      return value;
    }
    LoggerUtils.print("解析异常: $project-$key ${getExtraData()}");
    return null;
  }

  void setTestResult(TestResult result, {dynamic extraResult}) {
    FactoryMode().config.testResultManagerFactory().setTestResult(project, result, extraResult: extraResult);
  }
}

mixin TimedExecution on BaseTestController {
  int get secondsTime => 2;
  Timer? timer;

  bool get initStateSend => true;

  @override
  void initState() {
    super.initState();
    if (initStateSend) {
      timedExecution();
    }
    timer = Timer.periodic(Duration(seconds: secondsTime), (Timer timer) {
      timedExecution();
    });
  }

  @override
  void dispose() {
    super.dispose();
    timer?.cancel();
  }

  void timedExecution();
}
