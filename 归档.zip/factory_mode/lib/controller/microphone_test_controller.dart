import 'dart:async';

import 'package:factory_mode/api/factory_test_api.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:get/get.dart';

enum MicrophoneTestType {
  MIC,
  REF,
  PLAY,
  CONSISTENCY;
}

class MicrophoneTestResult {
  const MicrophoneTestResult({this.stateResult = StateResult.none, this.value});

  final StateResult stateResult;
  final int? value;
}

class MicrophoneTestProject {
  const MicrophoneTestProject({required this.index, required this.type});

  final int index;
  final MicrophoneTestType type;

  String getResultKey() {
    switch (type) {
      case MicrophoneTestType.MIC:
        return 'mic$index';
      case MicrophoneTestType.REF:
        return 'ref$index';
      case MicrophoneTestType.PLAY:
        return 'mic${index}Play';
      case MicrophoneTestType.CONSISTENCY:
        return "mic_consistency";
    }
  }

  String getSaveKey() {
    switch (type) {
      case MicrophoneTestType.MIC:
        return 'mic$index';
      case MicrophoneTestType.REF:
        return 'REF${index}_AEC';
      case MicrophoneTestType.PLAY:
        return 'mic$index';
      case MicrophoneTestType.CONSISTENCY:
        return "mic_consistency";
    }
  }
}

class MicrophoneTestController extends BaseTestController {
  @override
  TestProject get project => TestProject.microphone;

  int get refCount => getExtraDataValue('refCount') ?? 0;

  int get micCount => getExtraDataValue('micCount') ?? 0;

  ///为1表示需要子项测试，为0不需要
  int get subMicrophone => getExtraDataValue('subMicrophone') ?? 1;

  final RxMap<MicrophoneTestProject, MicrophoneTestResult> mapState =
      RxMap<MicrophoneTestProject, MicrophoneTestResult>();

  final Rx<StateResult?> soundValue = Rx<StateResult?>(null);

  MicrophoneTestProject? currentPlayKey;

  Duration get microphoneBaseTestTimeout => const Duration(seconds: 15);

  @override
  void initState() {
    super.initState();

    buildTestProjectMap();
    FactoryTestApi.microphoneBaseTest('microphone', timeout: microphoneBaseTestTimeout)
        .then((Map<String, dynamic>? map) {
      microphoneBaseTestResultHandler(map);
    });
  }

  void buildTestProjectMap() {
    for (int i = 1; i <= refCount; i++) {
      mapState[MicrophoneTestProject(index: i, type: MicrophoneTestType.REF)] = const MicrophoneTestResult();
    }
    for (int i = 1; i <= micCount; i++) {
      mapState[MicrophoneTestProject(index: i, type: MicrophoneTestType.MIC)] = const MicrophoneTestResult();
      mapState[MicrophoneTestProject(index: i, type: MicrophoneTestType.PLAY)] = const MicrophoneTestResult();
    }
  }

  void microphoneBaseTestResultHandler(Map<String, dynamic>? map) {
    final Map<MicrophoneTestProject, MicrophoneTestResult> resultMap = <MicrophoneTestProject, MicrophoneTestResult>{};
    mapState.forEach((MicrophoneTestProject key, MicrophoneTestResult value) {
      final StateResult stateResult = map?[key.getResultKey()] == 'pass' ? StateResult.pass : StateResult.fail;
      final int? value;
      if (key.type == MicrophoneTestType.CONSISTENCY) {
        value = map?["mic_diff"];
      } else {
        value = map?["${key.getResultKey()}_val"];
      }
      resultMap[key] = MicrophoneTestResult(stateResult: stateResult, value: value);
    });
    mapState.assignAll(resultMap);

    final List<StateResult> baseResultList = mapState.entries
        .where((MapEntry<MicrophoneTestProject, MicrophoneTestResult> element) =>
            element.key.type == MicrophoneTestType.MIC ||
            element.key.type == MicrophoneTestType.REF ||
            element.key.type == MicrophoneTestType.CONSISTENCY)
        .map((MapEntry<MicrophoneTestProject, MicrophoneTestResult> e) => e.value.stateResult)
        .toList();

    if (baseResultList.isNotEmpty && baseResultList.every((StateResult state) => state == StateResult.pass)) {
      if (subMicrophone == 1) {
        recordSound();
      }
    }
  }

  Future<void> recordSound() async {
    soundValue.value = StateResult.ordinary;
    final bool result = await FactoryTestApi.microphoneActionTest('recording');
    if (result) {
      soundValue.value = StateResult.pass;
      unawaited(playSound());
    } else {
      soundValue.value = StateResult.fail;
    }
  }

  Future<bool> playSound() async {
    final List<MicrophoneTestProject> playProjectList =
        mapState.keys.where((MicrophoneTestProject element) => element.type == MicrophoneTestType.PLAY).toList();
    for (final MicrophoneTestProject item in playProjectList) {
      currentPlayKey = item;
      mapState[item] = const MicrophoneTestResult(stateResult: StateResult.ordinary);
      final bool result = await FactoryTestApi.microphoneActionTest(item.getResultKey());
      mapState[item] = MicrophoneTestResult(stateResult: result ? StateResult.pass : StateResult.fail);
    }
    return false;
  }

  @override
  void setTestResult(TestResult result, {dynamic extraResult}) {
    final bool isPass = result == TestResult.pass;
    final Map<String, int> resultMap = <String, int>{};
    for (final MapEntry<MicrophoneTestProject, MicrophoneTestResult> entity in mapState.entries) {
      final int entityResult = isPass ? 0 : (entity.value.stateResult.isPass ? 0 : 1);
      if (resultMap.containsKey(entity.key.getSaveKey())) {
        resultMap[entity.key.getSaveKey()] = resultMap[entity.key.getSaveKey()]! | entityResult;
      } else {
        resultMap[entity.key.getSaveKey()] = entityResult;
      }
    }
    resultMap["AEC"] = isPass ? 0 : 1;
    super.setTestResult(result, extraResult: resultMap);
  }

  @override
  bool tested() {
    if (subMicrophone == 1) {
      return mapState.entries
          .where((MapEntry<MicrophoneTestProject, MicrophoneTestResult> element) =>
              element.key.type == MicrophoneTestType.PLAY)
          .every((MapEntry<MicrophoneTestProject, MicrophoneTestResult> element) => element.value.stateResult.isPass);
    } else {
      return mapState.entries
          .where((MapEntry<MicrophoneTestProject, MicrophoneTestResult> element) =>
              element.key.type == MicrophoneTestType.MIC ||
              element.key.type == MicrophoneTestType.REF ||
              element.key.type == MicrophoneTestType.CONSISTENCY)
          .every((MapEntry<MicrophoneTestProject, MicrophoneTestResult> element) => element.value.stateResult.isPass);
    }
  }
}

class MicrophoneState {
  MicrophoneState(this.index, {this.stateResult = StateResult.none, this.micPlayResult});

  StateResult stateResult;
  StateResult? micPlayResult;
  int index;

  bool get isMic => micPlayResult != null;
}
