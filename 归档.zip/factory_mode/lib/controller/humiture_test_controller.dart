import 'package:factory_mode/api/factory_test_api.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:get/get.dart';

class HumitureTestController extends BaseTestController with TimedExecution {
  @override
  TestProject get project => TestProject.humiture;

  final Rx<({int? temperature, int? humidity})?> value = Rx<({int? temperature, int? humidity})?>(null);

  @override
  void setTestResult(TestResult result, {dynamic extraResult}) {
    super.setTestResult(result, extraResult: <String, dynamic>{
      "result": result.value,
      "temp": "${value.value?.temperature}",
      "hum": "${value.value?.humidity}"
    });
  }

  @override
  void initState() {
    super.initState();
    FactoryTestApi.humitureListenerStart();
  }

  @override
  void dispose() {
    FactoryTestApi.humitureListenerStop();
    super.dispose();
  }

  @override
  bool tested() {
    return value.value?.temperature != null && value.value?.humidity != null;
  }

  @override
  void timedExecution() {
    value.value = FactoryTestApi.getHumiture();
  }
}
