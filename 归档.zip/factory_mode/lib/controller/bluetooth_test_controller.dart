import 'package:factory_mode/api/factory_test_api.dart';
import 'package:factory_mode/config/factory_signal_config.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/entity/entitys.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:get/get.dart';

class BluetoothTestController extends BaseTestController with TimedExecution, FactorySignalConfig {
  @override
  TestProject get project => TestProject.bluetooth;

  Rx<int> scanCount = Rx<int>(0);

  Rx<BluetoothInfoEntity?> bluetoothInfoNotifier = Rx<BluetoothInfoEntity?>(null);

  @override
  void setTestResult(TestResult result, {dynamic extraResult}) {
    super.setTestResult(result, extraResult: <String, dynamic>{
      'result': result.value,
      'rssi': bluetoothInfoNotifier.value?.bestBtRssi,
    });
  }

  @override
  void initState() {
    super.initState();
    FactoryTestApi.bluetoothScanStart();
  }

  @override
  void dispose() {
    FactoryTestApi.bluetoothScanStop();
    super.dispose();
  }

  @override
  bool tested() {
    final BluetoothInfoEntity? infoEntity = bluetoothInfoNotifier.value;
    return infoEntity != null && (infoEntity.bestBtRssi >= factorySignalConfig.btThreshold);
  }

  @override
  void timedExecution() {
    scanCount.value++;
    bluetoothInfoNotifier.value = FactoryTestApi.getBluetoothInfo();
  }
}
