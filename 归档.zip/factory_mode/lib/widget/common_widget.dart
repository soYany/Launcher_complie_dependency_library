import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/ui/gauss/widgets/test_project_common_widget.dart';
import 'package:flutter/material.dart';

class CommonListWidget extends StatelessWidget {
  const CommonListWidget({required this.children, required this.baseTestController, this.title, super.key});

  final BaseTestController baseTestController;
  final String? title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          if (title != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 15),
              child: TitleWidget(title: title ?? ''),
            ),
          Container(
            constraints: BoxConstraints(minHeight: 105 + (title != null ? 0 : 79)),
            child: Column(children: children),
          ),
          TestProjectCommonWidget(controller: baseTestController),
        ],
      ),
    );
  }
}

class TitleWidget extends StatelessWidget {
  const TitleWidget({required this.title, super.key, this.padding});

  final String title;
  final EdgeInsetsGeometry? padding;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding ?? const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 24,
          color: Colors.white,
        ),
      ),
    );
  }
}

class CommonTextBox extends StatelessWidget {
  const CommonTextBox(
      {required this.title, super.key, this.bgColor, this.textColor, this.padding, this.margin, this.width});

  final String title;
  final Color? bgColor;
  final Color? textColor;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final double? width;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      margin: margin,
      decoration: BoxDecoration(
        border: Border.all(color: bgColor ?? Colors.white, width: 0),
        color: bgColor ?? Colors.white,
      ),
      padding: padding ?? const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
      child: Text(
        title,
        textAlign: TextAlign.center,
        style: TextStyle(
          fontSize: 24,
          color: textColor ?? Colors.black,
        ),
      ),
    );
  }
}
