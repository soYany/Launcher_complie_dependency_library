import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/factory_mode.dart';
import 'package:factory_mode/manager/test_project_manager.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class FactoryModeHome extends StatelessWidget {
  const FactoryModeHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final TestMode? currentTestMode = TestProjectManager.currentTestMode;
      final bool isLoadHistoryResult = TestProjectManager.loadHistoryResultMode;
      final TestProject? currentTestProject = TestProjectManager.currentTestProject;
      if (currentTestMode == null) {
        return FactoryMode().config.mainPageBuilder(context);
      } else if (currentTestProject == null) {
        if (TestProjectManager.isTested() || isLoadHistoryResult) {
          return FactoryMode().config.testResultBuilder(context);
        } else {
          return FactoryMode().config.testProjectListPageBuilder(context, currentTestMode);
        }
      } else {
        return FactoryMode().config.testProjectPageBuilder(context, currentTestProject);
      }
    });
  }
}
