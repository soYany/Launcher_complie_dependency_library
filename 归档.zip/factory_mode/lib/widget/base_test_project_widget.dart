import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:flutter/material.dart';

abstract class BaseTestProjectWidget<C extends BaseTestController> extends StatefulWidget {
  const BaseTestProjectWidget({required this.controller, super.key});

  final C controller;

  @override
  BaseTestProjectWidgetState<C, BaseTestProjectWidget<C>> createState();
}

abstract class BaseTestProjectWidgetState<C extends BaseTestController, T extends BaseTestProjectWidget<C>>
    extends State<T> {
  @override
  void initState() {
    super.initState();
    widget.controller.initState();
  }

  @override
  void dispose() {
    widget.controller.dispose();
    super.dispose();
  }
}
