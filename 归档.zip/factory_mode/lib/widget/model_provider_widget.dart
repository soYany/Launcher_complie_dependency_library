import 'package:flutter/material.dart';

class ModelProviderWidget extends InheritedWidget {
  const ModelProviderWidget({
    required super.child,
    required this.model,
    super.key,
  });

  final String model;

  static String getModel(BuildContext context) {
    final ModelProviderWidget? result = context.dependOnInheritedWidgetOfExactType<ModelProviderWidget>();
    assert(result != null, 'No ModelProvider found in context');
    return result!.model;
  }

  static bool isGauss(BuildContext context) {
    return getModel(context) == 'MixPadGauss';
  }

  @override
  bool updateShouldNotify(ModelProviderWidget oldWidget) {
    return oldWidget.model != model;
  }
}
