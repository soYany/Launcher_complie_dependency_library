import 'package:factory_mode/api/factory_test_api.dart';
import 'package:factory_mode/entity/entitys.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/factory_mode.dart';
import 'package:factory_mode/manager/test_project_manager.dart';
import 'package:factory_mode/utils/logger_utils.dart';
import 'package:flutter/material.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  DeviceInfoEntity? deviceInfo;
  String? agingTime;

  static bool isFirst = true;
  bool isLoaded = false;

  @override
  void initState() {
    super.initState();
    if (isFirst) {
      isFirst = false;
      Future<void>.delayed(const Duration(seconds: 1), () {
        loadData();
      });
    } else {
      loadData();
    }
  }

  void loadData() {
    final List<FunctionEntity>? data = FactoryTestApi.getAllTestProjectList();
    final DeviceInfoEntity? deviceInfo = FactoryTestApi.getDeviceInfo();
    this.deviceInfo = deviceInfo;
    if (deviceInfo != null) {
      FactoryMode().config.testResultManagerFactory().setDeviceInfo(deviceInfo);
    }
    final int? seconds = FactoryTestApi.getAgingTime();
    if (seconds != null) {
      final int hours = seconds ~/ 3600;
      final int minutes = (seconds % 3600) ~/ 60;
      final int secs = seconds % 60;

      // Format hours, minutes, and seconds to two digits
      final String hoursStr = hours.toString().padLeft(2, '0');
      final String minutesStr = minutes.toString().padLeft(2, '0');
      final String secondsStr = secs.toString().padLeft(2, '0');
      agingTime = '$hoursStr:$minutesStr:$secondsStr';
    }
    if (data != null) {
      TestProjectManager.setAllTestFunction(data);
      if (mounted) {
        setState(() {
          isLoaded = true;
        });
      }
    } else {
      LoggerUtils.print("获取测试项目失败");
    }
  }

  @override
  Widget build(BuildContext context) {
    return isLoaded
        ? Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text("${deviceInfo?.deviceModel}"),
              const SizedBox(height: 30),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  SizedBox(
                    width: 102,
                    height: 66,
                    child: TextButton(
                      onPressed: () {
                        TestProjectManager.currentTestMode = TestMode.pcba;
                        TestProjectManager.setTestProjectList(TestProjectManager.getAllTestProject()
                            .where(FactoryMode().config.testResultManagerFactory().pcbaTestProjectList.contains)
                            .toList());
                      },
                      child: const Text("PCBA"),
                    ),
                  ),
                  const SizedBox(width: 34),
                  SizedBox(
                    width: 102,
                    height: 66,
                    child: TextButton(
                      onPressed: () {
                        TestProjectManager.currentTestMode = TestMode.all;
                        TestProjectManager.setTestProjectList(TestProjectManager.getAllTestProject());
                      },
                      child: const Text("整机"),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 30),
              Text(
                agingTime == null ? "" : "老化时间：$agingTime",
                style: const TextStyle(fontSize: 24, color: Colors.white),
              ),
            ],
          )
        : Container(
            color: Colors.black,
            alignment: Alignment.center,
            child: const Text("加载中"),
          );
  }
}
