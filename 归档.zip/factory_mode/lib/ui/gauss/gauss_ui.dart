import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/factory_mode.dart';
import 'package:factory_mode/ui/gauss/main_page.dart';
import 'package:factory_mode/ui/gauss/manager/gauss_test_result_manager.dart';
import 'package:factory_mode/ui/gauss/projects/audio_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/bluetooth_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/bottom_shell_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/device_info_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/humiture_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/key_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/microphone_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/motor_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/screen_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/screen_touch_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/wifi_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/zigbee_test_page.dart';
import 'package:factory_mode/ui/gauss/result_page.dart';
import 'package:factory_mode/ui/gauss/styles.dart';
import 'package:factory_mode/ui/gauss/test_project_list_page.dart';
import 'package:factory_mode/widget/factory_mode_home.dart';
import 'package:flutter/material.dart';

class GaussFactoryMode extends StatefulWidget {
  const GaussFactoryMode({super.key});

  @override
  State<GaussFactoryMode> createState() => _GaussFactoryModeState();
}

class _GaussFactoryModeState extends State<GaussFactoryMode> {
  @override
  void initState() {
    super.initState();
    FactoryMode().config = FactoryMode().config.copyWith(
        mainPageBuilder: (BuildContext context) => const MainPage(),
        testProjectListPageBuilder: (BuildContext context, TestMode mode) {
          return TestProjectListPage(mode: mode);
        },
        testProjectPageBuilder: (BuildContext context, TestProject project) {
          return switch (project) {
            TestProject.deviceInfo => DeviceInfoTestPage(),
            TestProject.screen => ScreenTestPage(),
            TestProject.wifi => WifiTestPage(),
            TestProject.screenTouch => ScreenTouchTestPage(),
            TestProject.bottomShell => BottomShellTestPage(),
            TestProject.bluetooth => BluetoothTestPage(),
            TestProject.audio => AudioTestPage(),
            TestProject.zigbee => ZigbeeTestPage(),
            TestProject.key => KeyTestPage(),
            TestProject.humiture => HumitureTestPage(),
            TestProject.microphone => MicrophoneTestPage(),
            TestProject.motor => MotorTestPage(),
          };
        },
        testResultManagerFactory: () {
          return GaussTestResultManager();
        },
        testResultBuilder: (BuildContext context) {
          return const ResultPage();
        });
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      child: DefaultTextStyle(
        style: GaussStyles.defaultTextStyle,
        child: TextButtonTheme(
          data: TextButtonThemeData(style: GaussStyles.defaultButtonStyle),
          child: const ColoredBox(color: Colors.black, child: FactoryModeHome()),
        ),
      ),
    );
  }
}
