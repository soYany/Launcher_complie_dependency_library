import 'package:factory_mode/api/factory_test_api.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/factory_mode.dart';
import 'package:factory_mode/manager/test_project_manager.dart';
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

class ResultPage extends StatefulWidget {
  const ResultPage({super.key});

  @override
  State<ResultPage> createState() => _ResultPageState();
}

class _ResultPageState extends State<ResultPage> {
  bool isShowTips = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final TestMode currentMode = TestProjectManager.currentTestMode ?? TestMode.all;
    return isShowTips
        ? ResultTipsPage(mode: currentMode)
        : Column(
            children: <Widget>[
              const SizedBox(height: 20),
              const Text("测试结果", style: TextStyle(fontSize: 24)),
              const SizedBox(height: 18),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: <Widget>[
                      if (currentMode == TestMode.all)
                        Container(
                          width: 200,
                          height: 200,
                          margin: const EdgeInsets.only(bottom: 18),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child:
                              QrImage(data: FactoryMode().config.testResultManagerFactory().getQrCodeData(), size: 200),
                        ),
                      SizedBox(
                        width: 280,
                        child: DefaultTextStyle(
                          style: const TextStyle(fontSize: 19),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: TestProjectManager.getTestProjectList().map<Widget>((TestProject project) {
                              final ({TestResult result, String? failReason}) e =
                                  FactoryMode().config.testResultManagerFactory().getTestResult(project);
                              final String failReason = e.failReason == null ? "" : "(${e.failReason})";
                              final Color color = switch (e.result) {
                                TestResult.pass => const Color(0xFF0EA70B),
                                TestResult.fail => const Color(0xFFDF1D1D),
                                TestResult.untested => Colors.white,
                              };
                              return Text(
                                "${project.getProjectName(context)}: ${e.result.text} $failReason",
                                style: TextStyle(color: color),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      SizedBox(
                        width: 148,
                        height: 66,
                        child: TextButton(
                          onPressed: () {
                            setState(() {
                              isShowTips = true;
                            });
                          },
                          child: const Text(
                            "测试完成",
                            style: TextStyle(color: Colors.black, fontSize: 32),
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      SizedBox(
                        width: 68,
                        height: 68,
                        child: TextButton(
                          onPressed: () {
                            TestProjectManager.loadHistoryResultMode = false;
                            TestProjectManager.resetTestProjectState();
                          },
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(const Color(0xFF1F1F1F)),
                            shape: MaterialStateProperty.all<OutlinedBorder>(const CircleBorder()),
                          ),
                          child: Image.asset("assets/menu.webp", package: "factory_mode"),
                        ),
                      ),
                      const SizedBox(height: 77),
                    ],
                  ),
                ),
              ),
            ],
          );
  }
}

class ResultTipsPage extends StatefulWidget {
  const ResultTipsPage({required this.mode, super.key});

  final TestMode mode;

  @override
  State<ResultTipsPage> createState() => _ResultTipsPageState();
}

class _ResultTipsPageState extends State<ResultTipsPage> {
  @override
  Widget build(BuildContext context) {
    return widget.mode == TestMode.pcba
        ? Stack(
            alignment: Alignment.center,
            children: <Widget>[
              const Text(
                "测试完成，请断电",
                style: TextStyle(fontSize: 24, color: Colors.white),
              ),
              Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 20),
                    child: SizedBox(
                      width: 68,
                      height: 68,
                      child: TextButton(
                        onPressed: () {
                          TestProjectManager.resetTestProject();
                          TestProjectManager.loadHistoryResultMode = false;
                        },
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(const Color(0xFF1F1F1F)),
                          shape: MaterialStateProperty.all<OutlinedBorder>(const CircleBorder()),
                        ),
                        child: Image.asset("assets/back.webp", package: "factory_mode"),
                      ),
                    ),
                  ))
            ],
          )
        : Container(
            alignment: Alignment.center,
            child: SizedBox(
              width: 236,
              height: 82,
              child: TextButton(
                onPressed: () {
                  FactoryTestApi.reset();
                },
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(const Color(0xFF00AAFF)),
                ),
                child: const Text("恢复出厂设置", style: TextStyle(fontSize: 24, color: Colors.black)),
              ),
            ),
          );
  }
}
