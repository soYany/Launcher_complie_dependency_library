import 'package:collection/collection.dart';
import 'package:factory_mode/config/ui.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/factory_mode.dart';
import 'package:factory_mode/manager/test_project_manager.dart';
import 'package:factory_mode/utils/logger_utils.dart';
import 'package:flutter/material.dart';

class TestProjectListPage extends StatefulWidget {
  const TestProjectListPage({required this.mode, super.key});

  final TestMode mode;

  @override
  State<TestProjectListPage> createState() => _TestProjectListPageState();
}

class _TestProjectListPageState extends State<TestProjectListPage> {
  @override
  void initState() {
    super.initState();
    FactoryMode().config.testResultManagerFactory().loadFactoryResult(widget.mode);
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: <Widget>[
          SizedBox(height: 36.aw),
          Wrap(
            runSpacing: 20.aw,
            spacing: 16.aw,
            alignment: WrapAlignment.center,
            children: TestProjectManager.getTestProjectList().mapIndexed((int index, TestProject project) {
              final Widget child = SizedBox(
                width: 130.aw,
                height: 42.ah,
                child: TextButton(
                  onPressed: () {
                    TestProjectManager.currentTestProject = project;
                  },
                  child: Text(project.getProjectName(context)),
                ),
              );
              if (index == 0) {
                return Padding(padding: EdgeInsets.symmetric(horizontal: 80.aw), child: child);
              } else {
                return child;
              }
            }).toList(),
          ),
          SizedBox(height: 18.ah),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              SizedBox(
                width: 68.aw,
                height: 68.ah,
                child: TextButton(
                  onPressed: () {
                    TestProjectManager.resetTestProject();
                  },
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(const Color(0x1FFFFFFF)),
                    shape: MaterialStateProperty.all<OutlinedBorder>(const CircleBorder()),
                  ),
                  child: Image.asset("assets/back.webp", package: "factory_mode"),
                ),
              ),
              SizedBox(width: 14.aw),
              SizedBox(
                width: 115.aw,
                height: 66.ah,
                child: TextButton(
                  onPressed: () {
                    LoggerUtils.print("点击START按钮");
                    TestProjectManager.currentTestProject = TestProjectManager.getTestProjectList().first;
                  },
                  onLongPress: () {
                    LoggerUtils.print("长按START按钮");
                    TestProjectManager.loadHistoryResultMode = true;
                  },
                  style: ButtonStyle(
                    padding: MaterialStateProperty.all<EdgeInsetsGeometry>(EdgeInsets.zero),
                    backgroundColor: MaterialStateProperty.all<Color>(Colors.red),
                  ),
                  child: Text(
                    "START",
                    style: TextStyle(fontSize: 32.asp),
                  ),
                ),
              ),
              SizedBox(width: 82.aw),
            ],
          ),
          SizedBox(height: 77.ah),
        ],
      ),
    );
  }
}
