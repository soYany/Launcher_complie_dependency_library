import 'dart:async';
import 'dart:math' as math;

import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/controller/screen_touch_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/ui/gauss/widgets/test_project_common_widget.dart';
import 'package:factory_mode/widget/base_test_project_widget.dart';
import 'package:flutter/material.dart';

class ScreenTouchTestPage extends BaseTestProjectWidget<ScreenTouchTestController> {
  ScreenTouchTestPage({super.key}) : super(controller: BaseTestController.getController(TestProject.screenTouch));

  @override
  BaseTestProjectWidgetState<ScreenTouchTestController, ScreenTouchTestPage> createState() {
    return ScreenTouchTestState();
  }
}

class ScreenTouchTestState extends BaseTestProjectWidgetState<ScreenTouchTestController, ScreenTouchTestPage> {
  late TouchTestController crossTouchTestController;
  late TouchTestController circleTouchTestController;

  bool isShowButton = false;

  Timer? timer;

  @override
  void initState() {
    super.initState();
    crossTouchTestController = TouchTestController();
    circleTouchTestController = TouchTestController();
    timer = Timer(const Duration(seconds: 5), () {
      if (mounted) {
        setState(() {
          isShowButton = true;
        });
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (PointerDownEvent event) {
        _onPointer(event.localPosition);
      },
      onPointerMove: (PointerMoveEvent event) {
        _onPointer(event.localPosition);
      },
      onPointerUp: (PointerUpEvent event) {
        _onPointer(event.localPosition);
      },
      child: Stack(fit: StackFit.expand, children: <Widget>[
        Center(
            child:
                CrossShapeTouchTestWidget(width: 320, height: 320, cellSize: 35, controller: crossTouchTestController)),
        CircleTouchTestWidget(segmentCount: 30, thickness: 35, size: 360, controller: circleTouchTestController),
        if (isShowButton)
          Align(
            alignment: Alignment.bottomCenter,
            child: TestProjectCommonWidget(controller: widget.controller),
          )
      ]),
    );
  }

  void _onPointer(Offset position) {
    crossTouchTestController.sendPointer(position.translate(-20, -20));
    circleTouchTestController.sendPointer(position);
    final bool isAllTouched = crossTouchTestController.isTouched() && circleTouchTestController.isTouched();
    if (isAllTouched != widget.controller.isAllTouched.value) {
      widget.controller.isAllTouched.value = isAllTouched;
      setState(() {});
    }
  }
}

class TouchTestController {
  TouchTestController();

  void sendPointer(Offset pointer) {
    _onPointer?.call(pointer);
  }

  bool isTouched() {
    return _onTouched?.call() ?? false;
  }

  bool Function()? _onTouched;

  void Function(Offset)? _onPointer;
}

class CircleTouchTestWidget extends StatefulWidget {
  const CircleTouchTestWidget({
    required this.size,
    required this.segmentCount,
    required this.thickness,
    super.key,
    this.controller,
  });

  final int segmentCount;
  final double thickness;
  final double size;
  final TouchTestController? controller;

  @override
  _CircleTouchTestWidgetState createState() => _CircleTouchTestWidgetState();
}

class _CircleTouchTestWidgetState extends State<CircleTouchTestWidget> {
  late List<bool> touched;

  @override
  void initState() {
    super.initState();
    touched = List<bool>.generate(widget.segmentCount, (_) => false); // 根据分段数量初始化
    widget.controller?._onPointer = (Offset position) {
      _handleTouch(position, widget.size);
    };
    widget.controller?._onTouched = () {
      return touched.every((bool element) => element);
    };
  }

  @override
  void dispose() {
    widget.controller?._onPointer = null;
    widget.controller?._onTouched = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      isComplex: true,
      size: Size(widget.size, widget.size),
      painter: CircleSegmentPainter(touched, widget.segmentCount, widget.thickness, widget.size),
    );
  }

  void _handleTouch(Offset position, double screenSize) {
    final double radius = screenSize / 2;
    final Offset center = Offset(radius, radius);
    final double dx = position.dx - center.dx;
    final double dy = position.dy - center.dy;
    final double distance = math.sqrt(dx * dx + dy * dy);
    final double angle = (math.atan2(dy, dx) + math.pi * 2) % (math.pi * 2);

    if (distance >= radius - widget.thickness && distance <= radius + widget.thickness) {
      // 确保触摸在圆环内
      final int touchedIndex = (angle / (2 * math.pi / widget.segmentCount)).floor();
      if (!touched[touchedIndex]) {
        setState(() {
          touched[touchedIndex] = true;
        });
      }
    }
  }
}

class CircleSegmentPainter extends CustomPainter {
  CircleSegmentPainter(this.touched, this.segmentCount, this.thickness, this.size);

  final List<bool> touched;
  final double size;
  final int segmentCount;
  final double thickness;

  @override
  void paint(Canvas canvas, Size size) {
    final double radius = this.size / 2;
    final Offset center = Offset(radius, radius);
    final Paint paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = thickness;

    final double sweepAngle = 2 * math.pi / segmentCount;

    for (int i = 0; i < segmentCount; i++) {
      final double startAngle = i * sweepAngle;
      //绘制黑色底色
      paint.color = Colors.black;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius - thickness / 2),
        startAngle,
        sweepAngle,
        false,
        paint,
      );
      paint.color = touched[i] ? Colors.green : Colors.grey;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius - thickness / 2),
        startAngle + 0.005,
        sweepAngle - 0.005,
        false,
        paint,
      );
    }
  }

  @override
  bool hitTest(Offset position) {
    return true;
  }

  @override
  bool shouldRepaint(CircleSegmentPainter oldDelegate) {
    return true;
  }
}

class CrossShapeTouchTestWidget extends StatefulWidget {
  const CrossShapeTouchTestWidget(
      {required this.cellSize, required this.width, required this.height, super.key, this.controller});

  final double width;
  final double height;
  final double cellSize;
  final TouchTestController? controller;

  @override
  _CrossShapeTouchTestWidgetState createState() => _CrossShapeTouchTestWidgetState();
}

class _CrossShapeTouchTestWidgetState extends State<CrossShapeTouchTestWidget> {
  List<_CrossBox> boxes = <_CrossBox>[];

  @override
  void initState() {
    super.initState();
    widget.controller?._onPointer = (Offset position) {
      _handleTouch(position);
    };

    widget.controller?._onTouched = () {
      return boxes.every((_CrossBox element) => element.state1 && element.state2);
    };
    buildCells();
  }

  void buildCells() {
    boxes.clear();
    final int horizontalNum = widget.width ~/ widget.cellSize;
    final double horizontalStartX = (widget.width - horizontalNum * widget.cellSize) / 2;
    final double horizontalStartY = (widget.height - widget.cellSize) / 2;

    final int verticalNum = widget.height ~/ widget.cellSize;
    final double verticalStartX = (widget.width - widget.cellSize) / 2;
    final double verticalStartY = (widget.height - verticalNum * widget.cellSize) / 2;

    for (int i = 0; i < horizontalNum; i++) {
      final double x = horizontalStartX + i * widget.cellSize;
      final Rect cellRect = Rect.fromLTWH(x, horizontalStartY, widget.cellSize, widget.cellSize);
      boxes.add(_CrossBox(rect: cellRect, state1: false, state2: false));
    }

    for (int i = 0; i < verticalNum; i++) {
      final double y = verticalStartY + i * widget.cellSize;
      final Rect cellRect = Rect.fromLTWH(verticalStartX, y, widget.cellSize, widget.cellSize);
      boxes.add(_CrossBox(rect: cellRect, state1: false, state2: false));
    }
  }

  @override
  void dispose() {
    widget.controller?._onPointer = null;
    widget.controller?._onTouched = null;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      isComplex: true,
      size: Size(widget.width, widget.height),
      painter: CrossGridPainter(boxes),
    );
  }

  void _handleTouch(Offset position) {
    //先将point旋转-45度
    final Offset newPoint = Offset(
      (position.dx - widget.width / 2) * math.cos(-math.pi / 4) -
          (position.dy - widget.height / 2) * math.sin(-math.pi / 4) +
          widget.width / 2,
      (position.dx - widget.width / 2) * math.sin(-math.pi / 4) +
          (position.dy - widget.height / 2) * math.cos(-math.pi / 4) +
          widget.height / 2,
    );
    bool isNeedUpdate = false;
    for (final _CrossBox value in boxes) {
      if (value.rect.contains(position)) {
        if (!value.state1) {
          value.state1 = true;
          isNeedUpdate = true;
        }
      }
      if (value.rect.contains(newPoint)) {
        if (!value.state2) {
          value.state2 = true;
          isNeedUpdate = true;
        }
      }
    }
    if (isNeedUpdate) {
      setState(() {});
    }
  }
}

class CrossGridPainter extends CustomPainter {
  CrossGridPainter(this.boxes);

  final List<_CrossBox> boxes;

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = Colors.grey
      ..style = PaintingStyle.fill;

    final Paint gridPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    for (final _CrossBox box in boxes) {
      if (box.state1) {
        paint.color = Colors.green;
      } else {
        paint.color = Colors.grey;
      }
      canvas.drawRect(box.rect, paint);
      canvas.drawRect(box.rect, gridPaint);
    }

    //旋转45度再画一次
    canvas.save();
    canvas.translate(size.width / 2, size.height / 2);
    canvas.rotate(math.pi / 4);
    canvas.translate(-size.width / 2, -size.height / 2);
    for (final _CrossBox box in boxes) {
      if (box.state2) {
        paint.color = Colors.green;
      } else {
        paint.color = Colors.grey;
      }
      canvas.drawRect(box.rect, paint);
      canvas.drawRect(box.rect, gridPaint);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}

class _CrossBox {
  _CrossBox({required this.rect, required this.state1, required this.state2});

  final Rect rect;
  bool state1;
  bool state2;
}
