import 'package:factory_mode/config/ui.dart';
import 'package:factory_mode/controller/audio_test_controller.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/widget/base_test_project_widget.dart';
import 'package:factory_mode/widget/common_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class AudioTestPage extends BaseTestProjectWidget<AudioTestController> {
  AudioTestPage({this.isAddBottomMargin = false, super.key})
      : super(controller: BaseTestController.getController(TestProject.audio));

  final bool isAddBottomMargin;

  @override
  BaseTestProjectWidgetState<AudioTestController, BaseTestProjectWidget<AudioTestController>> createState() =>
      _AudioTestPageState();
}

class _AudioTestPageState extends BaseTestProjectWidgetState<AudioTestController, AudioTestPage> {
  @override
  Widget build(BuildContext context) {
    return CommonListWidget(
      baseTestController: widget.controller,
      title: '音频',
      children: <Widget>[
        CupertinoButton(
          padding: EdgeInsets.zero,
          onPressed: widget.controller.audioPlay,
          child: Obx(() {
            return CommonTextBox(
              title: '点击发声',
              width: 236.aw,
              bgColor: widget.controller.state.value.color,
              padding: EdgeInsets.symmetric(vertical: 20.ah, horizontal: 20.aw),
              margin: EdgeInsets.only(bottom: 12.ah),
            );
          }),
        ),
        if (widget.isAddBottomMargin)
          SizedBox(
            height: 65.ah,
          )
      ],
    );
  }
}
