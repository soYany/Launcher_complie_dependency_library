import 'package:factory_mode/config/ui.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/controller/zigbee_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/widget/base_test_project_widget.dart';
import 'package:factory_mode/widget/common_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ZigbeeTestPage extends BaseTestProjectWidget<ZigbeeTestController> {
  ZigbeeTestPage({this.isAddBottomMargin = false, super.key})
      : super(controller: BaseTestController.getController(TestProject.zigbee));

  final bool isAddBottomMargin;

  @override
  BaseTestProjectWidgetState<ZigbeeTestController, BaseTestProjectWidget<ZigbeeTestController>> createState() =>
      _AudioTestPageState();
}

class _AudioTestPageState extends BaseTestProjectWidgetState<ZigbeeTestController, ZigbeeTestPage> {
  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return CommonListWidget(
        baseTestController: widget.controller,
        children: <Widget>[
          const TitleWidget(title: 'Zigbee'),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 60.aw),
            margin: EdgeInsets.only(bottom: 15.ah),
            alignment: AlignmentDirectional.centerStart,
            child: Text(
              getStateText(widget.controller.networkingState.value),
              textAlign: TextAlign.start,
              style: TextStyle(
                fontSize: 24.asp,
                color: Colors.white,
              ),
            ),
          ),
          Wrap(
            spacing: 16.aw,
            runSpacing: 16.ah,
            children: <Widget>[
              getValueListenable(
                title: '组网',
                state: widget.controller.networkingState.value,
                onPressed: widget.controller.sendNetworking,
              ),
              getValueListenable(
                title: '控制',
                state: widget.controller.controlState.value,
                onPressed: widget.controller.sendControl,
              ),
              getValueListenable(
                title: '解除',
                state: widget.controller.relieveState.value,
                onPressed: widget.controller.sendRelieve,
              ),
            ],
          ),
          if (widget.isAddBottomMargin)
            SizedBox(
              height: 75.ah,
            )
        ],
      );
    });
  }

  String getStateText(StateResult value) {
    if (value == StateResult.pass) {
      return '组网成功';
    } else if (value == StateResult.fail) {
      return '组网失败';
    } else if (value == StateResult.none) {
      return '组网中';
    }
    return '还未组网';
  }

  Widget getValueListenable({required String title, required StateResult state, required void Function() onPressed}) {
    return CupertinoButton(
      padding: EdgeInsets.zero,
      onPressed: onPressed,
      child: CommonTextBox(
        title: title,
        bgColor: state.color,
      ),
    );
  }
}
