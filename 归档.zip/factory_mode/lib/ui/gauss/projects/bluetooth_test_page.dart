import 'package:factory_mode/config/ui.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/controller/bluetooth_test_controller.dart';
import 'package:factory_mode/entity/entitys.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/widget/base_test_project_widget.dart';
import 'package:factory_mode/widget/common_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class BluetoothTestPage extends BaseTestProjectWidget<BluetoothTestController> {
  BluetoothTestPage({this.isAddBottomMargin = false, super.key})
      : super(controller: BaseTestController.getController(TestProject.bluetooth));

  final bool isAddBottomMargin;

  @override
  BaseTestProjectWidgetState<BluetoothTestController, BaseTestProjectWidget<BluetoothTestController>> createState() =>
      _BottomShellTestPageState();
}

class _BottomShellTestPageState extends BaseTestProjectWidgetState<BluetoothTestController, BluetoothTestPage> {
  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final BluetoothInfoEntity? value = widget.controller.bluetoothInfoNotifier.value;
      final String bestBtMac = value?.bestBtMac ?? "";
      return CommonListWidget(
        baseTestController: widget.controller,
        title: '蓝牙',
        children: <Widget>[
          CommonTextBox(
            title: _getSearchApStatus(bestBtMac),
            width: 270.aw,
            bgColor: getStateColor(),
            margin: EdgeInsets.only(bottom: 12.ah),
          ),
          CommonTextBox(
            title: '信号强度：${bestBtMac.isNotEmpty ? (value?.bestBtRssi ?? '--') : '--'} dBm',
            width: 270.aw,
            bgColor: getStateColor(),
          ),
          Obx(
            () {
              return TitleWidget(
                padding: EdgeInsets.only(bottom: 12.ah),
                title: '第${widget.controller.scanCount.value}次扫描，设备：${value?.btCount ?? 0}',
              );
            },
          ),
          if (widget.isAddBottomMargin) SizedBox(height: 30.ah)
        ],
      );
    });
  }

  Color getStateColor() {
    final String bestBtMac = widget.controller.bluetoothInfoNotifier.value?.bestBtMac ?? "";
    return bestBtMac.isNotEmpty
        ? (widget.controller.tested() ? StateResult.pass.color : StateResult.fail.color)
        : Colors.white;
  }

  String _getSearchApStatus(String bestBtMac) {
    if (bestBtMac.isNotEmpty) {
      return bestBtMac;
    }
    return '扫描中...';
  }
}
