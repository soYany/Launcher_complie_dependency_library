import 'dart:async';

import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/controller/screen_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/ui/gauss/widgets/test_project_common_widget.dart';
import 'package:factory_mode/widget/base_test_project_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ScreenTestPage extends BaseTestProjectWidget<ScreenTestController> {
  ScreenTestPage({super.key}) : super(controller: BaseTestController.getController(TestProject.screen));

  @override
  BaseTestProjectWidgetState<ScreenTestController, BaseTestProjectWidget<ScreenTestController>> createState() {
    return ScreenTestPageState();
  }
}

class ScreenTestPageState extends BaseTestProjectWidgetState<ScreenTestController, ScreenTestPage> {
  bool isShowButton = false;
  Timer? timer;

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        widget.controller.changeColor();
        if (widget.controller.testFinish()) {
          timer = Timer(const Duration(seconds: 2), () {
            if (mounted) {
              setState(() {
                isShowButton = true;
              });
            }
          });
        }
      },
      child: Obx(() {
        return Stack(
          children: <Widget>[
            Container(color: widget.controller.currentColor.value),
            if (isShowButton)
              Align(
                alignment: Alignment.bottomCenter,
                child: TestProjectCommonWidget(controller: widget.controller),
              )
          ],
        );
      }),
    );
  }
}
