import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/controller/motor_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/manager/test_project_manager.dart';
import 'package:factory_mode/widget/base_test_project_widget.dart';
import 'package:factory_mode/widget/common_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class MotorTestPage extends BaseTestProjectWidget<MotorTestController> {
  MotorTestPage({super.key}) : super(controller: BaseTestController.getController(TestProject.motor));

  @override
  BaseTestProjectWidgetState<MotorTestController, BaseTestProjectWidget<MotorTestController>> createState() =>
      _AudioTestPageState();
}

class _AudioTestPageState extends BaseTestProjectWidgetState<MotorTestController, MotorTestPage> {
  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final ({StateResult state, int? vibration}) value = widget.controller.state.value;
      final int? vibration = value.vibration;
      return CommonListWidget(
        baseTestController: widget.controller,
        title: '马达',
        children: <Widget>[
          CommonTextBox(
            title: vibration == null ? '点击触摸按键' : '${vibration / 10}HZ',
            width: 236,
            bgColor: TestProjectManager.currentTestMode == TestMode.pcba ? Colors.white : value.state.color,
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
            margin: const EdgeInsets.only(bottom: 12),
          ),
        ],
      );
    });
  }
}
