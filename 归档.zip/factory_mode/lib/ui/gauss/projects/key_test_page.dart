import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/controller/key_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/widget/base_test_project_widget.dart';
import 'package:factory_mode/widget/common_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class KeyTestPage extends BaseTestProjectWidget<KeyTestController> {
  KeyTestPage({super.key}) : super(controller: BaseTestController.getController(TestProject.key));

  @override
  BaseTestProjectWidgetState<KeyTestController, BaseTestProjectWidget<KeyTestController>> createState() =>
      _AudioTestPageState();
}

class _AudioTestPageState extends BaseTestProjectWidgetState<KeyTestController, KeyTestPage> {
  @override
  Widget build(BuildContext context) {
    return Obx(
      () {
        return CommonListWidget(
          baseTestController: widget.controller,
          title: '按键旋钮',
          children: <Widget>[
            getValueListenable(title: '旋钮 结果', value: widget.controller.knobKeyState.value),
            getValueListenable(title: '重启键 结果', value: widget.controller.restartKeyState.value),
            for (int i = 0; i < widget.controller.keyMapState.length; i++)
              getValueListenable(
                  title: '按键${i + 1} 结果', value: widget.controller.keyMapState.values.elementAt(i).value),
          ],
        );
      },
    );
  }

  Widget getValueListenable({required String title, required StateResult? value}) {
    if (value == null) {
      return const SizedBox.shrink();
    }
    return CommonTextBox(
      margin: const EdgeInsets.only(bottom: 15),
      title: title,
      width: 270,
      bgColor: value.color,
    );
  }
}
