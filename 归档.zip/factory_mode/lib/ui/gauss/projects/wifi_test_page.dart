import 'package:factory_mode/config/ui.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/controller/wifi_test_controller.dart';
import 'package:factory_mode/entity/entitys.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/widget/base_test_project_widget.dart';
import 'package:factory_mode/widget/common_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class WifiTestPage extends BaseTestProjectWidget<WifiTestController> {
  WifiTestPage({this.isAddBottomMargin = false, super.key})
      : super(controller: BaseTestController.getController(TestProject.wifi));

  final bool isAddBottomMargin;

  @override
  BaseTestProjectWidgetState<WifiTestController, BaseTestProjectWidget<WifiTestController>> createState() =>
      _WifiTestPageState();
}

class _WifiTestPageState extends BaseTestProjectWidgetState<WifiTestController, WifiTestPage> {
  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final ({WiFiInfoEntity? hz_2_4, WiFiInfoEntity? hz_5})? value = widget.controller.wifiInfoNotifier.value;
      final WiFiInfoEntity? hz_2_4 = value?.hz_2_4;
      final WiFiInfoEntity? hz_5 = value?.hz_5;
      return CommonListWidget(
        title: "Wi-Fi",
        baseTestController: widget.controller,
        children: <Widget>[
          CommonTextBox(
            title: _getSearchApStatus(hz_2_4),
            width: 270.aw,
            bgColor: hz_2_4 != null
                ? (widget.controller.isHz24tested() ? StateResult.pass.color : StateResult.fail.color)
                : Colors.white,
            margin: EdgeInsets.only(bottom: 12.ah),
          ),
          if (widget.controller.isFrequency5G)
            CommonTextBox(
              title: _getSearchApStatus(hz_5),
              width: 270.aw,
              bgColor: hz_5 != null
                  ? (widget.controller.isHz5tested() ? StateResult.pass.color : StateResult.fail.color)
                  : Colors.white,
              margin: EdgeInsets.only(bottom: 12.ah),
            ),
          if (widget.isAddBottomMargin)
            SizedBox(
              height: 60.ah,
            )
        ],
      );
    });
  }

  String _getSearchApStatus(WiFiInfoEntity? info) {
    final String ssid = info?.ssid ?? '';
    if (ssid.isNotEmpty) {
      return '$ssid ${info?.rssi}dBm';
    }
    return '扫描中...';
  }
}
