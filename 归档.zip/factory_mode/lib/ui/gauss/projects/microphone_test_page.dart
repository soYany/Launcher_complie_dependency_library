import 'package:factory_mode/config/ui.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/controller/microphone_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/widget/base_test_project_widget.dart';
import 'package:factory_mode/widget/common_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class MicrophoneTestPage extends BaseTestProjectWidget<MicrophoneTestController> {
  MicrophoneTestPage({
    this.isAddBottomMargin = false,
    super.key,
  }) : super(controller: BaseTestController.getController(TestProject.microphone));

  final bool isAddBottomMargin;

  @override
  BaseTestProjectWidgetState<MicrophoneTestController, BaseTestProjectWidget<MicrophoneTestController>> createState() =>
      _MicrophoneTestPageState();
}

class _MicrophoneTestPageState extends BaseTestProjectWidgetState<MicrophoneTestController, MicrophoneTestPage> {
  @override
  Widget build(BuildContext context) {
    return CommonListWidget(
      baseTestController: widget.controller,
      title: '麦克风',
      children: <Widget>[
        Obx(() {
          final StateResult? soundValue = widget.controller.soundValue.value;
          if (soundValue != null) {
            final MicrophoneTestProject? currentKey = widget.controller.currentPlayKey;
            final StateResult? currentPlayState =
                currentKey == null ? null : widget.controller.mapState[currentKey]?.stateResult;
            return CommonTextBox(
              title: getTitleState(soundValue, currentPlayState),
              width: 236.aw,
              bgColor: soundValue == StateResult.fail || currentPlayState == StateResult.fail
                  ? StateResult.fail.color
                  : StateResult.ordinary.color,
              padding: EdgeInsets.symmetric(vertical: 20.ah, horizontal: 8.aw),
            );
          }
          final List<MapEntry<MicrophoneTestProject, MicrophoneTestResult>> resultList = widget
              .controller.mapState.entries
              .where((MapEntry<MicrophoneTestProject, MicrophoneTestResult> element) =>
                  element.key.type == MicrophoneTestType.MIC ||
                  element.key.type == MicrophoneTestType.REF ||
                  element.key.type == MicrophoneTestType.CONSISTENCY)
              .toList();

          final List<(String, int?, Color, Color)> list = <(String, int?, Color, Color)>[];
          list.addAll(resultList.map((MapEntry<MicrophoneTestProject, MicrophoneTestResult> e) => (
                e.key.getResultKey(),
                e.value.value,
                e.value.stateResult == StateResult.none ? Colors.white : Colors.black,
                e.value.stateResult == StateResult.none ? Colors.transparent : e.value.stateResult.color
              )));

          return Column(
            children: <Widget>[
              for (final (String, int?, Color, Color) item in list)
                CommonTextBox(
                  width: 270.aw,
                  title: buildTitle(item.$1, item.$2),
                  textColor: item.$3,
                  bgColor: item.$4,
                ),
            ],
          );
        }),
        SizedBox(height: 20.ah),
        if (widget.isAddBottomMargin) SizedBox(height: 16.ah)
      ],
    );
  }

  String buildTitle(String key, int? value) {
    String title = key.toUpperCase();
    if (value != null) {
      title += ":${value / 100} dbFs";
    }
    return title;
  }

  String getTitleState(StateResult soundValue, StateResult? currentPlayState) {
    if (soundValue.isNormalState) {
      return '录音中...';
    } else if (soundValue == StateResult.fail) {
      return '录音失败';
    } else if (currentPlayState != null) {
      if (currentPlayState.isFail) {
        return '播放失败';
      } else if (currentPlayState.isPass) {
        return '播放成功';
      }
      return '${widget.controller.currentPlayKey?.getResultKey()}播放中';
    } else {
      return '错误';
    }
  }
}
