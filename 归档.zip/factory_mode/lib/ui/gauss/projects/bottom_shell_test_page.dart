import 'package:factory_mode/config/ui.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/controller/bottom_shell_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/widget/base_test_project_widget.dart';
import 'package:factory_mode/widget/common_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class BottomShellTestPage extends BaseTestProjectWidget<BottomShellTestController> {
  BottomShellTestPage({super.key}) : super(controller: BaseTestController.getController(TestProject.bottomShell));

  @override
  BaseTestProjectWidgetState<BottomShellTestController, BaseTestProjectWidget<BottomShellTestController>>
      createState() => _BottomShellTestPageState();
}

class _BottomShellTestPageState extends BaseTestProjectWidgetState<BottomShellTestController, BottomShellTestPage> {
  bool isNotClick = false;

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final BottomShellData? bottomShell = widget.controller.bottomShell.value;
      final StateResult? sensor485 = widget.controller.sensor485.value;
      return CommonListWidget(
        baseTestController: widget.controller,
        children: <Widget>[
          SizedBox(height: 40.ah),
          if (sensor485 != null)
            CommonTextBox(
              title: '485传感器',
              padding: EdgeInsets.symmetric(vertical: 10.ah, horizontal: 10.aw),
              margin: EdgeInsets.only(bottom: 20.ah),
              bgColor: sensor485.color,
            ),
          if (bottomShell != null)
            GestureDetector(
              onTap: () {
                if (!isNotClick) {
                  setState(() {
                    isNotClick = true;
                  });
                  widget.controller.controllerBottomShell();
                  Future<void>.delayed(const Duration(seconds: 1), () {
                    if (mounted) {
                      setState(() {
                        isNotClick = false;
                      });
                    }
                  });
                }
              },
              child: CommonTextBox(
                title: '外设开关',
                width: 236.aw,
                padding: EdgeInsets.symmetric(vertical: 20.ah, horizontal: 20.aw),
                bgColor: bottomShell.stateResult.color.withOpacity(isNotClick ? 0.3 : 1),
              ),
            ),
          SizedBox(height: 20.ah),
        ],
      );
    });
  }
}
