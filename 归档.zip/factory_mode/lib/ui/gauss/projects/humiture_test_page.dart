import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/controller/humiture_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/widget/base_test_project_widget.dart';
import 'package:factory_mode/widget/common_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class HumitureTestPage extends BaseTestProjectWidget<HumitureTestController> {
  HumitureTestPage({super.key}) : super(controller: BaseTestController.getController(TestProject.humiture));

  @override
  BaseTestProjectWidgetState<HumitureTestController, BaseTestProjectWidget<HumitureTestController>> createState() =>
      _HumitureTestPageState();
}

class _HumitureTestPageState extends BaseTestProjectWidgetState<HumitureTestController, HumitureTestPage> {
  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final ({int? humidity, int? temperature})? value = widget.controller.value.value;
      final int? temperature = value?.temperature;
      final int? humidity = value?.humidity;
      return CommonListWidget(
        title: "温湿度",
        baseTestController: widget.controller,
        children: <Widget>[
          CommonTextBox(
            title: '温度：${temperature == null ? '--' : '${temperature / 1000}'}°c',
            width: 270,
            margin: const EdgeInsets.only(bottom: 12),
          ),
          CommonTextBox(
            title: '湿度：${humidity == null ? '--' : '${humidity / 1000}'}%Rh',
            width: 270,
            margin: const EdgeInsets.only(bottom: 12),
          ),
        ],
      );
    });
  }
}
