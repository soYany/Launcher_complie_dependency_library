import 'package:flutter/material.dart';

class GaussStyles {
  static TextStyle defaultTextStyle = const TextStyle(
    fontSize: 23,
    color: Colors.white,
    fontWeight: FontWeight.w300
  );

  static ButtonStyle defaultButtonStyle = ButtonStyle(
    padding: MaterialStateProperty.all<EdgeInsetsGeometry>(EdgeInsets.zero),
    textStyle: MaterialStateProperty.all<TextStyle>(defaultTextStyle),
    foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
    overlayColor: MaterialStateProperty.all<Color>(Colors.white.withOpacity(0.1)),
    backgroundColor: MaterialStateProperty.all<Color>(const Color(0xFF7B7B7B)),
    shape: MaterialStateProperty.all<OutlinedBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(0))),
  );
}
