import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/manager/test_project_manager.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class TestProjectCommonWidget extends StatelessWidget {
  const TestProjectCommonWidget({required this.controller, super.key});

  final BaseTestController controller;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            SizedBox(
              width: 96,
              height: 66,
              child: Obx(
                () => TextButton(
                  onPressed: () {
                    if (controller.tested()) {
                      controller.pass();
                    }
                  },
                  style: ButtonStyle(splashFactory: controller.tested() ? null : NoSplash.splashFactory),
                  child: Text(
                    "PASS",
                    style: TextStyle(color: Colors.black.withOpacity(controller.tested() ? 1 : 0.3), fontSize: 32),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 36),
            SizedBox(
              width: 96,
              height: 66,
              child: TextButton(
                onPressed: () {
                  controller.fail();
                },
                child: const Text(
                  "NG",
                  style: TextStyle(color: Colors.black, fontSize: 32),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            SizedBox(
              width: 68,
              height: 68,
              child: TextButton(
                onPressed: () {
                  final TestProject? currentProject = TestProjectManager.currentTestProject;
                  if (currentProject == null) {
                    return;
                  }
                  final List<TestProject> textProjectList = TestProjectManager.getTestProjectList();
                  final int index = textProjectList.indexOf(currentProject);
                  if (index > 0) {
                    TestProjectManager.currentTestProject = textProjectList[index - 1];
                  } else {
                    TestProjectManager.currentTestProject = null;
                  }
                },
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(const Color(0xFF1F1F1F)),
                  shape: MaterialStateProperty.all<OutlinedBorder>(const CircleBorder()),
                ),
                child: Image.asset("assets/back.webp", package: "factory_mode"),
              ),
            ),
            const SizedBox(width: 28),
            SizedBox(
              width: 68,
              height: 68,
              child: TextButton(
                onPressed: () {
                  TestProjectManager.currentTestProject = null;
                },
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(const Color(0xFF1F1F1F)),
                  shape: MaterialStateProperty.all<OutlinedBorder>(const CircleBorder()),
                ),
                child: Image.asset("assets/menu.webp", package: "factory_mode"),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
      ],
    );
  }
}
