import 'package:factory_mode/api/factory_test_api.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/manager/test_result_manager.dart';

class M5TestResultManager extends TestResultManager {
  factory M5TestResultManager() => _instance ??= M5TestResultManager._internal();

  M5TestResultManager._internal();

  static M5TestResultManager? _instance;

  @override
  Map<String, dynamic> get defaultFactoryResultContent => const <String, dynamic>{
        "softversion": "",
        "deviceModel": "",
        "boardId": "",
        "sn": "",
        "uuid": "",
        "wifiMac": "",
        "blueToothMac": "",
        "ncp": "",
        "bottomShell": "",
        "testResult": <String, dynamic>{
          "dev_info": -1,
          "lcd": -1,
          "TouchPad": -1,
          "bottomShell": <Map<String, dynamic>>[
            <String, dynamic>{"testTag": 0, "testType": "relay", "testName": "relay1", "result": -1, "des": ""},
          ],
          "wifi": <String, dynamic>{"result": -1, "rssi": null, "report_ssid": ""},
          "bluetooth": <String, dynamic>{"result": -1, "rssi": null},
          "speaker": -1,
          "REF1_AEC": -1,
          "REF2_AEC": -1,
          "mic1": -1,
          "mic2": -1,
          "AEC": -1,
          "zigbee": -1,
          "rebootKey": -1,
        }
      };

  TestResult _parseResultValue(dynamic value) {
    if (value == 0) {
      return TestResult.pass;
    } else if (value == 1) {
      return TestResult.fail;
    } else {
      return TestResult.untested;
    }
  }

  @override
  TestProjectResult getTestResult(TestProject project) {
    switch (project) {
      case TestProject.deviceInfo:
        return (result: _parseResultValue(testResultContent["dev_info"]), failReason: null);
      case TestProject.screen:
        return (result: _parseResultValue(testResultContent["lcd"]), failReason: null);
      case TestProject.screenTouch:
        return (result: _parseResultValue(testResultContent["TouchPad"]), failReason: null);
      case TestProject.bottomShell:
        final dynamic bottomShellData = testResultContent["bottomShell"];
        if (bottomShellData is List) {
          final List<int> values = <int>[];
          for (final dynamic item in bottomShellData) {
            if (item is Map) {
              values.add(item["result"] ?? -1);
            } else {
              values.add(-1);
            }
          }
          if (values.every((int element) => element == -1)) {
            return (result: TestResult.untested, failReason: null);
          } else if (values.every((int element) => element == 0)) {
            return (result: TestResult.pass, failReason: null);
          } else {
            return (result: TestResult.fail, failReason: null);
          }
          // if (values.length != 3) {
          //   return (result: TestResult.untested, failReason: null);
          // } else {
          //   if (values.every((int element) => element == -1)) {
          //     return (result: TestResult.untested, failReason: null);
          //   } else if (values.every((int element) => element == 0)) {
          //     return (result: TestResult.pass, failReason: null);
          //   } else {
          //     return (result: TestResult.fail, failReason: null);
          //   }
          // }
        } else {
          return (result: TestResult.untested, failReason: null);
        }
      case TestProject.wifi:
        final dynamic wifiData = testResultContent["wifi"];
        if (wifiData is Map) {
          final int result = wifiData["result"] ?? -1;
          final int? rssi = wifiData["rssi"];
          if (result == 0) {
            return (result: TestResult.pass, failReason: null);
          } else if (result == 1) {
            return (result: TestResult.fail, failReason: rssi == null ? null : "信号不达标：$rssi");
          } else {
            return (result: TestResult.untested, failReason: null);
          }
        } else {
          return (result: TestResult.untested, failReason: null);
        }
      case TestProject.bluetooth:
        final dynamic bleData = testResultContent["bluetooth"];
        if (bleData is Map) {
          final int result = bleData["result"] ?? -1;
          final int? rssi = bleData["rssi"];
          if (result == 0) {
            return (result: TestResult.pass, failReason: null);
          } else if (result == 1) {
            return (result: TestResult.fail, failReason: rssi == null ? null : "信号不达标：$rssi");
          } else {
            return (result: TestResult.untested, failReason: null);
          }
        } else {
          return (result: TestResult.untested, failReason: null);
        }
      case TestProject.humiture:
        final dynamic humitureData = testResultContent["temHum"];
        if (humitureData is Map) {
          final int result = humitureData["result"] ?? -1;
          if (result == 0) {
            return (result: TestResult.pass, failReason: null);
          } else if (result == 1) {
            return (result: TestResult.fail, failReason: null);
          } else {
            return (result: TestResult.untested, failReason: null);
          }
        } else {
          return (result: TestResult.untested, failReason: null);
        }
      case TestProject.audio:
        return (result: _parseResultValue(testResultContent["speaker"]), failReason: null);
      case TestProject.microphone:
        return (result: _parseResultValue(testResultContent["AEC"]), failReason: null);
      case TestProject.zigbee:
        return (result: _parseResultValue(testResultContent["zigbee"]), failReason: null);
      case TestProject.key:
        // final TestResult touchKeyResult = _parseResultValue(testResultContent["touchKey"]);
        // final TestResult rotateKeyResult = _parseResultValue(testResultContent["rotateKey"]);
        // final TestResult result;
        // if (touchKeyResult == TestResult.pass && rotateKeyResult == TestResult.pass) {
        //   result = TestResult.pass;
        // } else if (touchKeyResult == TestResult.fail || rotateKeyResult == TestResult.fail) {
        //   result = TestResult.fail;
        // } else {
        //   result = TestResult.untested;
        // }
        final TestResult rebootKeyResult = _parseResultValue(testResultContent["rebootKey"]);
        final TestResult result;
        if (rebootKeyResult == TestResult.pass) {
          result = TestResult.pass;
        } else if (rebootKeyResult == TestResult.fail) {
          result = TestResult.fail;
        } else {
          result = TestResult.untested;
        }
        return (result: result, failReason: null);
      case TestProject.motor:
        return (result: _parseResultValue(testResultContent["motor"]), failReason: null);
    }
  }

  int _parseValueResult(TestResult result) {
    if (result == TestResult.pass) {
      return 0;
    } else if (result == TestResult.fail) {
      return 1;
    } else {
      return -1;
    }
  }

  @override
  void setTestResult(TestProject project, TestResult result, {dynamic extraResult}) {
    switch (project) {
      case TestProject.deviceInfo:
        testResultContent["dev_info"] = _parseValueResult(result);
        break;
      case TestProject.screen:
        testResultContent["lcd"] = _parseValueResult(result);
      case TestProject.screenTouch:
        testResultContent["TouchPad"] = _parseValueResult(result);
      case TestProject.bottomShell:
        testResultContent["bottomShell"] = extraResult;
      case TestProject.wifi:
        testResultContent["wifi"] = extraResult;
      case TestProject.bluetooth:
        testResultContent["bluetooth"] = extraResult;
      case TestProject.humiture:
        testResultContent["temHum"] = extraResult;
      case TestProject.audio:
        testResultContent["speaker"] = _parseValueResult(result);
      case TestProject.microphone:
        if (extraResult != null) {
          testResultContent.addAll(extraResult);
        } else {
          testResultContent["AEC"] = _parseValueResult(result);
          testResultContent["REF1_AEC"] = _parseValueResult(result);
          testResultContent["REF2_AEC"] = _parseValueResult(result);
          testResultContent["mic1"] = _parseValueResult(result);
          testResultContent["mic2"] = _parseValueResult(result);
        }
      case TestProject.zigbee:
        testResultContent["zigbee"] = _parseValueResult(result);
      case TestProject.key:
        if (extraResult != null) {
          testResultContent.addAll(extraResult);
        } else {
          testResultContent["touchKey"] = _parseValueResult(result);
          testResultContent["rotateKey"] = _parseValueResult(result);
        }
      case TestProject.motor:
        testResultContent["motor"] = _parseValueResult(result);
    }
    saveFactoryResult();
  }

  @override
  void saveFactoryResult() {
    if (currentMode == TestMode.pcba) {
      testResultContent["lcd"] = 0;
      testResultContent["TouchPad"] = 0;
      testResultContent["wifi"] = <String, dynamic>{"result": deviceInfoContent["wifiMac"]?.isNotEmpty == true ? 0 : 1};
      testResultContent["bluetooth"] = <String, dynamic>{
        "result": deviceInfoContent["blueToothMac"]?.isNotEmpty == true ? 0 : 1
      };
      testResultContent["zigbee"] = deviceInfoContent["ncp"]?.isNotEmpty == true ? 0 : 1;
      final int bottomShellResult = deviceInfoContent["bottomShell"]?.isNotEmpty == true ? 0 : 1;
      testResultContent["bottomShell"] = <Map<String, dynamic>>[
        <String, dynamic>{
          "testTag": 0,
          "testType": "relay",
          "testName": "relay1",
          "result": bottomShellResult,
          "des": ""
        },
        <String, dynamic>{
          "testTag": 0,
          "testType": "relay",
          "testName": "relay2",
          "result": bottomShellResult,
          "des": ""
        },
        <String, dynamic>{
          "testTag": 0,
          "testType": "sensor",
          "testName": "485Sensor",
          "result": bottomShellResult,
          "des": ""
        },
      ];
    }
    super.saveFactoryResult();
  }

  @override
  String getQrCodeData() {
    final TestMode? currentMode = this.currentMode;
    if (currentMode == null) {
      throw Exception("currentMode is null");
    }

    final StringBuffer qrDataBuffer =
        StringBuffer("${currentMode == TestMode.pcba ? "P" : "D"}-${deviceInfoContent["sn"]}-");
    final List<TestProject> projects = qrCodeResultOrderList;
    for (final TestProject project in projects) {
      final TestProjectResult result = getTestResult(project);
      qrDataBuffer.write(switch (result.result) {
        TestResult.pass => "1",
        TestResult.fail => "0",
        TestResult.untested => "2",
      });
    }

    final int seconds = FactoryTestApi.getAgingTime() ?? 0;
    final double hours = seconds / 3600;
    String str = (hours * 10).toInt().toString().padLeft(4, '0');
    str = '${str.substring(0, 3)}.${str.substring(3)}';
    qrDataBuffer.write(",$str");
    return qrDataBuffer.toString();
  }

  @override
  bool isAllTested() {
    return allTestProjectList.every((TestProject element) => getTestResult(element).result != TestResult.untested);
  }

  @override
  List<TestProject> get allTestProjectList => const <TestProject>[
        TestProject.deviceInfo,
        TestProject.screen,
        TestProject.screenTouch,
        TestProject.bottomShell,
        TestProject.wifi,
        TestProject.bluetooth,
        TestProject.key,
        TestProject.audio,
        TestProject.microphone,
        TestProject.zigbee,
        TestProject.humiture,
        TestProject.motor,
      ];

  @override
  List<TestProject> get pcbaTestProjectList => const <TestProject>[
        TestProject.deviceInfo,
        TestProject.audio,
        TestProject.microphone,
        TestProject.motor,
        TestProject.key,
        TestProject.humiture,
      ];

  @override
  List<TestProject> get qrCodeResultOrderList => allTestProjectList;
}
