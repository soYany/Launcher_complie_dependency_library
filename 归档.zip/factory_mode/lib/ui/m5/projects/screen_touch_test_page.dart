import 'dart:async';

import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/controller/screen_touch_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/ui/gauss/widgets/test_project_common_widget.dart';
import 'package:factory_mode/utils/logger_utils.dart';
import 'package:factory_mode/widget/base_test_project_widget.dart';
import 'package:flutter/material.dart';

class ScreenTouchTestPage extends BaseTestProjectWidget<ScreenTouchTestController> {
  ScreenTouchTestPage({super.key}) : super(controller: BaseTestController.getController(TestProject.screenTouch));

  @override
  BaseTestProjectWidgetState<ScreenTouchTestController, ScreenTouchTestPage> createState() {
    return ScreenTouchTestState();
  }
}

class ScreenTouchTestState extends BaseTestProjectWidgetState<ScreenTouchTestController, ScreenTouchTestPage> {
  bool isShowButton = false;

  Timer? timer;

  @override
  void initState() {
    super.initState();
    timer = Timer(const Duration(seconds: 5), () {
      if (mounted) {
        setState(() {
          isShowButton = true;
        });
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(fit: StackFit.expand, children: <Widget>[
      TouchScreenTest(
        gridSize: 32,
        width: 480,
        height: 480,
        onAllCellsTouched: () {
          widget.controller.isAllTouched.value = true;
        },
      ),
      if (isShowButton)
        Align(
          alignment: Alignment.bottomCenter,
          child: TestProjectCommonWidget(controller: widget.controller),
        )
    ]);
  }
}

class TouchScreenTest extends StatefulWidget {
  const TouchScreenTest({
    required this.gridSize,
    required this.width,
    required this.height,
    required this.onAllCellsTouched,
    super.key,
  });

  final double gridSize;
  final double width;
  final double height;
  final void Function() onAllCellsTouched;

  @override
  _TouchScreenTestState createState() => _TouchScreenTestState();
}

class _TouchScreenTestState extends State<TouchScreenTest> {
  late List<List<bool>> _touchedCells;

  int get rows => (widget.height / widget.gridSize).floor();

  int get columns => (widget.width / widget.gridSize).floor();

  @override
  void initState() {
    super.initState();
    _touchedCells = List<List<bool>>.generate(columns, (int x) => List<bool>.generate(rows, (int y) => false));
  }

  void _handleTouch(Offset position) {
    setState(() {
      final int x = (position.dx / widget.gridSize).floor();
      final int y = (position.dy / widget.gridSize).floor();
      if (x >= 0 && x < columns && y >= 0 && y < rows) {
        _touchedCells[x][y] = true;
      }
    });
    if (_allCellsTouched()) {
      widget.onAllCellsTouched();
    }
  }

  bool _allCellsTouched() {
    for (int x = 0; x < columns; x++) {
      for (int y = 0; y < rows; y++) {
        // 检查单元格是否沿边缘、中间线或对角线
        final bool isEdge = x == 0 || y == 0 || x == columns - 1 || y == rows - 1;
        final bool isMiddle = x == (columns / 2).floor() || y == (rows / 2).floor();
        final bool isDiagonal1 = x == y;
        final bool isDiagonal2 = x + y == columns - 1;
        if (isEdge || isMiddle || isDiagonal1 || isDiagonal2) {
          if (!_touchedCells[x][y]) {
            return false;
          }
        }
      }
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.width,
      height: widget.height,
      child: Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: (PointerDownEvent event) {
          _handleTouch(event.localPosition);
          LoggerUtils.print("onPointerDown: x=>${event.localPosition.dx}, y=>${event.localPosition.dy}");
        },
        onPointerMove: (PointerMoveEvent event) {
          _handleTouch(event.localPosition);
          LoggerUtils.print("onPointerMove: x=>${event.localPosition.dx}, y=>${event.localPosition.dy}");
        },
        onPointerUp: (PointerUpEvent event) {
          _handleTouch(event.localPosition);
          LoggerUtils.print("onPointerUp: x=>${event.localPosition.dx}, y=>${event.localPosition.dy}");
        },
        child: CustomPaint(
          size: Size(widget.width, widget.height),
          painter: GridPainter(_touchedCells, widget.gridSize),
        ),
      ),
    );
  }
}

class GridPainter extends CustomPainter {
  GridPainter(this.touchedCells, this.gridSize);

  final List<List<bool>> touchedCells;
  final double gridSize;

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..strokeWidth = 1
      ..style = PaintingStyle.fill;

    final int rows = touchedCells[0].length;
    final int columns = touchedCells.length;

    for (int x = 0; x < columns; x++) {
      for (int y = 0; y < rows; y++) {
        // 检查单元格是否沿边缘、中间线或对角线
        final bool isEdge = x == 0 || y == 0 || x == columns - 1 || y == rows - 1;
        final bool isMiddle = x == (columns / 2).floor() || y == (rows / 2).floor();
        final bool isDiagonal1 = x == y;
        final bool isDiagonal2 = x + y == columns - 1;
        if (isEdge || isMiddle || isDiagonal1 || isDiagonal2) {
          paint.color = touchedCells[x][y] ? Colors.green : Colors.white;
          canvas.drawRect(
            Rect.fromLTWH(x * gridSize, y * gridSize, gridSize, gridSize),
            paint,
          );
        }
      }
    }
    paint.color = Colors.black;
    for (int x = 0; x <= columns; x++) {
      canvas.drawLine(Offset(x * gridSize, 0), Offset(x * gridSize, size.height), paint);
    }
    for (int y = 0; y <= rows; y++) {
      canvas.drawLine(Offset(0, y * gridSize), Offset(size.width, y * gridSize), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }

  @override
  bool? hitTest(Offset position) {
    return true;
  }

}
