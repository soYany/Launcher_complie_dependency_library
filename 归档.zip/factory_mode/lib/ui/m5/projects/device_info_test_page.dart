import 'package:factory_mode/config/ui.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/controller/device_info_test_controller.dart';
import 'package:factory_mode/entity/entitys.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/ui/gauss/widgets/test_project_common_widget.dart';
import 'package:factory_mode/widget/base_test_project_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

///
/// @author 熊建刚
/// @desc 产品信息测试页面
/// @date 2024-07-29
///
class DeviceInfoTestPage extends BaseTestProjectWidget<DeviceInfoTestController> {
  DeviceInfoTestPage({super.key}) : super(controller: BaseTestController.getController(TestProject.deviceInfo));

  @override
  BaseTestProjectWidgetState<DeviceInfoTestController, BaseTestProjectWidget<DeviceInfoTestController>> createState() {
    return DeviceInfoTestPageState();
  }
}

class DeviceInfoTestPageState extends BaseTestProjectWidgetState<DeviceInfoTestController, DeviceInfoTestPage> {
  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final DeviceInfoEntity? value = widget.controller.deviceInfoNotifier.value;
      return Column(
        children: <Widget>[
          SizedBox(height: 20.aw),
          Text("产品信息", style: TextStyle(fontSize: 24.asp)),
          SizedBox(height: 18.ah),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  SizedBox(
                    width: 263.aw,
                    child: DefaultTextStyle(
                      style: TextStyle(fontSize: 24.asp, color: const Color(0xFF0EA70B)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Text("固件版本号: ${value?.versions.core}"),
                          //Text("硬件ID: ${value?.boardId}"),
                          Text("ModelID: ${value?.modelId}"),
                          Text("SN: ${value?.sn}"),
                          Text("UUID: ${value?.uuid}"),
                          Text("WiFi MAC: ${value?.wifiMac}"),
                          Text("BT MAC: ${value?.btMac}"),
                          Text("NCP版本: ${value?.ncpVersion}"),
                          //Text("底壳固件版本: ${value?.bottomShellVersion}"),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 100.ah),
                  TestProjectCommonWidget(controller: widget.controller),
                ],
              ),
            ),
          ),
        ],
      );
    });
  }
}
