import 'package:factory_mode/config/ui.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/controller/key_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/widget/base_test_project_widget.dart';
import 'package:factory_mode/widget/common_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

///
/// @author 熊建刚
/// @desc 按键测试页面(只有一个按键)
/// @date 2024-07-29
///
class KeyTestPage extends BaseTestProjectWidget<KeyTestController> {
  KeyTestPage({super.key}) : super(controller: BaseTestController.getController(TestProject.key));

  @override
  BaseTestProjectWidgetState<KeyTestController, BaseTestProjectWidget<KeyTestController>> createState() =>
      _AudioTestPageState();
}

class _AudioTestPageState extends BaseTestProjectWidgetState<KeyTestController, KeyTestPage> {
  @override
  Widget build(BuildContext context) {
    return Obx(
      () {
        return CommonListWidget(
          baseTestController: widget.controller,
          title: '按键',
          children: <Widget>[
            getValueListenable(title: '重启键 结果', value: widget.controller.restartKeyState.value),
            SizedBox(
              height: 95.ah,
            )
          ],
        );
      },
    );
  }

  Widget getValueListenable({required String title, required StateResult? value}) {
    if (value == null) {
      return const SizedBox.shrink();
    }
    return CommonTextBox(
      margin: EdgeInsets.only(bottom: 15.ah),
      title: title,
      width: 270.aw,
      bgColor: value.color,
    );
  }
}
