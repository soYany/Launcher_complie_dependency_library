import 'package:factory_mode/config/ui.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/controller/bottom_shell_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/widget/base_test_project_widget.dart';
import 'package:factory_mode/widget/common_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

///
/// @author 熊建刚
/// @desc 底壳测试页面
/// @date 2024-07-29
///
class BottomShellTestPage extends BaseTestProjectWidget<BottomShellTestController> {
  BottomShellTestPage({super.key}) : super(controller: BaseTestController.getController(TestProject.bottomShell));

  @override
  BaseTestProjectWidgetState<BottomShellTestController, BaseTestProjectWidget<BottomShellTestController>>
      createState() => _BottomShellTestPageState();
}

class _BottomShellTestPageState extends BaseTestProjectWidgetState<BottomShellTestController, BottomShellTestPage> {
  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final BottomShellData? bottomShell = widget.controller.bottomShell.value;
      return CommonListWidget(
        baseTestController: widget.controller,
        children: <Widget>[
          SizedBox(height: 120.ah),
          if (bottomShell != null)
            CupertinoButton(
              padding: EdgeInsets.zero,
              onPressed: () {
                widget.controller.controllerBottomShell();
              },
              child: CommonTextBox(
                title: '外设开关',
                width: 236.aw,
                padding: EdgeInsets.symmetric(vertical: 20.ah, horizontal: 20.aw),
                bgColor: bottomShell.stateResult.color,
              ),
            ),
          SizedBox(height: 20.ah),
        ],
      );
    });
  }
}
