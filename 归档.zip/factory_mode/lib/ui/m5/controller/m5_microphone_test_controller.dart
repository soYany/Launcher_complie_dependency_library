import 'package:factory_mode/controller/microphone_test_controller.dart';

class M5MicrophoneTestController extends MicrophoneTestController {
  @override
  Duration get microphoneBaseTestTimeout => const Duration(seconds: 30);

  @override
  void buildTestProjectMap() {
    super.buildTestProjectMap();
    if (micCount > 1) {
      mapState[const MicrophoneTestProject(index: 0, type: MicrophoneTestType.CONSISTENCY)] =
      const MicrophoneTestResult();
    }
  }
}
