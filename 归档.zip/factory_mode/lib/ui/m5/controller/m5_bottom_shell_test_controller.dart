import 'package:factory_mode/controller/bottom_shell_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/utils/logger_utils.dart';

class M5BottomShellTestController extends BottomShellTestController {

  @override
  void bottomShellHandlerCallback(int type, bool result) {
    final BottomShellData? bottomShellData = bottomShell.value;
    final StateResult? sensor485Data = sensor485.value;
    LoggerUtils.print(
        '底壳测试监听upload上报, type = $type, bottomShellData.isOn = ${bottomShellData?.isOn}, bottomShellData.stateResult = ${bottomShellData?.stateResult.name}');
    if (bottomShellData != null) {
      bottomShell.value = BottomShellData(
          isOn: result ? bottomShellData.isOn : !bottomShellData.isOn,
          stateResult: result ? StateResult.pass : StateResult.fail);
      return;
    }
    if (type == 2 && sensor485Data != null) {
      sensor485.value = result ? StateResult.pass : StateResult.fail;
      if (bottomShellData != null) {
        bottomShell.value = BottomShellData(
            isOn: result ? !bottomShellData.isOn : bottomShellData.isOn,
            stateResult: result ? StateResult.pass : StateResult.fail);
      }
    }
  }

  @override
  bool tested() {
    final BottomShellData? data = bottomShell.value;
    if (data != null) {
      return data.stateResult == StateResult.pass;
    } else {
      return false;
    }
  }

}