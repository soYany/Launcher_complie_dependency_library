import 'package:factory_mode/controller/key_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';

import 'package:factory_mode/factory_mode.dart';

class M5KeyTestController extends KeyTestController {
  @override
  void setTestResult(TestResult result, {dynamic extraResult}) {
    FactoryMode().config.testResultManagerFactory().setTestResult(project, result, extraResult: <String, dynamic>{
      "rebootKey": restartKeyState.value?.isPass == true ? 0 : 1,
    });
  }
}
