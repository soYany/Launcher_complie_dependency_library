import 'package:factory_mode/config/factory_builder_config.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/factory_mode.dart';
import 'package:factory_mode/ui/gauss/main_page.dart';
import 'package:factory_mode/ui/gauss/projects/audio_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/bluetooth_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/microphone_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/screen_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/wifi_test_page.dart';
import 'package:factory_mode/ui/gauss/projects/zigbee_test_page.dart';
import 'package:factory_mode/ui/gauss/result_page.dart';
import 'package:factory_mode/ui/gauss/styles.dart';
import 'package:factory_mode/ui/gauss/test_project_list_page.dart';
import 'package:factory_mode/ui/m5/controller/m5_bottom_shell_test_controller.dart';
import 'package:factory_mode/ui/m5/controller/m5_key_test_controller.dart';
import 'package:factory_mode/ui/m5/controller/m5_microphone_test_controller.dart';
import 'package:factory_mode/ui/m5/manager/m5_test_result_manager.dart';
import 'package:factory_mode/ui/m5/projects/bottom_shell_test_page.dart';
import 'package:factory_mode/ui/m5/projects/device_info_test_page.dart';
import 'package:factory_mode/ui/m5/projects/key_test_page.dart';
import 'package:factory_mode/ui/m5/projects/screen_touch_test_page.dart';
import 'package:factory_mode/utils/logger_utils.dart';
import 'package:factory_mode/widget/factory_mode_home.dart';
import 'package:flutter/material.dart';

class M5FactoryMode extends StatefulWidget {
  const M5FactoryMode({super.key});

  @override
  State<M5FactoryMode> createState() => _M5FactoryModeState();
}

class _M5FactoryModeState extends State<M5FactoryMode> {
  @override
  void initState() {
    super.initState();
    FactoryMode().config = FactoryMode().config.copyWith(
        mainPageBuilder: (BuildContext context) => const MainPage(),
        testProjectListPageBuilder: (BuildContext context, TestMode mode) {
          return TestProjectListPage(mode: mode);
        },
        testProjectPageBuilder: (BuildContext context, TestProject project) {
          LoggerUtils.print("testProjectPageBuilder(), project.name = ${project.name}");
          return switch (project) {
            TestProject.deviceInfo => DeviceInfoTestPage(),
            TestProject.screen => ScreenTestPage(),
            TestProject.wifi => WifiTestPage(isAddBottomMargin: true),
            TestProject.screenTouch => ScreenTouchTestPage(),
            TestProject.bottomShell => BottomShellTestPage(),
            TestProject.bluetooth => BluetoothTestPage(),
            TestProject.audio => AudioTestPage(isAddBottomMargin: true),
            TestProject.zigbee => ZigbeeTestPage(isAddBottomMargin: true),
            TestProject.key => KeyTestPage(),
            TestProject.microphone => MicrophoneTestPage(isAddBottomMargin: true),
            _ => Container(),
          };
        },
        testResultManagerFactory: () {
          return M5TestResultManager();
        },
        controllerFactory: (TestProject project) {
          return switch (project) {
            TestProject.microphone => M5MicrophoneTestController(),
            TestProject.bottomShell => M5BottomShellTestController(),
            TestProject.key => M5KeyTestController(),
            _ => FactoryBuilderConfig.defaultConfig.controllerFactory(project),
          };
        },
        testResultBuilder: (BuildContext context) {
          return const ResultPage();
        });
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      child: DefaultTextStyle(
        style: GaussStyles.defaultTextStyle,
        child: TextButtonTheme(
          data: TextButtonThemeData(style: GaussStyles.defaultButtonStyle),
          child: const ColoredBox(color: Colors.black, child: FactoryModeHome()),
        ),
      ),
    );
  }
}
