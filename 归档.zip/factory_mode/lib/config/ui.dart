import 'package:factory_mode/factory_mode.dart';

///M5是高斯的 4/3 倍
extension NumExtension on num {
  double get aw => toDouble() * FactoryMode().scaleValue;

  double get ah => toDouble() * FactoryMode().scaleValue;

  double get asp => toDouble() * FactoryMode().scaleValue;

  double get ar => toDouble() * FactoryMode().scaleValue;
}
