import 'package:flutter/material.dart';

class FontFamily {
  static const String mainFontFamily = "MainFont";
  static const String oppoMedium = "OPPOSans-M";

  static const List<String> fontFamilyFallback = <String>[
    'NanumGothic-Regular',
    'NotoSansThai-Regular',
    oppoMedium,
    'SourceSansPro-Regular',
    'Amiri-Regular',
    'Rubik-Regular',
  ];
}

class FontWeightStyle {
  static FontWeight fontWeightMini = FontWeight.w600;
}

class FontSize {
  static const double minTitle = 24;
  static const double mainTitle = 26;
  static const double bigTitle = 28;
  static const double smallSubTitle = 20;
}

class FontStyle {
  static TextStyle defaultTitle = const TextStyle(
    fontFamily: FontFamily.mainFontFamily,
    fontFamilyFallback: FontFamily.fontFamilyFallback,
    decoration: TextDecoration.none,
  );
  static TextStyle default300Title = defaultTitle.copyWith(
    fontWeight: FontWeight.w300,
  );
  static TextStyle default400Title = defaultTitle.copyWith(
    fontWeight: FontWeight.w400,
  );
  static TextStyle default500Title = defaultTitle.copyWith(
    fontWeight: FontWeight.w500,
  );
  static TextStyle default600Title = defaultTitle.copyWith(
    fontWeight: FontWeight.w600,
  );
  static TextStyle subText = defaultTitle.copyWith(
    fontSize: 22,
    color: const Color.fromRGBO(255, 255, 255, 0.8),
  );
  static TextStyle smallText = defaultTitle.copyWith(
    fontSize: 18,
    color: const Color.fromRGBO(255, 255, 255, 0.5),
  );

  static TextStyle albumDetail = FontStyle.defaultTitle.merge(
    const TextStyle(
      fontFamily: FontFamily.mainFontFamily,
      fontSize: 24,
      color: Color.fromARGB(128, 225, 225, 225),
      fontWeight: FontWeight.w400,
      decoration: TextDecoration.none,
      letterSpacing: 1.44,
    ),
  );
  static TextStyle playlistDetail = FontStyle.defaultTitle.merge(
    const TextStyle(
      fontFamily: FontFamily.mainFontFamily,
      fontSize: 24,
      color: Color.fromARGB(128, 225, 225, 225),
      fontWeight: FontWeight.w400,
      decoration: TextDecoration.none,
      letterSpacing: 1.44,
    ),
  );
  static TextStyle songDetailTitle = FontStyle.defaultTitle.merge(
    const TextStyle(
      fontFamily: FontFamily.mainFontFamily,
      fontSize: 40,
      color: Colors.white,
      fontWeight: FontWeight.w400,
      decoration: TextDecoration.none,
      letterSpacing: 2.4,
    ),
  );
  static TextStyle albumSubTitle = FontStyle.defaultTitle.merge(
    const TextStyle(
      fontFamily: FontFamily.mainFontFamily,
      fontSize: 24,
      color: Colors.white,
      fontWeight: FontWeight.w600,
      decoration: TextDecoration.none,
      letterSpacing: 1.44,
    ),
  );

  static TextStyle tipSmallTxt = FontStyle.defaultTitle.merge(
    const TextStyle(
      fontFamily: FontFamily.mainFontFamily,
      fontSize: 18,
      color: Color.fromRGBO(117, 117, 117, 1),
      decoration: TextDecoration.none,
    ),
  );
  static TextStyle playlistSubTitle = FontStyle.defaultTitle.merge(
    const TextStyle(
      fontFamily: FontFamily.mainFontFamily,
      fontSize: 24,
      color: Colors.white,
      fontWeight: FontWeight.w600,
      decoration: TextDecoration.none,
      letterSpacing: 1.44,
    ),
  );
}
