import 'dart:convert';
import 'dart:io';

import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/utils/logger_utils.dart';

mixin FactorySignalConfig on BaseTestController {
  FactorySignalConfigEntity factorySignalConfig = FactorySignalConfigEntity.fromJson(null);

  @override
  void initState() {
    super.initState();
    final File file = File('/tmp/factory_test/config/wifi_bt_config');
    if (file.existsSync()) {
      try {
        factorySignalConfig = FactorySignalConfigEntity.fromJson(jsonDecode(file.readAsStringSync()));
        LoggerUtils.print('读取wifi_bt_config 成功：${factorySignalConfig.toJson()}');
      } catch (e, s) {
        LoggerUtils.print('读取wifi_bt_config 错误：$e\n$s');
      }
    } else {
      LoggerUtils.print('读取wifi_bt_config 文件不存在');
    }
  }
}

class FactorySignalConfigEntity {
  FactorySignalConfigEntity.fromJson(Map<String, dynamic>? json)
      : wifi24GThreshold = json?['wifi_24G_threshold'] ?? -35,
        wifi5GThreshold = json?['wifi_5G_threshold'] ?? -30,
        btThreshold = json?['bt_threshold'] ?? -40;
  final int wifi24GThreshold;
  final int wifi5GThreshold;
  final int btThreshold;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'wifi_24G_threshold': wifi24GThreshold,
        'wifi_5G_threshold': wifi5GThreshold,
        'bt_threshold': btThreshold,
      };
}
