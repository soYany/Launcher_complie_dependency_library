import 'package:factory_mode/controller/audio_test_controller.dart';
import 'package:factory_mode/controller/base_test_controller.dart';
import 'package:factory_mode/controller/bluetooth_test_controller.dart';
import 'package:factory_mode/controller/bottom_shell_test_controller.dart';
import 'package:factory_mode/controller/device_info_test_controller.dart';
import 'package:factory_mode/controller/humiture_test_controller.dart';
import 'package:factory_mode/controller/key_test_controller.dart';
import 'package:factory_mode/controller/microphone_test_controller.dart';
import 'package:factory_mode/controller/motor_test_controller.dart';
import 'package:factory_mode/controller/screen_test_controller.dart';
import 'package:factory_mode/controller/screen_touch_test_controller.dart';
import 'package:factory_mode/controller/wifi_test_controller.dart';
import 'package:factory_mode/controller/zigbee_test_controller.dart';
import 'package:factory_mode/entity/enums.dart';
import 'package:factory_mode/manager/test_result_manager.dart';
import 'package:flutter/material.dart';

class FactoryBuilderConfig {
  FactoryBuilderConfig({
    required this.controllerFactory,
    required this.testResultManagerFactory,
    required this.mainPageBuilder,
    required this.testProjectListPageBuilder,
    required this.testProjectPageBuilder,
    required this.testResultBuilder,
  });

  final BaseTestController Function(TestProject project) controllerFactory;

  final TestResultManager Function() testResultManagerFactory;

  final Widget Function(BuildContext context) mainPageBuilder;

  final Widget Function(BuildContext context, TestMode mode) testProjectListPageBuilder;

  final Widget Function(BuildContext context, TestProject project) testProjectPageBuilder;

  final Widget Function(BuildContext context) testResultBuilder;

  FactoryBuilderConfig copyWith({
    BaseTestController Function(TestProject project)? controllerFactory,
    TestResultManager Function()? testResultManagerFactory,
    Widget Function(BuildContext context)? mainPageBuilder,
    Widget Function(BuildContext context, TestMode mode)? testProjectListPageBuilder,
    Widget Function(BuildContext context, TestProject project)? testProjectPageBuilder,
    Widget Function(BuildContext context)? testResultBuilder,
  }) {
    return FactoryBuilderConfig(
      controllerFactory: controllerFactory ?? this.controllerFactory,
      testResultManagerFactory: testResultManagerFactory ?? this.testResultManagerFactory,
      mainPageBuilder: mainPageBuilder ?? this.mainPageBuilder,
      testProjectListPageBuilder: testProjectListPageBuilder ?? this.testProjectListPageBuilder,
      testProjectPageBuilder: testProjectPageBuilder ?? this.testProjectPageBuilder,
      testResultBuilder: testResultBuilder ?? this.testResultBuilder,
    );
  }

  static final FactoryBuilderConfig defaultConfig = FactoryBuilderConfig(
    controllerFactory: _defaultControllerFactory,
    testResultManagerFactory: _defaultTestResultManagerFactory,
    testProjectPageBuilder: _defaultTestProjectPageBuilder,
    mainPageBuilder: _defaultMainPageBuilder,
    testProjectListPageBuilder: _defaultTestProjectListPageBuilder,
    testResultBuilder: _defaultTestResultBuilder,
  );
}

BaseTestController _defaultControllerFactory(TestProject project) {
  return switch (project) {
    TestProject.deviceInfo => DeviceInfoTestController(),
    TestProject.screen => ScreenTestController(),
    TestProject.screenTouch => ScreenTouchTestController(),
    TestProject.wifi => WifiTestController(),
    TestProject.bottomShell => BottomShellTestController(),
    TestProject.bluetooth => BluetoothTestController(),
    TestProject.audio => AudioTestController(),
    TestProject.zigbee => ZigbeeTestController(),
    TestProject.key => KeyTestController(),
    TestProject.humiture => HumitureTestController(),
    TestProject.microphone => MicrophoneTestController(),
    TestProject.motor => MotorTestController(),
  };
}

T _defaultTestResultManagerFactory<T extends TestResultManager>() {
  throw UnimplementedError();
}

Widget _defaultTestProjectPageBuilder(BuildContext context, TestProject project) {
  throw UnimplementedError();
}

Widget _defaultMainPageBuilder(BuildContext context) {
  throw UnimplementedError();
}

Widget _defaultTestProjectListPageBuilder(BuildContext context, TestMode mode) {
  throw UnimplementedError();
}

Widget _defaultTestResultBuilder(BuildContext context) {
  throw UnimplementedError();
}
