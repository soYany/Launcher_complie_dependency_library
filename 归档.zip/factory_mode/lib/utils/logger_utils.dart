import 'dart:core' as core;

class LoggerUtils {
  static void print(core.String message) {
    // ignore: avoid_print
    core.print(message);
  }
}
