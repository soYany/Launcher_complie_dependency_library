#!/usr/bin/env bash
flutter test --update-goldens test/image_test.dart
flutter test --update-goldens test/painter_test.dart
