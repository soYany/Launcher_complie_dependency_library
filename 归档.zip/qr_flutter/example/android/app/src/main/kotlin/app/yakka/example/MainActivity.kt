package app.yakka.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
