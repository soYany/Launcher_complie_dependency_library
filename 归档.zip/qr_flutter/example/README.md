<img src="https://storage.googleapis.com/product-logos/logo_qr_flutter.png" align="center" width="200">

This is the example project for the QR.Flutter library. It contains a simple example that you can modify / tweak to test the various options that the `qr_flutter` library exposes.

# Running the app

Simply run `flutter run` or open the project in your IDE of choice and give it a run!

Have fun!