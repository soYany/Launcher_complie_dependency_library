# carousel_slider_example

This exmaple shows four carousel slider examples:

- Image slider with custom button control
- Image slider with custom caption
- Image slider with full width display
- Image slider with indicator

# Running

```
flutter run
```

# Building

```
flutter build ios # or flutter build apk
```