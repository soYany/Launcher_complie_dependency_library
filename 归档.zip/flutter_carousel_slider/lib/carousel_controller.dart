import 'dart:async';

import 'package:flutter/material.dart';

import 'carousel_options.dart';
import 'carousel_state.dart';
import 'utils.dart';

abstract class CarouselController {
  bool get ready;

  Future<void> nextPage({Duration duration, Curve curve});

  Future<void> previousPage({Duration duration, Curve curve});

  void jumpToPage(int page);

  Future<void> animateToPage(int page, {Duration duration, Curve curve});

  void startAutoPlay();

  void stopAutoPlay();

  factory CarouselController() => CarouselControllerImpl();
}

class CarouselControllerImpl implements CarouselController {
  CarouselState? _state;

  set state(CarouselState? state) {
    _state = state;
  }

  CarouselState get _privateState => _state!;

  void _setModeController() => _privateState.changeMode(CarouselPageChangedReason.controller);

  @override
  bool get ready => _state != null;

  /// Animates the controlled [CarouselSlider] to the next page.
  ///
  /// The animation lasts for the given duration and follows the given curve.
  /// The returned [Future] resolves when the animation completes.
  Future<void> nextPage({Duration duration = const Duration(milliseconds: 300), Curve curve = Curves.linear}) async {
    final bool isNeedResetTimer = _privateState.options.pauseAutoPlayOnManualNavigate;
    if (isNeedResetTimer) {
      _privateState.onResetTimer();
    }
    _setModeController();
    await _privateState.pageController.nextPage(duration: duration, curve: curve);
    if (isNeedResetTimer) {
      _privateState.onResumeTimer();
    }
  }

  /// Animates the controlled [CarouselSlider] to the previous page.
  ///
  /// The animation lasts for the given duration and follows the given curve.
  /// The returned [Future] resolves when the animation completes.
  Future<void> previousPage(
      {Duration duration = const Duration(milliseconds: 300), Curve curve = Curves.linear}) async {
    final bool isNeedResetTimer = _privateState.options.pauseAutoPlayOnManualNavigate;
    if (isNeedResetTimer) {
      _privateState.onResetTimer();
    }
    _setModeController();
    await _privateState.pageController.previousPage(duration: duration, curve: curve);
    if (isNeedResetTimer) {
      _privateState.onResumeTimer();
    }
  }

  /// Changes which page is displayed in the controlled [CarouselSlider].
  ///
  /// Jumps the page position from its current value to the given value,
  /// without animation, and without checking if the new value is in range.
  void jumpToPage(int page) {
    final index = getRealIndex(_privateState.pageController.page!.toInt(),
        _privateState.realPage - _privateState.initialPage, _privateState.itemCount);

    _setModeController();
    final int pageToJump = _privateState.pageController.page!.toInt() + page - index;
    return _privateState.pageController.jumpToPage(pageToJump);
  }

  /// Animates the controlled [CarouselSlider] from the current page to the given page.
  ///
  /// The animation lasts for the given duration and follows the given curve.
  /// The returned [Future] resolves when the animation completes.
  Future<void> animateToPage(int page,
      {Duration? duration = const Duration(milliseconds: 300), Curve? curve = Curves.linear}) async {
    final bool isNeedResetTimer = _privateState.options.pauseAutoPlayOnManualNavigate;
    if (isNeedResetTimer) {
      _privateState.onResetTimer();
    }
    final index = getRealIndex(_privateState.pageController.page!.toInt(),
        _privateState.realPage - _privateState.initialPage, _privateState.itemCount);
    int smallestMovement = page - index;
    if (_privateState.options.enableInfiniteScroll && _privateState.options.animateToClosest) {
      if ((page - index).abs() > (page + _privateState.itemCount - index).abs()) {
        smallestMovement = page + _privateState.itemCount - index;
      } else if ((page - index).abs() > (page - _privateState.itemCount - index).abs()) {
        smallestMovement = page - _privateState.itemCount - index;
      }
    }
    _setModeController();
    await _privateState.pageController.animateToPage(_privateState.pageController.page!.toInt() + smallestMovement,
        duration: duration!, curve: curve!);
    if (isNeedResetTimer) {
      _privateState.onResumeTimer();
    }
  }

  /// Starts the controlled [CarouselSlider] autoplay.
  ///
  /// The carousel will only autoPlay if the [autoPlay] parameter
  /// in [CarouselOptions] is true.
  void startAutoPlay() {
    _privateState.onResumeTimer();
  }

  /// Stops the controlled [CarouselSlider] from autoplaying.
  ///
  /// This is a more on-demand way of doing this. Use the [autoPlay]
  /// parameter in [CarouselOptions] to specify the autoPlay behaviour of the carousel.
  void stopAutoPlay() {
    _privateState.onResetTimer();
  }
}
