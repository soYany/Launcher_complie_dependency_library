## [2.1.1] 
- Fix null exception in previous getx versions

## [2.1.0] 
- Add support to Getx5

## [2.0.3] 
- update to lastest getx

## [2.0.2] 
- update dependencies

## [2.0.0] 
- Null-safety support (@Ascenio) and fixes #49, #53 and #54 (@SquishyOctopus)

## [1.4.0] 
- Added failure recover backup

## [1.3.2] 
- Added compatibility with Getx 3.15.0

## [1.3.1] 
- Added compatibility with Getx 3.10.2

## [1.3.0] 
- Added ReadWriteValue

## [1.2.0] 
- Added writeInMemory and save methods

## [1.1.4] 
- Prevent spaces on database.gs

## [1.1.3] 
- Fix unnecessary imports

## [1.1.2] 
- Added Benchmarks

## [1.1.1] 
- Added Examples

## [1.1.0] 
- Added Container listeners

## [1.0.3] 
- Added repo

## [1.0.2] 
- Added docs

## [1.0.1] 
- Added docs

## [1.0.0] 
- Release to Get 3.0
