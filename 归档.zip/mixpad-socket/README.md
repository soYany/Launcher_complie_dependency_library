## 使用说明

### 1.添加依赖

```
mixpad_socket:
    git:
      url: git@gitlab.orviboserver.com:orvibo-mixpad/mixpad-socket.git
      ref: ${tag} # tag 对应版本
```

### 2.初始化
在使用前调用`await MixPadSocket().init()`进行初始化

### 3.使用
#### 1:调用`MixPadSocket().setMessageListener(MessageDataCallback listener)`设置消息监听，收到的所有消息都会回调至此
#### 2:调用`MixPadSocket().setConnectStatusListener(void Function(ConnectStatus status) listener)`设置连接状态变化监听
#### 3:调用`MixPadSocket().setEventListener(String eventName,MessageDataCallback listener)`设置对应event消息监听,重复设置将覆盖
#### 4:调用`MixPadSocket().sendMessage(dynamic message,{int retryCount = 0,Duration intervalTimeout = const Duration(milliseconds: 3000),bool isNeedResponse = true})`发送指令
    message:指令内容 支持json String,Map,Class,Class需要包含toJson方法，指令内容无法解析时将抛出FormatException
    retryCount:超时重试次数
    intervalTimeout:超时时长
    isNeedResponse:此指令是否需要等待回复,为true时将等待并返回此指令的执行结果,为false时立即返回执行成功
    返回值:isNeedResponse为false时将返回[EventMessageResult.success],为true时返回值[EventMessageResult],超时将返回[EventMessageResult.timeout],通信服务未连接时将返回[EventMessageResult.connectError]
#### 5:调用`MixPadSocket().startConnect({String ip="localhost",int port=7520})`开始连接通信服务
#### 6:调用`MixPadSocket().close()`关闭mixpad_socket服务,再次使用需要重新初始化

