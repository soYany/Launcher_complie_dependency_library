import 'dart:convert';

import 'package:mixpad_socket/src/utils.dart';

const String heartEvent = 'web_communication_heart';
const int nullErrorCode = -10019;
const int successCode = 0;

const int statusMaybeSuccess = 10000;
const int statusTimeout = -10000;
const int statusConnectError = -10001;

enum ConnectStatus {
  idle,
  connecting,
  connected, // 已连接
  failed, // 失败
  closed, // 连接关闭
}

enum ConnectType { native, proxy }

enum LogLevel { info, debug, warn, error }

enum RemoteAction {
  setOption,
  connectService,
  disconnectService,
  sendMessage,
  registerEvent,
  unregisterEvent,
  registerEventParse,
  unregisterEventParse,
  registerPrintCallback,
  unregisterPrintCallback,
  startProxyService,
  closeProxyService,
  sendMessageProxyClient,
  readBlackboard,
  writeBlackboard,
  watchdog,
  watchdogStop,
  processExit,
}

enum LocalAction {
  connectStatusChange,
  onReceive,
  onPrint,
  readBlackboardResult,
  writeBlackboardResult,
}

class RemoteActionEntity {
  RemoteActionEntity(this.action, [this.data]);

  final RemoteAction action;
  final dynamic data;
}

class LocalActionEntity {
  LocalActionEntity(this.action, this.data);

  final LocalAction action;
  final dynamic data;
}

typedef ConnectStatusChangeCallback = void Function(ConnectStatus status);
typedef MessageDataCallback = void Function(EventMessageResult message);
typedef ParseDataCallback = dynamic Function(dynamic);
typedef PrintCallback = void Function(LogLevel, String);

class EventMessage {
  EventMessage({required this.event, dynamic data, int? serial})
      : serial = serial ?? Utils.generateSerial(),
        data = _convertString(data);

  EventMessage.fromJson(Map<String, dynamic> json)
      : serial = (json['serial'] ?? Utils.generateSerial()) as int,
        event = json['event'] as String,
        data = json['data'] as String?;

  int serial;
  String? data;
  String event;

  @override
  String toString() => 'EventMessage{event: $event, serial: $serial, data: $data}';

  static String? _convertString(dynamic data) {
    if (data == null || data is String) {
      return data as String?;
    } else {
      return jsonEncode(data);
    }
  }

  Map<String, dynamic> toJson() => <String, dynamic>{'event': event, 'serial': serial, 'data': data};
}

class EventMessageResult {
  EventMessageResult(this.status, this.serial, this.event, this.data);

  EventMessageResult.fromJson(Map<String, dynamic> json)
      : event = json['event'] as String,
        data = json['data'] == 'NULL' ? null : json['data'],
        status =
            json['res_code'] is String ? int.tryParse(json['res_code'] as String) ?? 0 : json['res_code'] as int? ?? 0,
        serial = json['serial'] as int? ?? -1;

  /// liyang: 从local_isolate传入的message未经过解析 data大概率是string类型 考虑本地异常时data为null
  EventMessageResult._fromMessage(EventMessage message, this.status)
      : event = message.event,
        data = null,
        serial = message.serial;

  factory EventMessageResult.success(EventMessage message) => EventMessageResult._fromMessage(message, 10000);

  factory EventMessageResult.timeout(EventMessage message) => EventMessageResult._fromMessage(message, -10000);

  factory EventMessageResult.connectError(EventMessage message) => EventMessageResult._fromMessage(message, -10001);

  final int status;
  final int serial;
  final String event;
  dynamic data;

  bool get isSuccess => status == 0 || status == statusMaybeSuccess;

  @override
  String toString() => 'EventMessageResult{event: $event, status: $status, serial: $serial, data: $data}';

  Map<String, dynamic> toJson() =>
      <String, dynamic>{'event': event, 'data': data, 'res_code': status, 'serial': serial};
}

class ReadBlackboardMessage {
  ReadBlackboardMessage({required this.serviceName, required this.key, this.length = 50, int? serial})
      : serial = serial ?? Utils.generateSerial();

  final String serviceName;
  final String key;
  final int length;
  final int serial;

  static const String eventName = "read_blackboard_PROXY";

  EventMessage toEventMessage() => EventMessage(
        event: eventName,
        data: <String, dynamic>{
          'serviceName': serviceName,
          'key': key,
          'length': length,
        },
        serial: serial,
      );

  static ReadBlackboardMessage? fromEventMessage(EventMessage message) {
    try {
      if (message.event == eventName) {
        final String? data = message.data;
        if (data != null) {
          final Map<String, dynamic> dataMap = jsonDecode(data) as Map<String, dynamic>;
          final String? serviceName = dataMap['serviceName'] as String?;
          final String? key = dataMap['key'] as String?;
          final int? length = dataMap['length'] as int?;
          if (serviceName != null && key != null && length != null) {
            return ReadBlackboardMessage(
              serviceName: serviceName,
              key: key,
              length: length,
              serial: message.serial,
            );
          }
        }
      }
    } catch (_) {}

    return null;
  }

  @override
  String toString() => 'ReadBlackboardMessage{serviceName: $serviceName, key: $key, length: $length serial: $serial}';
}

class ReadBlackboardMessageResult extends ReadBlackboardMessage {
  ReadBlackboardMessageResult({
    required super.serviceName,
    required super.key,
    required super.serial,
    required this.value,
    required this.resultCode,
  });

  ReadBlackboardMessageResult.fromMessage({
    required ReadBlackboardMessage message,
    required this.value,
    required this.resultCode,
  }) : super(serviceName: message.serviceName, key: message.key, serial: message.serial);

  EventMessageResult toEventMessageResult() {
    return EventMessageResult(
      0,
      serial,
      ReadBlackboardMessage.eventName,
      <String, dynamic>{
        'serviceName': serviceName,
        'key': key,
        'value': value,
        'resultCode': resultCode,
      },
    );
  }

  static ReadBlackboardMessageResult? fromEventMessageResult(EventMessageResult message) {
    try {
      if (message.event == ReadBlackboardMessage.eventName) {
        final Map<String, dynamic>? dataMap = message.data;
        if (dataMap != null) {
          final String? serviceName = dataMap['serviceName'] as String?;
          final String? key = dataMap['key'] as String?;
          final String? value = dataMap['value'] as String?;
          final int? resultCode = dataMap['resultCode'] as int?;
          if (serviceName != null && key != null && value != null && resultCode != null) {
            return ReadBlackboardMessageResult(
              serviceName: serviceName,
              key: key,
              value: value,
              resultCode: resultCode,
              serial: message.serial,
            );
          }
        }
      }
    } catch (_) {}
    return null;
  }

  final String? value;
  final int resultCode;

  @override
  String toString() =>
      'ReadBlackboardMessageResult{serviceName: $serviceName, key: $key, serial: $serial, value: $value, resultCode: $resultCode}';
}

class WriteBlackboardMessage {
  WriteBlackboardMessage({required this.key, required this.value, int? serial})
      : serial = serial ?? Utils.generateSerial();

  final String key;
  final String value;
  final int serial;

  static const String eventName = "write_blackboard_PROXY";

  EventMessage toEventMessage() => EventMessage(
        event: eventName,
        data: <String, dynamic>{
          'key': key,
          'value': value,
        },
        serial: serial,
      );

  static WriteBlackboardMessage? fromEventMessage(EventMessage message) {
    try {
      if (message.event == eventName) {
        final String? data = message.data;
        if (data != null) {
          final Map<String, dynamic> dataMap = jsonDecode(data) as Map<String, dynamic>;
          final String? key = dataMap['key'] as String?;
          final String? value = dataMap['value'] as String?;
          if (key != null && value != null) {
            WriteBlackboardMessage(
              key: key,
              value: value,
              serial: message.serial,
            );
          }
        }
      }
    } catch (_) {}

    return null;
  }

  @override
  String toString() => 'ReadBlackboardMessage{key: $key, value: $value, serial: $serial}';
}

class WriteBlackboardMessageResult extends WriteBlackboardMessage {
  WriteBlackboardMessageResult({
    required super.key,
    required super.serial,
    required super.value,
    required this.resultCode,
  });

  WriteBlackboardMessageResult.fromMessage({
    required WriteBlackboardMessage message,
    required int resultCode,
  }) : this(key: message.key, value: message.value, resultCode: resultCode, serial: message.serial);

  final int resultCode;

  EventMessageResult toEventMessageResult() {
    return EventMessageResult(
      0,
      serial,
      WriteBlackboardMessage.eventName,
      <String, dynamic>{
        'key': key,
        'value': value,
        'resultCode': resultCode,
      },
    );
  }

  static WriteBlackboardMessageResult? fromEventMessageResult(EventMessageResult message) {
    try {
      if (message.event == WriteBlackboardMessage.eventName) {
        final Map<String, dynamic>? dataMap = message.data;
        if (dataMap != null) {
          final String? key = dataMap['key'] as String?;
          final String? value = dataMap['value'] as String?;
          final int? resultCode = dataMap['resultCode'] as int?;
          if (key != null && value != null && resultCode != null) {
            WriteBlackboardMessageResult(
              key: key,
              value: value,
              resultCode: resultCode,
              serial: message.serial,
            );
          }
        }
      }
    } catch (_) {}
    return null;
  }

  @override
  String toString() =>
      'WriteBlackboardMessageResult{key: $key, serial: $serial, value: $value, resultCode: $resultCode}';
}

class MixPadSocketOption {
  const MixPadSocketOption({
    this.isPrint = true,
    this.isPrintHeartbeat = false,
    this.isPrintJsonFormat = true,
    this.isPrintReceiveContent = false,
  });

  final bool isPrint;

  final bool isPrintHeartbeat;

  final bool isPrintJsonFormat;

  final bool isPrintReceiveContent;
}
