import 'dart:async';
import 'dart:convert';
import 'dart:isolate';

import 'package:flutter/foundation.dart';
import 'package:mixpad_socket/src/entity/entity.dart';
import 'package:mixpad_socket/src/messenger/message_io_base.dart';
import 'package:mixpad_socket/src/messenger/native_message_service.dart';
import 'package:mixpad_socket/src/messenger/proxy/proxy_web_socket_message_service.dart';
import 'package:mixpad_socket/src/messenger/proxy/proxy_web_socket_service.dart';
import 'package:mixpad_socket/src/native/native_service_api.dart';
import 'package:mixpad_socket/src/utils.dart';

class RemoteIsolateHandler {
  static MixPadSocketOption option = const MixPadSocketOption();
  static MessageIoBase? _io;
  static SendPort? _sendPort;

  static Future<void> handler(SendPort sendPort) async {
    final ReceivePort receivePort = ReceivePort();
    sendPort.send(receivePort.sendPort);
    _sendPort = sendPort;
    await for (final dynamic msg in receivePort) {
      try {
        _handlerMessage(msg);
      } catch (e, s) {
        handleUncaughtError(e, s);
      }
    }
  }

  static void _handlerMessage(dynamic msg) {
    final RemoteActionEntity(:RemoteAction action, :dynamic data) = msg as RemoteActionEntity;
    switch (action) {
      case RemoteAction.connectService:
        final (ConnectType connectType, List<dynamic> connectParam) = data as (ConnectType, List<dynamic>);
        _startConnect(connectType, connectParam);
        break;
      case RemoteAction.disconnectService:
        _disconnect();
        break;
      case RemoteAction.sendMessage:
        _sendMessage(data as EventMessage);
        break;
      case RemoteAction.registerEvent:
        _registerEvent(data as String);
        break;
      case RemoteAction.unregisterEvent:
        _unregisterEvent(data as String);
        break;
      case RemoteAction.registerEventParse:
        final (String eventName, ParseDataCallback parseFunc) = data as (String, ParseDataCallback);
        _registerEventParse(eventName, parseFunc);

        break;
      case RemoteAction.unregisterEventParse:
        _unregisterEventParse(data as String);
        break;
      case RemoteAction.setOption:
        option = (data as MixPadSocketOption?) ?? const MixPadSocketOption();
        break;
      case RemoteAction.registerPrintCallback:
        _registerPrintCallback();
        break;
      case RemoteAction.unregisterPrintCallback:
        _unregisterPrintCallback();
        break;
      case RemoteAction.startProxyService:
        _startProxyService();
        break;
      case RemoteAction.closeProxyService:
        _closeProxyService();
        break;
      case RemoteAction.sendMessageProxyClient:
        final EventMessage message = data as EventMessage;
        _sendMessageProxyClient(message);
        break;
      case RemoteAction.readBlackboard:
        _readBlackboardValue(data as ReadBlackboardMessage);
        break;
      case RemoteAction.writeBlackboard:
        _writeBlackboardValue(data as WriteBlackboardMessage);
        break;
      case RemoteAction.watchdog:
        final (String processName, int timeoutSec) = data as (String, int);
        _watchdog(processName, timeoutSec);
        break;
      case RemoteAction.watchdogStop:
        _watchdogStop(data as String);
        break;
      case RemoteAction.processExit:
        _processExit(data as String);
        break;
    }
  }

  static void _sendAction(LocalActionEntity entity) {
    _sendPort?.send(entity);
  }

  //发送数据锁
  static Completer<void>? _sendLockCompleter;

  static Future<void> _sendReceiveData(EventMessageResult data) async {
    final Completer<void>? lock = _sendLockCompleter;
    if (lock != null && !lock.isCompleted) {
      await lock.future;
    }
    final Completer<void> newLock = Completer<void>();
    _sendLockCompleter = newLock;
    try {
      final ParseDataCallback? _computeParseFunc = _registerParse[data.event];
      if (_computeParseFunc != null) {
        //不捕获可能出现的异常，将由[_errorReceivePort]转发到main Zone
        final dynamic rawData = data.data;
        if (Utils.isLongMessage(rawData)) {
          //如果数据长度大于800，则使用compute
          data.data = await compute(_computeParseFunc, rawData);
        } else {
          //如果数据长度小于800或者不是String，则直接调用_parseFunc
          data.data = _computeParseFunc(rawData);
        }
      }
      _sendAction(LocalActionEntity(LocalAction.onReceive, data));
    } finally {
      _sendLockCompleter = null;
      newLock.complete();
    }
  }

  static void _startConnect(ConnectType connectType, List<dynamic> connectParam) {
    switch (connectType) {
      case ConnectType.native:
        _io = NativeMessageService();
        break;
      case ConnectType.proxy:
        _io = ProxyWebSocketMessageService();
        break;
    }
    _io?.onReceiveListeners.add(_sendReceiveData);
    _io?.startService(
        connectParam: connectParam,
        connectStatusChangeCallback: (ConnectStatus status) {
          _sendAction(LocalActionEntity(LocalAction.connectStatusChange, status));
        });
  }

  static void _disconnect() {
    _io?.onReceiveListeners.remove(_sendReceiveData);
    _io?.closeService();
    _io = null;
    ProxyWebSocketService().closeProxyService();
  }

  static void _sendMessage(EventMessage message) {
    _io?.sendMessage(message);
  }

  static final Map<String, ParseDataCallback> _registerParse = <String, ParseDataCallback>{};

  static void _registerEventParse(String eventName, ParseDataCallback parse) {
    _registerParse[eventName] = parse;
  }

  static void _unregisterEventParse(String eventName) {
    _registerParse.remove(eventName);
  }

  static final Set<String> _registerEvents = <String>{};

  static void _registerEvent(String eventName) {
    _registerEvents.add(eventName);
  }

  static void _unregisterEvent(String eventName) {
    _registerEvents.remove(eventName);
  }

  static void _registerPrintCallback() {
    MessageIoBase.printCallback = _sendPrintMessage;
  }

  static void _unregisterPrintCallback() {
    MessageIoBase.printCallback = null;
  }

  static void _sendPrintMessage(LogLevel level, String data) {
    _sendAction(LocalActionEntity(LocalAction.onPrint, (level, data)));
  }

  static void _startProxyService() {
    final MessageIoBase? inServiceIO = _io;
    if (inServiceIO != null) {
      ProxyWebSocketService().startProxyService(inServiceIO);
    } else {
      throw Exception('未连接到任何后端服务');
    }
  }

  static void _closeProxyService() {
    ProxyWebSocketService().closeProxyService();
  }

  static void _sendMessageProxyClient(EventMessage message) {
    ProxyWebSocketService().sendMessageToClient(jsonEncode(message));
  }

  static Future<void> _readBlackboardValue(ReadBlackboardMessage message) async {
    final MessageIoBase? io = _io;
    if (io != null) {
      final ReadBlackboardMessageResult result = await io.readBlackboard(message);
      _sendAction(LocalActionEntity(LocalAction.readBlackboardResult, result));
    }
  }

  static Future<void> _writeBlackboardValue(WriteBlackboardMessage message) async {
    final MessageIoBase? io = _io;
    if (io != null) {
      final WriteBlackboardMessageResult result = await io.writeBlackboard(message);
      _sendAction(LocalActionEntity(LocalAction.writeBlackboardResult, result));
    }
  }

  static void _watchdog(String processName, int timeoutSec) {
    NativeServiceApi().watchdog(processName, timeoutSec);
  }

  static void _watchdogStop(String processName) {
    NativeServiceApi().watchdogStop(processName);
  }

  static int _processExit(String processName) => NativeServiceApi().processExit(processName);

  static void handleUncaughtError(Object error, StackTrace stackTrace) {
    _sendPort?.send(<String>[error.toString(), stackTrace.toString()]);
  }
}
