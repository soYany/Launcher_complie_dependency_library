import 'dart:async';
import 'dart:convert';
import 'dart:isolate';

import 'package:flutter/foundation.dart';
import 'package:mixpad_socket/src/entity/entity.dart';

class LocalIsolateHandler {
  static SendPort? _sendPort;

  static final Map<String, MessageDataCallback> eventListener = <String, MessageDataCallback>{};
  static MessageDataCallback? onReceiveListener;
  static PrintCallback? onPrint;
  static void Function(ConnectStatus status)? onConnectStatusListener;

  static void setSendPort(SendPort sendPort) {
    _sendPort = sendPort;
  }

  static void handler(LocalActionEntity msg) {
    final LocalAction action = msg.action;
    final dynamic data = msg.data;
    switch (action) {
      case LocalAction.connectStatusChange:
        onConnectStatusListener?.call(data as ConnectStatus);
        break;
      case LocalAction.onReceive:
        final EventMessageResult result = data as EventMessageResult;
        final String event = result.event;
        onReceiveListener?.call(result);
        eventListener[event]?.call(result);
        final int serial = result.serial;
        final Completer<EventMessageResult>? completer = _cacheMessageCompleter[serial];
        if (completer != null) {
          if (!completer.isCompleted) {
            completer.complete(result);
          }
          _cacheMessageCompleter.remove(serial);
        }
        break;
      case LocalAction.onPrint:
        if (data is (LogLevel, String)) {
          final (LogLevel logLevel, String logData) = data;
          onPrint?.call(logLevel, logData);
        }
        break;
      case LocalAction.readBlackboardResult:
        final ReadBlackboardMessageResult result = data as ReadBlackboardMessageResult;
        final int serial = result.serial;
        final Completer<ReadBlackboardMessageResult>? completer = _cacheReadBlackboardMessageCompleter[serial];
        if (completer != null) {
          if (!completer.isCompleted) {
            completer.complete(result);
          }
          _cacheReadBlackboardMessageCompleter.remove(serial);
        }
        break;
      case LocalAction.writeBlackboardResult:
        final WriteBlackboardMessageResult result = data as WriteBlackboardMessageResult;
        final int serial = result.serial;
        final Completer<WriteBlackboardMessageResult>? completer = _cacheWriteBlackboardMessageCompleter[serial];
        if (completer != null) {
          if (!completer.isCompleted) {
            completer.complete(result);
          }
          _cacheWriteBlackboardMessageCompleter.remove(serial);
        }
        break;
      default:
        break;
    }
  }

  static void _sendAction(RemoteActionEntity action) {
    _sendPort?.send(action);
  }

  static void startConnect((ConnectType, List<dynamic>) param) {
    _sendAction(RemoteActionEntity(RemoteAction.connectService, param));
  }

  static void disconnect() {
    _sendAction(RemoteActionEntity(RemoteAction.disconnectService));
  }

  static final Map<int, Completer<EventMessageResult>> _cacheMessageCompleter = <int, Completer<EventMessageResult>>{};

  static EventMessage _computeDecodeMessage(dynamic message) {
    dynamic rawMessage;
    if (message is String) {
      rawMessage = jsonDecode(message);
    } else if (message is! Map) {
      rawMessage = jsonDecode(jsonEncode(message));
    }
    if (rawMessage is Map) {
      if (rawMessage is Map<String, dynamic>) {
        return EventMessage.fromJson(rawMessage);
      } else {
        return EventMessage.fromJson(Map<String, dynamic>.from(rawMessage));
      }
    } else {
      throw FormatException(message.toString());
    }
  }

  static Future<EventMessageResult> sendMessage(dynamic message, int retryCount, Duration intervalTimeout,
      {required bool isNeedResponse}) async {
    _cacheMessageCompleter.removeWhere((int key, Completer<EventMessageResult> value) => value.isCompleted);
    final Completer<EventMessageResult> result = Completer<EventMessageResult>();
    final EventMessage eventMessage;
    try {
      if (message is EventMessage) {
        eventMessage = message;
      } else {
        eventMessage = await compute(_computeDecodeMessage, message);
      }
    } catch (e, s) {
      result.completeError(e, s);
      return result.future;
    }

    if (isNeedResponse) {
      _cacheMessageCompleter[eventMessage.serial] = result;
    } else {
      result.complete(EventMessageResult.success(eventMessage));
    }
    _sendAction(RemoteActionEntity(RemoteAction.sendMessage, eventMessage));

    return result.future.timeout(intervalTimeout, onTimeout: () {
      final int serial = eventMessage.serial;
      _cacheMessageCompleter.remove(serial)?.completeError(
          TimeoutException("Future not completed, retry count $retryCount", intervalTimeout), StackTrace.empty);
      if (retryCount > 0) {
        return sendMessage(message, retryCount - 1, intervalTimeout, isNeedResponse: isNeedResponse);
      } else {
        return Future<EventMessageResult>.value(EventMessageResult.timeout(eventMessage));
      }
    });
  }

  static void setEventListener(String eventName, MessageDataCallback listener) {
    _sendAction(RemoteActionEntity(RemoteAction.registerEvent, eventName));
    LocalIsolateHandler.eventListener[eventName] = listener;
  }

  static void removeEventListener(String eventName) {
    _sendAction(RemoteActionEntity(RemoteAction.unregisterEvent, eventName));
    LocalIsolateHandler.eventListener.remove(eventName);
  }

  static void registerParseFunction(String eventName, ParseDataCallback parse) {
    _sendAction(RemoteActionEntity(RemoteAction.registerEventParse, (eventName, parse)));
  }

  static void unregisterParseFunction(String eventName) {
    _sendAction(RemoteActionEntity(RemoteAction.unregisterEventParse, eventName));
  }

  static void setOption(MixPadSocketOption option) {
    _sendAction(RemoteActionEntity(RemoteAction.setOption, option));
  }

  static void registerPrintCallback(PrintCallback print) {
    onPrint = print;
    _sendAction(RemoteActionEntity(RemoteAction.registerPrintCallback));
  }

  static void unregisterPrintCallback() {
    onPrint = null;
    _sendAction(RemoteActionEntity(RemoteAction.unregisterPrintCallback));
  }

  static void startProxyService() {
    _sendAction(RemoteActionEntity(RemoteAction.startProxyService));
  }

  static void closeProxyService() {
    _sendAction(RemoteActionEntity(RemoteAction.closeProxyService));
  }

  static void sendMessageProxyClient(EventMessage message) {
    _sendAction(RemoteActionEntity(RemoteAction.sendMessageProxyClient, message));
  }

  static final Map<int, Completer<ReadBlackboardMessageResult>> _cacheReadBlackboardMessageCompleter =
      <int, Completer<ReadBlackboardMessageResult>>{};

  static Future<ReadBlackboardMessageResult> readBlackboardValue(
    ReadBlackboardMessage message, {
    Duration intervalTimeout = const Duration(milliseconds: 3000),
  }) {
    _cacheReadBlackboardMessageCompleter
        .removeWhere((int key, Completer<ReadBlackboardMessageResult> value) => value.isCompleted);
    final Completer<ReadBlackboardMessageResult> result = Completer<ReadBlackboardMessageResult>();
    _cacheReadBlackboardMessageCompleter[message.serial] = result;
    _sendAction(RemoteActionEntity(RemoteAction.readBlackboard, message));
    return result.future.timeout(intervalTimeout, onTimeout: () {
      final int serial = message.serial;
      _cacheReadBlackboardMessageCompleter.remove(serial);
      result
          .complete(ReadBlackboardMessageResult.fromMessage(message: message, value: null, resultCode: statusTimeout));
      return result.future;
    });
  }

  static final Map<int, Completer<WriteBlackboardMessageResult>> _cacheWriteBlackboardMessageCompleter =
      <int, Completer<WriteBlackboardMessageResult>>{};

  static Future<WriteBlackboardMessageResult> writeBlackboardValue(
    WriteBlackboardMessage message, {
    Duration intervalTimeout = const Duration(milliseconds: 3000),
  }) {
    _cacheWriteBlackboardMessageCompleter
        .removeWhere((int key, Completer<WriteBlackboardMessageResult> value) => value.isCompleted);
    final Completer<WriteBlackboardMessageResult> result = Completer<WriteBlackboardMessageResult>();
    _cacheWriteBlackboardMessageCompleter[message.serial] = result;
    _sendAction(RemoteActionEntity(RemoteAction.writeBlackboard, message));
    return result.future.timeout(intervalTimeout, onTimeout: () {
      final int serial = message.serial;
      _cacheWriteBlackboardMessageCompleter.remove(serial);
      result.complete(WriteBlackboardMessageResult.fromMessage(message: message, resultCode: statusTimeout));
      return result.future;
    });
  }

  static void watchdog(String processName, int timeoutSec) {
    _sendAction(RemoteActionEntity(RemoteAction.watchdog, (processName, timeoutSec)));
  }

  static void watchdogStop(String processName) {
    _sendAction(RemoteActionEntity(RemoteAction.watchdogStop, processName));
  }

  static void processExit(String processName) {
    _sendAction(RemoteActionEntity(RemoteAction.processExit, processName));
  }
}
