import 'dart:convert' as convert;
import 'dart:convert';
import 'dart:math';

class Utils {
  static JsonEncoder encoder = const JsonEncoder.withIndent('  ');

  static final Random _random = Random();
  static const String _scopeF = '123456789'; //首位
  static const int _scopeFLength = _scopeF.length;
  static const String _scopeC = '0123456789'; //中间
  static const int _scopeCLength = _scopeC.length;

  static int generateSerial() {
    String result = '';
    for (int i = 0; i < 8; i++) {
      if (i == 0) {
        result = _scopeF[_random.nextInt(_scopeFLength)];
      } else {
        result = result + _scopeC[_random.nextInt(_scopeCLength)];
      }
    }
    return int.parse(result);
  }

  ///对json格式的字符串做格式化处理
  static dynamic stringifyMessage(dynamic message) {
    if (message == null) {
      return null;
    }
    if (message is Map || message is Iterable) {
      return encoder.convert(message);
    } else if (message is String) {
      try {
        final dynamic j = convert.jsonDecode(message);
        return encoder.convert(j);
      } catch (e, s) {
        //ignore: avoid_print
        print('$e\n$s');
        return message;
      }
    } else {
      return message;
    }
  }

  static List<String> splitStringByLength(String str, int fixLength) {
    final List<String> list = <String>[];
    final int divisionIndex = str.length ~/ fixLength;
    final int surplus = str.length % fixLength;
    for (int i = 0; i < divisionIndex; i++) {
      final String tempString = str.substring(i * fixLength, i * fixLength + fixLength);
      list.add(tempString);
    }
    if (surplus != 0) {
      list.add(str.substring(str.length - surplus));
    }
    return list;
  }

  static bool isLongMessage(dynamic message){
    if(message is String){
      return message.length > 800;
    }
    return false;
  }
}
