import 'dart:ffi';
import 'dart:math';

import 'package:ffi/ffi.dart';
import 'package:mixpad_socket/src/entity/entity.dart';

// ignore_for_file: avoid_print

typedef _StartServiceFunc = int Function(Pointer<Utf8>, Pointer<Utf8>, Pointer<Void>, int);
typedef _ServiceEventSendFunc = int Function(Pointer<Utf8>, int);
typedef _BlackboardReadBufFunc = int Function(Pointer<Utf8>, Pointer<Utf8>, Pointer<Utf8>, int);
typedef _BlackboardWriteBufFunc = int Function(Pointer<Utf8>, Pointer<Utf8>, Pointer<Utf8>);
typedef _OrbThreadWatchdog = void Function(Pointer<Utf8>, int, int);
typedef _OrbThreadWatchdogStop = void Function(Pointer<Utf8>, int);
typedef _ProcessExit = int Function(Pointer<Utf8>, int);

class NativeServiceApi {
  factory NativeServiceApi() => _instance ??= NativeServiceApi._();

  NativeServiceApi._() {
    _initApi();
  }

  static NativeServiceApi? _instance;

  ///线程id，后端每次拿到的tid都不一样，造成机制不生效。故由上层模拟固定的tid给后端。
  int? tid;

  void _initApi() {
    tid = Random().nextInt(10000) + 1;
    print('1开始初始化Native API,tid=$tid');

    try {
      final DynamicLibrary guiLib = DynamicLibrary.open('libguiservice.so');

      ///-------通信----------
      _startServiceFunc =
          guiLib.lookupFunction<Int32 Function(Pointer<Utf8>, Pointer<Utf8>, Pointer<Void>, Int64), _StartServiceFunc>(
              'gui_API_StartService');
      _serviceEventSendFunc = guiLib
          .lookupFunction<Int32 Function(Pointer<Utf8>, Int32), _ServiceEventSendFunc>('gui_API_ServiceEventSend');

      ///-------黑板----------
      try {
        _blackboardReadBufFunc = guiLib.lookupFunction<
            Int32 Function(Pointer<Utf8>, Pointer<Utf8>, Pointer<Utf8>, Int32),
            _BlackboardReadBufFunc>('gui_API_BlackboardReadBuf');
      } catch (e, s) {
        print('API BlackboardReadBuf API 初始化异常:$e\n$s');
      }

      ///-------黑板----------
      try {
        _blackboardWriteBufFunc =
            guiLib.lookupFunction<Int32 Function(Pointer<Utf8>, Pointer<Utf8>, Pointer<Utf8>), _BlackboardWriteBufFunc>(
                'gui_API_BlackboardWriteFile');
      } catch (e, s) {
        print('API BlackboardWriteFile API 初始化异常:$e\n$s');
      }

      ///-------守护进程----------
      try {
        _orbThreadWatchdog = guiLib.lookupFunction<Void Function(Pointer<Utf8>, Int32, Int32), _OrbThreadWatchdog>(
            'gui_API_OrbThreadWatchdog');
        _orbThreadWatchdogStop = guiLib.lookupFunction<Void Function(Pointer<Utf8>, Int32), _OrbThreadWatchdogStop>(
            'gui_API_OrbThreadWatchdogStop');
        _orbProcessExit =
            guiLib.lookupFunction<Int32 Function(Pointer<Utf8>, Int32), _ProcessExit>('gui_API_OrbProcessExit');
      } catch (e, s) {
        print('Daemon API 初始化异常:$e\n$s');
      }
    } catch (e, s) {
      print('初始化Native API异常:$e\n$s');
      return;
    }
    print('初始化Native API成功');
  }

  _StartServiceFunc? _startServiceFunc;
  _ServiceEventSendFunc? _serviceEventSendFunc;
  _BlackboardReadBufFunc? _blackboardReadBufFunc;
  _BlackboardWriteBufFunc? _blackboardWriteBufFunc;

  ///喂狗
  _OrbThreadWatchdog? _orbThreadWatchdog;

  //停止喂狗
  _OrbThreadWatchdogStop? _orbThreadWatchdogStop;

  ///退出桌面进程
  _ProcessExit? _orbProcessExit;

  int startService(String serviceName, String version, int nativePort) => using((Arena arena) {
        final Pointer<Utf8> serviceNamePtr = serviceName.toNativeUtf8(allocator: arena);
        final Pointer<Utf8> versionPtr = version.toNativeUtf8(allocator: arena);
        final int result =
            _startServiceFunc?.call(serviceNamePtr, versionPtr, NativeApi.initializeApiDLData, nativePort) ??
                nullErrorCode;
        return result;
      });

  int serviceEventSend(String message) => using((Arena arena) {
        final Pointer<Utf8> messageNative = message.toNativeUtf8(allocator: arena);
        final int result = _serviceEventSendFunc?.call(messageNative, messageNative.length) ?? nullErrorCode;
        return result;
      });

  (int code, String? value) blackboardReadBuf(String blackboardName, String key, int length) => using((Arena arena) {
        final Pointer<Utf8> blackboardNamePtr = blackboardName.toNativeUtf8(allocator: arena);
        final Pointer<Utf8> keyPtr = key.toNativeUtf8(allocator: arena);
        Pointer<Utf8> value = arena<Uint8>(length).cast();
        int result = _blackboardReadBufFunc?.call(blackboardNamePtr, keyPtr, value, length) ?? nullErrorCode;
        if (result > 0) {
          value = arena<Uint8>(result).cast();
          result = _blackboardReadBufFunc?.call(blackboardNamePtr, keyPtr, value, result) ?? nullErrorCode;
        }

        if (result == 0) {
          final String valueStr = value.toDartString();
          return (result, valueStr);
        }
        return (result, null);
      });

  int blackboardWriteBuf(String key, String value) => using((Arena arena) {
        final Pointer<Utf8> blackboardNamePtr = "gui".toNativeUtf8(allocator: arena);
        final Pointer<Utf8> keyPtr = key.toNativeUtf8(allocator: arena);
        final Pointer<Utf8> valuePtr = value.toNativeUtf8(allocator: arena);
        int result = _blackboardWriteBufFunc?.call(blackboardNamePtr, keyPtr, valuePtr) ?? nullErrorCode;
        if (result > 0) {
          result = _blackboardWriteBufFunc?.call(blackboardNamePtr, keyPtr, valuePtr) ?? nullErrorCode;
        }
        return result;
      });

  ///喂狗，timeout:超时，单位秒，超过此时间未喂狗自动重启Launcher
  void watchdog(String processName, int timeout) {
    // print('start launcher hb,processName=$processName,tid=$tid');
    using((Arena arena) => _orbThreadWatchdog?.call(processName.toNativeUtf8(allocator: arena), timeout, tid ?? 1));
  }

  ///停止喂狗
  void watchdogStop(String processName) {
    //print('stop launcher hb,processName=$processName,tid=$tid');
    using((Arena arena) => _orbThreadWatchdogStop?.call(processName.toNativeUtf8(allocator: arena), tid ?? 1));
  }

  ///退出Launcher进程
  int processExit(String processName) => using(
      (Arena arena) => _orbProcessExit?.call(processName.toNativeUtf8(allocator: arena), tid ?? 1) ?? nullErrorCode);
}
