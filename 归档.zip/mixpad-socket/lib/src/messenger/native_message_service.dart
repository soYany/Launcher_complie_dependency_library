import 'dart:async';
import 'dart:convert';
import 'dart:ffi';
import 'dart:isolate';

import 'package:mixpad_socket/src/entity/entity.dart';
import 'package:mixpad_socket/src/messenger/message_io_base.dart';
import 'package:mixpad_socket/src/native/native_service_api.dart';

class NativeMessageService extends MessageIoBase {
  factory NativeMessageService() => instance ??= NativeMessageService._internal();

  NativeMessageService._internal();

  static NativeMessageService? instance;

  @override
  String get logTag => '[Native]';

  ReceivePort? _receivePort;

  bool _isStartMessageSuccess = false;

  @override
  int startService(
      {required List<dynamic> connectParam, required ConnectStatusChangeCallback connectStatusChangeCallback}) {
    super.startService(connectParam: connectParam, connectStatusChangeCallback: connectStatusChangeCallback);
    connectStatus = ConnectStatus.connecting;
    if (_isStartMessageSuccess) {
      connectStatus = ConnectStatus.connected;
      return successCode;
    }
    handlerPrint(LogLevel.info, '开始初始化通信接口');
    final ReceivePort port = ReceivePort();
    _listenerStream(port);
    _receivePort = port;
    final int result =
        NativeServiceApi().startService(connectParam[0] as String, connectParam[1] as String, port.sendPort.nativePort);
    if (result == successCode) {
      _isStartMessageSuccess = true;
      connectStatus = ConnectStatus.connected;
      handlerPrint(LogLevel.info, '初始化通信接口成功');
    } else {
      port.close();
      _receivePort = null;
      connectStatus = ConnectStatus.failed;
      handlerPrint(LogLevel.error, '初始化通信接口失败');
    }
    return result;
  }

  int sendEvent(String message) => NativeServiceApi().serviceEventSend(message);

  @override
  int sendMessage(EventMessage message) {
    super.sendMessage(message);
    return sendEvent(jsonEncode(message));
  }

  @override
  FutureOr<ReadBlackboardMessageResult> readBlackboard(ReadBlackboardMessage message) {
    final (int code, String? value) = NativeServiceApi().blackboardReadBuf(
      message.serviceName,
      message.key,
      message.length,
    );
    return ReadBlackboardMessageResult.fromMessage(message: message, resultCode: code, value: value);
  }

  @override
  FutureOr<WriteBlackboardMessageResult> writeBlackboard(WriteBlackboardMessage message) {
    final int code = NativeServiceApi().blackboardWriteBuf(
      message.key,
      message.value,
    );
    return WriteBlackboardMessageResult.fromMessage(message: message, resultCode: code);
  }

  Future<void> _listenerStream(Stream<dynamic> stream) async {
    await for (final dynamic data in stream) {
      try {
        if (data is! String) {
          throw Exception('数据类型异常:$data');
        }
        await onHandlerRawResultMessage(data);
      } catch (e, s) {
        handleUncaughtError(e, s);
      }
    }
  }

  @override
  void closeService() {
    if (_isStartMessageSuccess) {
      _receivePort?.close();
      _receivePort = null;
      _isStartMessageSuccess = false;
    }
    connectStatus = ConnectStatus.closed;
    handlerPrint(LogLevel.warn, '通信接口关闭');
  }
}
