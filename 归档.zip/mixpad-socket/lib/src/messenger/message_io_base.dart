import 'dart:async';
import 'dart:convert';

import 'package:ansicolor/ansicolor.dart';
import 'package:flutter/foundation.dart';
import 'package:mixpad_socket/src/entity/entity.dart';
import 'package:mixpad_socket/src/isolate/remote_isolate_handler.dart';
import 'package:mixpad_socket/src/utils.dart';

/// Created by liyang on 2022/3/9.
/// @TODO file describe

abstract class MessageIoBase {
  String get logTag => '';

  ConnectStatus _connectStatus = ConnectStatus.idle; // socket状态
  ConnectStatus get connectStatus => _connectStatus;

  set connectStatus(ConnectStatus status) {
    _connectStatus = status;
    onConnectStatusChange?.call(_connectStatus);
  }

  ConnectStatusChangeCallback? onConnectStatusChange;

  Set<Future<void> Function(EventMessageResult)> onReceiveListeners = <Future<void> Function(EventMessageResult)>{};
  Set<void Function(String)> onReceiveRawListeners = <void Function(String)>{};

  @mustCallSuper
  int startService(
      {required List<dynamic> connectParam, required ConnectStatusChangeCallback connectStatusChangeCallback}) {
    onConnectStatusChange = connectStatusChangeCallback;
    ansiColorDisabled = false;
    return successCode;
  }

  void closeService();

  @mustCallSuper
  int sendMessage(EventMessage message) {
    logSendMessage(message);
    return successCode;
  }

  FutureOr<ReadBlackboardMessageResult> readBlackboard(ReadBlackboardMessage message);

  FutureOr<WriteBlackboardMessageResult> writeBlackboard(WriteBlackboardMessage message);

  static EventMessageResult _computeDecodeMessageStr(String messageStr) {
    final dynamic result = json.decode(messageStr);
    return EventMessageResult.fromJson(result as Map<String, dynamic>);
  }

  Future<void> onHandlerRawResultMessage(String messageStr) async {
    final EventMessageResult resultEntity;
    if (Utils.isLongMessage(messageStr)) {
      resultEntity = await compute(_computeDecodeMessageStr, messageStr);
    } else {
      resultEntity = _computeDecodeMessageStr(messageStr);
    }

    try {
      logReceiveMessage(resultEntity);
    } catch (e, s) {
      RemoteIsolateHandler.handleUncaughtError(e, s);
    }

    await onHandlerResultMessage(resultEntity);

    if (resultEntity.event != heartEvent) {
      for (final void Function(String) listener in onReceiveRawListeners) {
        listener.call(messageStr);
      }
    }
  }

  Future<void> onHandlerResultMessage(EventMessageResult message) async {
    if (message.event != heartEvent) {
      for (final Future<void> Function(EventMessageResult message) listener in onReceiveListeners) {
        await listener.call(message);
      }
    }
  }

  final AnsiPen _pen = AnsiPen()..green();

  void logReceiveMessage(EventMessageResult message) {
    if (!RemoteIsolateHandler.option.isPrint) {
      return;
    }
    if (!RemoteIsolateHandler.option.isPrintHeartbeat) {
      if (message.event == heartEvent) {
        return;
      }
    }

    final String formatMsg;
    if (RemoteIsolateHandler.option.isPrintReceiveContent) {
      final bool isPrintJsonFormat = RemoteIsolateHandler.option.isPrintJsonFormat && !kReleaseMode;
      formatMsg = isPrintJsonFormat ? '${Utils.stringifyMessage(jsonEncode(message))}' : jsonEncode(message);
    } else {
      formatMsg = 'event:${message.event} serial:${message.serial}';
    }
    printMessageWrapped('receive data=> $formatMsg');
  }

  void logSendMessage(EventMessage message) {
    const String tag = 'send data=>';
    final String formatMsg;
    if (Utils.isLongMessage(message.data)) {
      formatMsg = 'event:${message.event} serial:${message.serial} length:${message.data?.length ?? 0}';
    } else {
      final bool isPrintJsonFormat = RemoteIsolateHandler.option.isPrintJsonFormat && !kReleaseMode;
      formatMsg = isPrintJsonFormat ? '${Utils.stringifyMessage(jsonEncode(message))}' : jsonEncode(message);
    }
    printMessageWrapped('$tag $formatMsg', isReceive: false);
  }

  void printMessageWrapped(String text, {bool isReceive = true}) {
    if (kReleaseMode) {
      for (final String value in Utils.splitStringByLength(text, 800)) {
        handlerPrint(LogLevel.info, value);
      }
    } else {
      if (isReceive) {
        _pen.yellow();
      } else {
        _pen.green();
      }
      for (final String value in Utils.splitStringByLength(text, 800)) {
        handlerPrint(LogLevel.info, _pen(value));
      }
    }
  }

  static PrintCallback? printCallback;

  void handlerPrint(LogLevel level, String data) {
    final String fixData = '$logTag $data';
    if (printCallback != null) {
      printCallback?.call(level, fixData);
    } else {
      // ignore: avoid_print
      print(fixData);
    }
  }

  void handleUncaughtError(Object error, StackTrace stackTrace) {
    RemoteIsolateHandler.handleUncaughtError(error, stackTrace);
  }
}
