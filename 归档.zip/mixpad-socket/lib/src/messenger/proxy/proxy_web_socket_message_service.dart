import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:mixpad_socket/src/entity/entity.dart';
import 'package:mixpad_socket/src/messenger/message_io_base.dart';

class ProxyWebSocketMessageService extends MessageIoBase {
  factory ProxyWebSocketMessageService() => _service ??= ProxyWebSocketMessageService._();

  ProxyWebSocketMessageService._();

  static ProxyWebSocketMessageService? _service;

  @override
  String get logTag => '[Simulation WebSocket]';

  WebSocket? _webSocket;

  String _ip = 'localhost';
  static const int _port = 7530;

  @override
  int startService(
      {required List<dynamic> connectParam, required ConnectStatusChangeCallback connectStatusChangeCallback}) {
    super.startService(connectParam: connectParam, connectStatusChangeCallback: connectStatusChangeCallback);
    _ip = connectParam[0] as String;
    openSocket();
    return successCode;
  }

  bool _isConnectionRetry = true;
  bool _isPrintConnectInfo = true;

  /// 开启Socket连接
  Future<void> openSocket() async {
    final String wsUrl = 'ws://$_ip:$_port';
    try {
      if (connectStatus == ConnectStatus.connecting) {
        return;
      }
      closeService();
      _isConnectionRetry = true;
      if (_isPrintConnectInfo) {
        handlerPrint(LogLevel.info, '开始连接通信服务: $wsUrl');
      }
      connectStatus = ConnectStatus.connecting;
      // ignore: close_sinks
      final WebSocket webSocket = await WebSocket.connect(wsUrl);
      if (webSocket.readyState != WebSocket.open) {
        throw Exception('WebSocket状态异常:${webSocket.readyState}');
      }
      _webSocket = webSocket;
      webSocket.timeout(const Duration(seconds: 10), onTimeout: (EventSink<dynamic> list) {
        handlerPrint(LogLevel.error, '通信服务超时,尝试重新连接: $wsUrl');
        openSocket();
      });
      webSocket.listen(_onReceiveMessage, onDone: () {
        handlerPrint(LogLevel.warn, '通信服务=>onDone');
        openSocket();
      }, onError: (Object error, StackTrace stackTrace) {
        handlerPrint(LogLevel.error, '通信服务异常:$error\n$stackTrace');
        connectStatus = ConnectStatus.failed;
        closeService();
      });
      // 连接成功，返回WebSocket实例
      handlerPrint(LogLevel.info, '通信服务连接成功: $wsUrl');
      connectStatus = ConnectStatus.connected;
      _isPrintConnectInfo = true;
    } catch (e, s) {
      if (_isPrintConnectInfo) {
        _isPrintConnectInfo = false;
        handlerPrint(LogLevel.warn, '通信服务连接失败 $e\n$s');
      }
      connectStatus = ConnectStatus.failed;
      if (_isConnectionRetry) {
        return openSocket();
      }
    }
  }

  Future<void> _onReceiveMessage(dynamic data) async {
    try {
      if (data is! String) {
        throw Exception('数据类型异常:$data');
      }
      await onHandlerRawResultMessage(data);
    } catch (e, s) {
      handleUncaughtError(e, s);
    }
  }

  /// 由调用者保证数据格式 发送WebSocket消息
  @override
  int sendMessage(EventMessage message) {
    super.sendMessage(message);
    final String messageStr = jsonEncode(message);
    if (_webSocket != null && connectStatus == ConnectStatus.connected) {
      _webSocket?.add(messageStr);
      return successCode;
    } else {
      handlerPrint(LogLevel.warn, '发送失败:连接状态异常');
      final EventMessageResult result =
          EventMessageResult.connectError(EventMessage.fromJson(jsonDecode(messageStr) as Map<String, dynamic>));
      unawaited(onHandlerRawResultMessage(jsonEncode(result)));
      return nullErrorCode;
    }
  }

  @override
  void closeService() {
    _isConnectionRetry = false;
    _webSocket?.close();
    if (_isPrintConnectInfo) {
      handlerPrint(LogLevel.warn, '关闭通信服务');
    }
  }

  @override
  Future<void> onHandlerResultMessage(EventMessageResult message) async {
    if (message.event == ReadBlackboardMessage.eventName) {
      final ReadBlackboardMessageResult? result = ReadBlackboardMessageResult.fromEventMessageResult(message);
      if (result != null) {
        final int serial = result.serial;
        final Completer<ReadBlackboardMessageResult>? completer = _readBlackboardCompleterMap[serial];
        if (completer != null) {
          if (!completer.isCompleted) {
            completer.complete(result);
          }
          _readBlackboardCompleterMap.remove(serial);
        }
      }
    } else if (message.event == WriteBlackboardMessage.eventName) {
      final WriteBlackboardMessageResult? result = WriteBlackboardMessageResult.fromEventMessageResult(message);
      if (result != null) {
        final int serial = result.serial;
        final Completer<WriteBlackboardMessageResult>? completer = _writeBlackboardCompleterMap[serial];
        if (completer != null) {
          if (!completer.isCompleted) {
            completer.complete(result);
          }
          _readBlackboardCompleterMap.remove(serial);
        }
      }
    } else {
      await super.onHandlerResultMessage(message);
    }
  }

  final Map<int, Completer<ReadBlackboardMessageResult>> _readBlackboardCompleterMap =
      <int, Completer<ReadBlackboardMessageResult>>{};
  final Map<int, Completer<WriteBlackboardMessageResult>> _writeBlackboardCompleterMap =
      <int, Completer<WriteBlackboardMessageResult>>{};

  @override
  FutureOr<ReadBlackboardMessageResult> readBlackboard(ReadBlackboardMessage message) {
    _readBlackboardCompleterMap
        .removeWhere((int key, Completer<ReadBlackboardMessageResult> value) => value.isCompleted);
    final Completer<ReadBlackboardMessageResult> result = Completer<ReadBlackboardMessageResult>();
    _readBlackboardCompleterMap[message.serial] = result;
    sendMessage(message.toEventMessage());
    return result.future.timeout(const Duration(seconds: 15), onTimeout: () {
      final int serial = message.serial;
      _readBlackboardCompleterMap.remove(serial);
      result
          .complete(ReadBlackboardMessageResult.fromMessage(message: message, value: null, resultCode: statusTimeout));
      return result.future;
    });
  }

  @override
  FutureOr<WriteBlackboardMessageResult> writeBlackboard(WriteBlackboardMessage message) {
    _writeBlackboardCompleterMap
        .removeWhere((int key, Completer<WriteBlackboardMessageResult> value) => value.isCompleted);
    final Completer<WriteBlackboardMessageResult> result = Completer<WriteBlackboardMessageResult>();
    _writeBlackboardCompleterMap[message.serial] = result;
    sendMessage(message.toEventMessage());
    return result.future.timeout(const Duration(seconds: 15), onTimeout: () {
      final int serial = message.serial;
      _writeBlackboardCompleterMap.remove(serial);
      result.complete(WriteBlackboardMessageResult.fromMessage(message: message, resultCode: statusTimeout));
      return result.future;
    });
  }
}
