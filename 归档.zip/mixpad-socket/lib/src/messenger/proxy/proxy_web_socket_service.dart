import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:mixpad_socket/src/entity/entity.dart';
import 'package:mixpad_socket/src/messenger/message_io_base.dart';

/// Created by liyang on 2022/3/14.

class ProxyWebSocketService {
  factory ProxyWebSocketService() => _service ??= ProxyWebSocketService._();

  ProxyWebSocketService._();

  static ProxyWebSocketService? _service;

  MessageIoBase? _proxyIO;

  HttpServer? _httpServer;
  final List<WebSocket> _clientWebSocket = <WebSocket>[];

  Future<void> startProxyService(MessageIoBase io) async {
    try {
      await closeProxyService();
      _proxyIO = io;
      io.onReceiveRawListeners.add(_onReceiveMessage);
      _httpServer = await HttpServer.bind(InternetAddress.anyIPv4, 7530);
      _handlerPrint(LogLevel.info, '代理服务启动成功 ws://${_httpServer?.address.host}:${_httpServer?.port}');
      _httpServer?.listen((HttpRequest request) async {
        final WebSocket webSocket = await WebSocketTransformer.upgrade(request);
        _addClient(webSocket, request);
      }, onDone: () {
        _handlerPrint(LogLevel.error, '代理服务异常');
      }, onError: (Object error, StackTrace stackTrace) {
        _handlerPrint(LogLevel.error, '代理服务异常 => $error\n$stackTrace');
      });
    } catch (e, s) {
      _handlerPrint(LogLevel.error, '代理服务异常 => $e\n$s');
    }
  }

  Future<void> closeProxyService() async {
    _proxyIO?.onReceiveRawListeners.remove(_onReceiveMessage);
    _proxyIO = null;
    for (final WebSocket client in _clientWebSocket) {
      unawaited(client.close());
    }
    _clientWebSocket.clear();
    await _httpServer?.close();
    _httpServer = null;
  }

  void _addClient(WebSocket client, HttpRequest request) {
    if (_clientWebSocket.contains(client)) {
      return;
    }
    _clientWebSocket.add(client);
    client.listen(_onClientMessage, onDone: () {
      _removeClient(client, request);
    }, onError: (Object error, StackTrace stackTrace) {
      _removeClient(client, request, error: error, stackTrace: stackTrace);
    });
    _handlerPrint(LogLevel.info,
        '客户端连接成功 address:${request.connectionInfo?.remoteAddress.address} port:${request.connectionInfo?.remotePort}');
  }

  void _removeClient(WebSocket client, HttpRequest request, {Object? error, StackTrace? stackTrace}) {
    _clientWebSocket.remove(client);
    client.close();
    _handlerPrint(LogLevel.error,
        '客户端异常 address:${request.connectionInfo?.remoteAddress.address} port:${request.connectionInfo?.remotePort} => $error\n$stackTrace');
  }

  Future<void> _onClientMessage(dynamic data) async {
    _handlerPrint(LogLevel.info, "client_data => $data");
    if (data is String) {
      final MessageIoBase? io = _proxyIO;
      final EventMessage message = EventMessage.fromJson(jsonDecode(data) as Map<String, dynamic>);
      if (message.event == ReadBlackboardMessage.eventName) {
        final ReadBlackboardMessage? event = ReadBlackboardMessage.fromEventMessage(message);
        _handlerPrint(LogLevel.info, "client_data2 => $event");
        if (io != null && event != null) {
          final ReadBlackboardMessageResult result = await io.readBlackboard(event);
          _handlerPrint(LogLevel.info, "client_data3 => $event");
          _onReceiveMessage(jsonEncode(result.toEventMessageResult()));
        }
      } else if (message.event == WriteBlackboardMessage.eventName) {
        final WriteBlackboardMessage? event = WriteBlackboardMessage.fromEventMessage(message);
        if (io != null && event != null) {
          final WriteBlackboardMessageResult result = await io.writeBlackboard(event);
          _onReceiveMessage(jsonEncode(result.toEventMessageResult()));
        }
      } else {
        _proxyIO?.sendMessage(EventMessage.fromJson(jsonDecode(data) as Map<String, dynamic>));
      }
    } else {
      throw Exception('数据类型异常:$data');
    }
  }

  void _onReceiveMessage(String message) {
    for (final WebSocket client in _clientWebSocket) {
      try {
        client.add(message);
      } catch (e, s) {
        _proxyIO?.handlerPrint(LogLevel.error, '$e\n$s');
      }
    }
  }

  void sendMessageToClient(String message) {
    _onReceiveMessage(message);
  }

  void _handlerPrint(LogLevel level, String data) {
    _proxyIO?.handlerPrint(level, '[Simulation WebSocket Service] $data');
  }
}
