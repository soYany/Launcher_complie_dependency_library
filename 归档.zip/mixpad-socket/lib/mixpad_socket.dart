library mixpad_socket;

import 'dart:async';
import 'dart:isolate';

import 'package:mixpad_socket/src/entity/entity.dart';
import 'package:mixpad_socket/src/isolate/local_isolate_handler.dart';
import 'package:mixpad_socket/src/isolate/remote_isolate_handler.dart';

export 'mixpad_socket.dart';
export 'src/entity/entity.dart'
    show
        ConnectStatus,
        ConnectStatusChangeCallback,
        MessageDataCallback,
        ParseDataCallback,
        PrintCallback,
        EventMessage,
        EventMessageResult,
        ReadBlackboardMessage,
        ReadBlackboardMessageResult,
        WriteBlackboardMessage,
        WriteBlackboardMessageResult,
        MixPadSocketOption,
        LogLevel;

class MixPadSocket {
  factory MixPadSocket() => _singleton;

  MixPadSocket._internal();

  static final MixPadSocket _singleton = MixPadSocket._internal();

  Isolate? _isolate;
  ReceivePort? _receivePort;

  Future<void> init() async {
    await _makeIsolate();
  }

  void setOption(MixPadSocketOption option) {
    LocalIsolateHandler.setOption(option);
  }

  Capability? pause() {
    return _isolate?.pause();
  }

  void resume(Capability capability) {
    _isolate?.resume(capability);
  }

  void close() {
    disconnect();
    _receivePort?.close();
    _receivePort = null;
    _isolate?.kill();
    _isolate = null;
  }

  Future<void> _checkIsolate() async {
    if ((_isolate == null || _receivePort == null) && !_isInitializing) {
      close();
      await _makeIsolate();
    }
  }

  bool _isInitializing = false;

  Future<void> _makeIsolate() async {
    if (_isInitializing) {
      return;
    }
    _isInitializing = true;
    final ReceivePort receivePort = ReceivePort();
    _receivePort?.close();
    _receivePort = receivePort;
    _isolate = await Isolate.spawn(RemoteIsolateHandler.handler, receivePort.sendPort,
        onError: receivePort.sendPort, errorsAreFatal: false);
    await _startListener(receivePort);
    _isInitializing = false;
  }

  Future<SendPort> _startListener(ReceivePort receivePort) async {
    final Completer<SendPort> completer = Completer<SendPort>();
    Future<void> _listener() async {
      await for (final dynamic msg in receivePort) {
        try {
          if (msg is LocalActionEntity) {
            LocalIsolateHandler.handler(msg);
          } else if (msg is List) {
            final String errorDescription = msg[0] as String;
            final String? stackDescription = msg[1] as String?;
            Zone.current.handleUncaughtError(errorDescription,
                stackDescription == null ? StackTrace.empty : StackTrace.fromString(stackDescription));
          } else if (msg is SendPort) {
            LocalIsolateHandler.setSendPort(msg);
            completer.complete(msg);
          }
        } catch (e, s) {
          Zone.current.handleUncaughtError(e, s);
        }
      }
    }

    unawaited(_listener());
    return completer.future;
  }

  Future<void> startConnectNative({String serviceName = 'mixpad_gui', String version = '1'}) async {
    await _checkIsolate();
    LocalIsolateHandler.startConnect((ConnectType.native, <dynamic>[serviceName, version]));
  }

  Future<void> startConnectProxy({required String ip}) async {
    LocalIsolateHandler.startConnect((ConnectType.proxy, <dynamic>[ip]));
  }

  void disconnect() {
    LocalIsolateHandler.disconnect();
  }

  /// 调用该方法用来发送消息。
  ///
  /// 要设置请求重试次数，可以设置[retryCount]，每重发一次，[retryCount]减1，
  /// 当[retryCount]>1时，每过[intervalTimeout]没有返回消息，则重发一次，
  /// 当[retryCount]==0时，则最后一次发送请求的超时时长为[intervalTimeout]，
  /// 当用户未设置[retryCount]时，[intervalTimeout]表示该请求的超时时长，
  /// [isNeedResponse]表示是否依赖于ACK机制返回结果.
  ///
  Future<EventMessageResult> sendMessage(dynamic message,
      {int retryCount = 0,
      Duration intervalTimeout = const Duration(milliseconds: 3000),
      bool isNeedResponse = true}) async {
    if (retryCount < 0) {
      throw Exception('retryCount不能小于0');
    }
    return LocalIsolateHandler.sendMessage(message, retryCount, intervalTimeout, isNeedResponse: isNeedResponse);
  }

  void setMessageListener(MessageDataCallback listener) {
    LocalIsolateHandler.onReceiveListener = listener;
  }

  void removeMessageListener() {
    LocalIsolateHandler.onReceiveListener = null;
  }

  void setConnectStatusListener(void Function(ConnectStatus status) listener) {
    LocalIsolateHandler.onConnectStatusListener = listener;
  }

  void removeConnectStatusListener() {
    LocalIsolateHandler.onConnectStatusListener = null;
  }

  void setEventListener(String eventName, MessageDataCallback listener) {
    LocalIsolateHandler.setEventListener(eventName, listener);
  }

  void removeEventListener(String eventName) {
    LocalIsolateHandler.removeEventListener(eventName);
  }

  // TODO(liyang): VM目前只允许在隔离消息中发送类中顶级方法或静态方法的闭包, https://github.com/dart-lang/sdk/issues/38964#issuecomment-550569513
  void registerParseFunction(String eventName, dynamic Function(dynamic data) parse) {
    LocalIsolateHandler.registerParseFunction(eventName, parse);
  }

  void unregisterParseFunction(String eventName) {
    LocalIsolateHandler.unregisterParseFunction(eventName);
  }

  void registerPrintCallback(PrintCallback print) {
    LocalIsolateHandler.registerPrintCallback(print);
  }

  void unregisterPrintCallback() {
    LocalIsolateHandler.unregisterPrintCallback();
  }

  void startProxyService() {
    LocalIsolateHandler.startProxyService();
  }

  void closeProxyService() {
    LocalIsolateHandler.closeProxyService();
  }

  void sendMessageProxyClient(EventMessage message) {
    LocalIsolateHandler.sendMessageProxyClient(message);
  }

  Future<ReadBlackboardMessageResult> readBlackboardValue(
    ReadBlackboardMessage message, {
    Duration intervalTimeout = const Duration(milliseconds: 3000),
  }) =>
      LocalIsolateHandler.readBlackboardValue(message, intervalTimeout: intervalTimeout);

  Future<WriteBlackboardMessageResult> writeBlackboardValue(
    WriteBlackboardMessage message, {
    Duration intervalTimeout = const Duration(milliseconds: 3000),
  }) =>
      LocalIsolateHandler.writeBlackboardValue(message, intervalTimeout: intervalTimeout);

  void watchdog(String processName, int timeoutSec) {
    LocalIsolateHandler.watchdog(processName, timeoutSec);
  }

  void watchdogStop(String processName) {
    LocalIsolateHandler.watchdogStop(processName);
  }

  void processExit(String processName) {
    LocalIsolateHandler.processExit(processName);
  }
}
